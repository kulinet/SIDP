<?= $this->extend(service('request')->getUserAgent()->isMobile() ? 'layout/mobile_main' : 'layout/main') ?>

<?= $this->section('content') ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light">Settings /</span> API Security
    </h4>

    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success alert-dismissible" role="alert">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <h5 class="card-header">API Access Token</h5>
                <div class="card-body">
                    <div class="alert alert-warning mb-4" role="alert">
                        <h6 class="alert-heading fw-bold mb-1">Peringatan Keamanan!</h6>
                        <p class="mb-0">Token ini memberikan akses penuh ke API data pengadaan. Jangan bagikan token ini kepada siapapun. Gunakan token ini pada header <code>X-API-KEY</code> di aplikasi Flutter Anda.</p>
                    </div>

                    <?php 
                        $generatedToken = session()->getFlashdata('generated_token');
                        $hasToken = !empty($user['api_token']);
                        $displayValue = $generatedToken ? $generatedToken : ($hasToken ? '•••••••••••••••••••••••••••••••• (Tersimpan Aman / Ter-hash)' : 'Belum ada token');
                    ?>

                    <?php if ($generatedToken) : ?>
                        <div class="alert alert-danger mb-3" role="alert">
                            <i class="bx bx-error-circle me-1"></i> <strong>Perhatian:</strong> Salin token di bawah sekarang. Demi alasan keamanan, token mentah ini hanya ditampilkan satu kali ini saja!
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('user/api-settings/generate') ?>" method="POST">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label">Your API Token</label>
                            <div class="input-group input-group-merge">
                                <input type="text" class="form-control <?= $generatedToken ? 'border-danger text-danger fw-bold' : '' ?>" id="apiToken" value="<?= esc($displayValue) ?>" data-copyable="<?= $generatedToken ? esc($generatedToken) : '' ?>" readonly>
                                <?php if ($generatedToken) : ?>
                                    <span class="input-group-text cursor-pointer bg-primary text-white" onclick="copyToken()"><i class="bx bx-copy me-1"></i> Salin Token</span>
                                <?php else : ?>
                                    <span class="input-group-text cursor-pointer" onclick="copyToken()"><i class="bx bx-copy"></i></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-text">
                                <?= $hasToken ? '<span class="badge bg-label-success">Token Aktif (SHA-256 Hashed)</span>' : '<span class="badge bg-label-secondary">Tidak Ada Token</span>' ?>
                                Gunakan token ini pada header <code>Authorization: Bearer &lt;token&gt;</code> atau <code>X-API-KEY: &lt;token&gt;</code>.
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary me-2" onclick="return confirm('Generate token baru akan membatalkan token yang lama. Lanjutkan?')">Generate New Token</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <h5 class="card-header">Contoh Penggunaan API (Flutter)</h5>
                <div class="card-body">
                    <pre class="bg-dark text-white p-3 rounded"><code>
// Contoh Flutter Code
final response = await http.get(
  Uri.parse('https://ajip.io/api/summary'),
  headers: {
    'X-API-KEY': 'YOUR_TOKEN_HERE',
    'Accept': 'application/json',
  },
);
                    </code></pre>
                </div>
            </div>
        <?php /* Updated API Settings view with endpoint list */ ?>
</div>
</div>
<div class="card mb-4">
    <h5 class="card-header">List API Endpoints</h5>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr><th>Method</th><th>Endpoint</th><th>Description</th></tr>
            </thead>
            <tbody>
                <tr><td>POST</td><td>/api/login</td><td>User login, returns JWT token</td></tr>
                <tr><td>GET</td><td>/api/summary</td><td>Get summary of procurement data</td></tr>
                <tr><td>GET</td><td>/api/lpse/{segment}</td><td>Retrieve LPSE data for given segment</td></tr>
                <tr><td>GET</td><td>/api/rup-opd</td><td>Get RUP data per OPD</td></tr>
                <tr><td>POST</td><td>/api/chatbot/ask</td><td>Ask chatbot via API</td></tr>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>

<script>
function copyToken() {
    var tokenInput = document.getElementById("apiToken");
    var copyableValue = tokenInput.getAttribute("data-copyable");
    
    if (copyableValue && copyableValue.length > 0) {
        navigator.clipboard.writeText(copyableValue).then(function() {
            alert("Token API berhasil disalin ke clipboard!");
        });
        return;
    }
    
    if (tokenInput.value.indexOf('••••') !== -1) {
        alert("Token tersimpan dalam format hash demi keamanan. Jika lupa, klik 'Generate New Token' untuk membuat token baru.");
        return;
    }

    if (tokenInput.value === 'Belum ada token') {
        alert("Belum ada token. Silakan klik 'Generate New Token'.");
        return;
    }
    
    navigator.clipboard.writeText(tokenInput.value).then(function() {
        alert("Token berhasil disalin!");
    });
}
</script>
<?= $this->endSection() ?>
