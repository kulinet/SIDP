<?php

namespace App\Controllers;

use App\Models\ChatbotKnowledgeModel;
use CodeIgniter\RESTful\ResourceController;
use Smalot\PdfParser\Parser;

class ChatbotKnowledge extends ResourceController
{
    public function index()
    {
        $model = new ChatbotKnowledgeModel();
        
        // Group by document_title to show the list of uploaded documents
        $db = \Config\Database::connect();
        $builder = $db->table('chatbot_knowledge');
        $builder->select('document_title, COUNT(*) as chunks, MAX(created_at) as uploaded_at');
        $builder->groupBy('document_title');
        $builder->orderBy('uploaded_at', 'DESC');
        
        $documents = $builder->get()->getResultArray();
        
        return view('user/chatbot_knowledge', [
            'title' => 'Library Kepintaran AI',
            'user'  => session()->get(),
            'documents' => $documents
        ]);
    }

    public function upload()
    {
        $file = $this->request->getFile('pdf_document');
        $ext = strtolower($file->getExtension());
        if (!$file->isValid() || !in_array($ext, ['pdf', 'txt'])) {
            return redirect()->back()->with('error', 'File tidak valid. Harap unggah PDF atau TXT.');
        }

        $filename = $file->getName();
        // Cek jika dokumen sudah ada
        $model = new ChatbotKnowledgeModel();
        $existing = $model->where('document_title', $filename)->first();
        if ($existing) {
            return redirect()->back()->with('error', 'Dokumen dengan nama ini sudah ada di library.');
        }

        // Simpan file sementara
        $tempPath = $file->getTempName();

        try {
            $text = '';
            if ($ext === 'pdf') {
                $parser = new Parser();
                $pdf = $parser->parseFile($tempPath);
                $text = $pdf->getText();
            } else {
                // Jika file TXT, langsung baca isinya
                $text = file_get_contents($tempPath);
            }
            
            // Bersihkan text (hapus multiple whitespace, baris kosong)
            $text = preg_replace('/\s+/', ' ', $text);

            // Chunking text (misalnya per 1000 karakter)
            $chunks = str_split($text, 1000);
            
            $settingsModel = new \App\Models\SettingsModel();
            $apiKey = $settingsModel->getSetting('embedding_api_key', env('OPENAI_API_KEY'));
            $embeddingUrl = $settingsModel->getSetting('embedding_api_url', 'https://api.openai.com/v1/embeddings');
            $embeddingModel = $settingsModel->getSetting('embedding_model', 'text-embedding-3-small');

            $successCount = 0;
            $lastError = '';
            
            foreach ($chunks as $chunk) {
                if (trim($chunk) === '') continue;

                // Dapatkan embedding vektor
                $embedRes = $this->getEmbedding($chunk, $apiKey, $embeddingUrl, $embeddingModel);
                if (isset($embedRes['error'])) {
                    $lastError = $embedRes['error'];
                    continue; // Skip jika gagal mendapat vektor
                }

                $model->insert([
                    'document_title' => $filename,
                    'chunk_text' => trim($chunk),
                    'embedding_vector' => json_encode($embedRes['embedding']),
                ]);
                $successCount++;
            }

            if ($successCount === 0 && $lastError !== '') {
                return redirect()->back()->with('error', "Gagal membuat vektor. Pastikan API Chatbot Anda mendukung endpoint /embeddings dan model text-embedding-3-small. Error: " . $lastError);
            }

            return redirect()->back()->with('success', "Berhasil membaca dan menyimpan $successCount potongan teks dari $filename.");
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal memproses PDF: ' . $e->getMessage());
        }
    }
    
    public function delete($id = null)
    {
        $title = $this->request->getPost('document_title');
        $model = new ChatbotKnowledgeModel();
        $model->where('document_title', $title)->delete();
        return redirect()->back()->with('success', "Dokumen $title berhasil dihapus dari library.");
    }

    private function getEmbedding($text, $apiKey, $url, $model)
    {
        $data = [
            'model' => $model,
            'input' => $text
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) return ['error' => 'cURL Error: ' . $error];

        $resObj = json_decode($response, true);
        if (isset($resObj['data'][0]['embedding'])) {
            return ['embedding' => $resObj['data'][0]['embedding']];
        }

        return ['error' => 'Response API tidak valid: ' . $response];
    }
}
