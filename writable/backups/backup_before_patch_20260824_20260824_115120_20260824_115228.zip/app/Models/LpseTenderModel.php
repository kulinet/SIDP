<?php

namespace App\Models;

use CodeIgniter\Model;

class LpseTenderModel extends Model
{
    protected $table = 'lpse_tender';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'kd_rup', 'tahun', 'kd_paket', 'nama_paket', 'nama_satker', 'kd_satker', 'pagu', 'hps', 
        'nilai_penawaran', 'nilai_kontrak', 'nama_penyedia', 'metode', 'tgl_pemenang', 'tgl_kontrak', 
        'no_kontrak', 'status', 'jenis_pengadaan', 'kgr_nama', 'mtd_evaluasi', 'mtd_kualifikasi', 
        'kualifikasi_paket', 'kontrak_pembayaran', 'status_kontrak'
    ];
    protected $useTimestamps = true;
}
