<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\SettingsModel;
use App\Models\UserModel;

class SettingsController extends BaseController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new SettingsModel();
        // Extra check to ensure only admin can access
        if (session()->get('role') !== 'admin') {
            header('Location: ' . base_url('dashboard'));
            exit;
        }
    }

    public function chatbot()
    {
        $data = [
            'title' => 'Chatbot Settings',
            'settings' => [
                'model' => $this->settingsModel->getSetting('chatbot_model', 'gpt-5.4-mini'),
                'api_key' => $this->settingsModel->getSetting('chatbot_api_key', ''),
                'api_url' => $this->settingsModel->getSetting('chatbot_api_url', 'https://api.ai.cc/v1/chat/completions'),
                'embedding_model' => $this->settingsModel->getSetting('embedding_model', 'text-embedding-3-small'),
                'embedding_api_key' => $this->settingsModel->getSetting('embedding_api_key', ''),
                'embedding_api_url' => $this->settingsModel->getSetting('embedding_api_url', 'https://api.openai.com/v1/embeddings'),
            ]
        ];

        return view('user/chatbot_settings', $data);
    }

    public function saveChatbot()
    {
        $rules = [
            'chatbot_model' => 'required',
            'chatbot_api_key' => 'required',
            'chatbot_api_url' => 'required|valid_url',
            'embedding_model' => 'required',
            'embedding_api_key' => 'required',
            'embedding_api_url' => 'required|valid_url',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->settingsModel->updateSetting('chatbot_model', $this->request->getPost('chatbot_model'));
        $this->settingsModel->updateSetting('chatbot_api_key', $this->request->getPost('chatbot_api_key'));
        $this->settingsModel->updateSetting('chatbot_api_url', $this->request->getPost('chatbot_api_url'));
        $this->settingsModel->updateSetting('embedding_model', $this->request->getPost('embedding_model'));
        $this->settingsModel->updateSetting('embedding_api_key', $this->request->getPost('embedding_api_key'));
        $this->settingsModel->updateSetting('embedding_api_url', $this->request->getPost('embedding_api_url'));

        return redirect()->to(base_url('user/chatbot-settings'))->with('success', 'Chatbot settings updated successfully.');
    }

    public function generateToken()
    {
        $userModel = new UserModel();
        $userId = session()->get('id');
        $token = bin2hex(random_bytes(32)); // Secure 64‑char token
        $userModel->update($userId, ['api_token' => $token]);
        return redirect()->to(base_url('user/api-settings'))->with('success', 'New API Token generated successfully.');
    }

    // New method to render API Security settings page
    public function api()
    {
        $userModel = new UserModel();
        $userId = session()->get('id');
        $user = $userModel->find($userId);
        $data = [
            'title' => 'API Security Settings',
            'user' => $user,
        ];
        return view('user/api_settings', $data);
    }

    public function sync()
    {
        $data = [
            'title' => 'Sinkronisasi Data RUP',
            'last_sync_penyedia' => $this->settingsModel->getSetting('last_sync_penyedia', 'Belum pernah'),
            'last_sync_swakelola' => $this->settingsModel->getSetting('last_sync_swakelola', 'Belum pernah'),
            'last_sync_tender' => $this->settingsModel->getSetting('last_sync_tender', 'Belum pernah'),
            'last_sync_nontender' => $this->settingsModel->getSetting('last_sync_nontender', 'Belum pernah'),
            'last_sync_epurchasing' => $this->settingsModel->getSetting('last_sync_epurchasing', 'Belum pernah'),
            'last_sync_master' => $this->settingsModel->getSetting('last_sync_master', 'Belum pernah'),
            'last_sync_pct_nontender' => $this->settingsModel->getSetting('last_sync_pct_nontender', 'Belum pernah'),
            'last_sync_pct_swakelola' => $this->settingsModel->getSetting('last_sync_pct_swakelola', 'Belum pernah'),
        ];

        return view('user/sync_settings', $data);
    }

    public function doSync($type)
    {
        // Increase execution time for large data
        set_time_limit(600);
        ini_set('memory_limit', '1024M');

        $syncService = new \App\Services\SyncService();
        $currentYear = date('Y');

        try {
            switch ($type) {
                case 'penyedia':
                    $count = $syncService->syncPenyedia($currentYear);
                    $this->settingsModel->updateSetting('last_sync_penyedia', date('Y-m-d H:i:s'));
                    break;
                case 'swakelola':
                    $count = $syncService->syncSwakelola($currentYear);
                    $this->settingsModel->updateSetting('last_sync_swakelola', date('Y-m-d H:i:s'));
                    break;
                case 'tender':
                    $count = $syncService->syncTender($currentYear);
                    $this->settingsModel->updateSetting('last_sync_tender', date('Y-m-d H:i:s'));
                    break;
                case 'nontender':
                    $count = $syncService->syncNontender($currentYear);
                    $this->settingsModel->updateSetting('last_sync_nontender', date('Y-m-d H:i:s'));
                    break;
                case 'epurchasing':
                    $count = $syncService->syncEpurchasing($currentYear);
                    $this->settingsModel->updateSetting('last_sync_epurchasing', date('Y-m-d H:i:s'));
                    break;
                case 'master':
                    $count = $syncService->syncMasterAnggaran($currentYear);
                    $this->settingsModel->updateSetting('last_sync_master', date('Y-m-d H:i:s'));
                    break;
                case 'pct_nontender':
                    $count = $syncService->syncPencatatanNontender($currentYear);
                    $this->settingsModel->updateSetting('last_sync_pct_nontender', date('Y-m-d H:i:s'));
                    break;
                case 'pct_swakelola':
                    $count = $syncService->syncPencatatanSwakelola($currentYear);
                    $this->settingsModel->updateSetting('last_sync_pct_swakelola', date('Y-m-d H:i:s'));
                    break;
                default:
                    throw new \Exception("Tipe sinkronisasi tidak dikenal.");
            }

            return $this->response->setJSON([
                'status' => 'success',
                'message' => "Berhasil sinkronisasi $count data $type."
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
