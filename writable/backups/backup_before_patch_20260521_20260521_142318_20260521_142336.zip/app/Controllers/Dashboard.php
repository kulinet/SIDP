<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\MasterAnggaranModel;
use App\Models\RupPenyediaModel;
use App\Models\RupSwakelolaModel;
use App\Models\LpseTenderModel;
use App\Models\LpseNontenderModel;
use App\Models\EpurchasingModel;
use App\Models\LpsePencatatanNontenderModel;
use App\Models\LpsePencatatanSwakelolaModel;

class Dashboard extends BaseController
{
    use ResponseTrait;

    public function getFilterOptions($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        
        if ($type === 'epurchasing') {
            $model = new \App\Models\EpurchasingModel();
            $data = $model->where('tahun', $currentYear)->select('nama_satker')->distinct()->findAll();
            $opds = array_values(array_unique(array_filter(array_column($data, 'nama_satker'))));
            
            $userSatker = session()->get('nama_satker');
            $userRole = session()->get('role');
            if (($userRole === 'satker' || $userRole === 'opd') && $userSatker) {
                $opds = [$userSatker];
            } else {
                sort($opds);
            }
            return $this->response->setJSON($opds);
        }

        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $data = $model->where('tahun', $currentYear)->findAll();
        
        $opds = array_values(array_unique(array_filter(array_column($data, 'nama_satker'))));
        $jenis = array_values(array_unique(array_filter(array_column($data, 'jenis_pengadaan'))));
        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
        $metodes = array_values(array_unique(array_filter(array_column($data, $metodeField))));

        $userSatker = session()->get('nama_satker');
        $userRole = session()->get('role');

        if (($userRole === 'satker' || $userRole === 'opd') && $userSatker) {
            $opds = [$userSatker];
        } else {
            sort($opds);
        }
        sort($jenis);
        sort($metodes);

        return $this->response->setJSON([
            'opds' => $opds,
            'jenis' => $jenis,
            'metodes' => $metodes
        ]);
    }

    private $apiPenyedia;
    private $apiSwakelola;
    private $apiMasterSatker;
    private $apiKegiatanMaster;
    
    // Specific for RUP OPD Monitoring
    private $apiRupAnggaranPenyedia;
    private $apiRupAnggaranSwakelola;

    // Data Pengadaan APIs
    private $apiEpurchasing;
    private $apiTender;
    private $apiTenderEkontrak;
    private $apiNonTender;
    private $apiPencatatanNonTender;
    private $apiPencatatanSwakelola;
    private $apiPencatatanSwakelolaRealisasi;
    private $apiNonTenderEkontrak;
    private $apiPengumumanTender;
    private $apiNonTenderSelesai;
    private $apiListPencatatanSwakelola;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $baseUrl = env('AJIP_API_BASE_URL', 'https://ajip-api.cloud');
        $this->apiPenyedia = $baseUrl . '/api/data/perbandingan-rup-penyedia';
        $this->apiSwakelola = $baseUrl . '/api/data/perbandingan-swakelola';
        $this->apiMasterSatker = $baseUrl . '/api/data/master-satker';
        $this->apiKegiatanMaster = $baseUrl . '/api/data/kegiatan-master';
        $this->apiRupAnggaranPenyedia = $baseUrl . '/api/data/rup-paket-anggaran';
        $this->apiRupAnggaranSwakelola = $baseUrl . '/api/data/rup-paket-swakelola';
        $this->apiEpurchasing = $baseUrl . '/api/data/paket-epurchasing';
        $this->apiTender = $baseUrl . '/api/data/tender-selesai';
        $this->apiTenderEkontrak = $baseUrl . '/api/data/list-tender-kontrak';
        $this->apiNonTender = $baseUrl . '/api/data/nontender-selesai';
        $this->apiPencatatanNonTender = $baseUrl . '/api/data/pencatatan-nontender-realisasi';
        $this->apiPencatatanSwakelola = $baseUrl . '/api/data/list-pencatatan-swakelola';
        $this->apiPencatatanSwakelolaRealisasi = $baseUrl . '/api/data/encatatan-swakelola-realisasi';
        $this->apiNonTenderEkontrak = $baseUrl . '/api/data/list-nontender-ekontrak';
        $this->apiPengumumanTender = $baseUrl . '/api/data/pengumuman-tender';
        $this->apiNonTenderSelesai = $baseUrl . '/api/data/nontender-selesai';
        $this->apiListPencatatanSwakelola = $baseUrl . '/api/data/list-pencatatan-swakelola';
    }

    public function index()
    {
        try {
            $chartModel = new \App\Models\DashboardChartModel();
            $charts = $chartModel->getWithMenu();
        } catch (\Throwable $e) {
            $charts = [];
        }

        return view('dashboard/index', [
            'title'  => 'Dashboard Overview',
            'user'   => session()->get(),
            'charts' => $charts
        ]);
    }

    public function getDashboardSummary($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = trim(session()->get('kd_satker') ?? '');
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        
        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        $data = $builder->findAll();
        
        $matrix = [];
        $jenisList = [];
        $metodeList = [];
        $opdList = [];

        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';

        foreach ($data as $item) {
            $opd = $item['nama_satker'] ?: 'N/A';
            $jenis = ($type === 'penyedia') ? ($item['jenis_pengadaan'] ?: 'N/A') : 'Swakelola';
            $metode = $item[$metodeField] ?: 'N/A';

            if (!isset($matrix[$opd])) $matrix[$opd] = [];
            if (!isset($matrix[$opd][$jenis])) $matrix[$opd][$jenis] = [];
            if (!isset($matrix[$opd][$jenis][$metode])) $matrix[$opd][$jenis][$metode] = ['pagu' => 0, 'paket' => 0];
            
            $matrix[$opd][$jenis][$metode]['pagu'] += (float)$item['pagu'];
            $matrix[$opd][$jenis][$metode]['paket'] += 1;

            $opdList[$opd] = true;
            $jenisList[$jenis] = true;
            $metodeList[$metode] = true;
        }

        return $this->respond([
            'matrix' => $matrix,
            'opds' => array_keys($opdList),
            'jenis' => array_keys($jenisList),
            'metodes' => array_keys($metodeList),
            'type' => $type
        ]);
    }


    public function penyedia()
    {
        $data = [
            'title' => 'Data RUP Penyedia',
            'user'  => session()->get(),
            'type'  => 'penyedia'
        ];
        return view('dashboard/table', $data);
    }

    public function swakelola()
    {
        $data = [
            'title' => 'Data RUP Swakelola',
            'user'  => session()->get(),
            'type'  => 'swakelola'
        ];
        return view('dashboard/table', $data);
    }

    public function rupOpd()
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $cacheKey = "rup_opd_v15_full_db_{$currentYear}";
        
        if (!$summary = cache($cacheKey)) {
            $masterModel = new MasterAnggaranModel();
            $penyediaModel = new RupPenyediaModel();
            $swakelolaModel = new RupSwakelolaModel();

            $kegiatanMaster = $masterModel->where('tahun', $currentYear)->findAll();
            $rupPenyedia = $penyediaModel->where('tahun', $currentYear)->findAll();
            $rupSwakelola = $swakelolaModel->where('tahun', $currentYear)->findAll();
            
            foreach ($rupPenyedia as &$p) $p['_tipe'] = 'Penyedia';
            foreach ($rupSwakelola as &$s) $s['_tipe'] = 'Swakelola';
            $allRup = array_merge($rupPenyedia, $rupSwakelola);

            $satkerPrograms = [];
            $kegiatanStats = [];
            foreach ($kegiatanMaster as $k) {
                $kd = $k['kd_satker'] ?: '0';
                $progKey = trim($k['kd_program_str'] ?: 'UNKNOWN');
                if (!isset($satkerPrograms[$kd])) $satkerPrograms[$kd] = [];
                if ($progKey !== 'UNKNOWN') $satkerPrograms[$kd][] = $progKey;

                if (!isset($kegiatanStats[$kd])) {
                    $kegiatanStats[$kd] = ['total_pagu' => 0, 'program_list' => [], 'nama_satker' => $k['nama_satker']];
                }
                $kegiatanStats[$kd]['total_pagu'] += (float)$k['pagu_program'];
                if (!isset($kegiatanStats[$kd]['program_list'][$progKey])) {
                    $kegiatanStats[$kd]['program_list'][$progKey] = ['name' => $k['nama_program'], 'pagu' => 0];
                }
                $kegiatanStats[$kd]['program_list'][$progKey]['pagu'] += (float)$k['pagu_program'];
            }

            // --- PROCESS RUP DATA ---
            $rupStats = [];
            $seenRup = [];
            foreach ($allRup as $item) {
                $kd = $item['kd_satker'] ?: '0';
                $kdRup = $item['kd_rup'];
                $isNewRup = false;
                if ($kdRup) {
                    if (!isset($seenRup[$kdRup])) { $seenRup[$kdRup] = true; $isNewRup = true; }
                } else { $isNewRup = true; }

                $paguItem = (float)$item['pagu'];
                $mak = trim($item['mak'] ?? '');
                $progKey = 'UNKNOWN';

                if ($mak && isset($satkerPrograms[$kd])) {
                    $cleanMak = str_replace(['.', '-'], '', $mak);
                    foreach ($satkerPrograms[$kd] as $validCode) {
                        $cleanCode = str_replace(['.', '-'], '', $validCode);
                        if ($cleanCode === '') continue;
                        if (str_starts_with($cleanMak, $cleanCode) || str_contains($mak, $validCode)) {
                            $progKey = $validCode;
                            break;
                        }
                    }
                }

                if (!isset($rupStats[$kd])) {
                    $rupStats[$kd] = [
                        'pagu' => 0, 
                        'paket' => 0, 
                        'programs' => [], 
                        'package_list' => [],
                        'nama_satker_fallback' => $item['nama_satker']
                    ];
                }

                if ($isNewRup) {
                    $rupStats[$kd]['pagu'] += $paguItem;
                    $rupStats[$kd]['paket'] += 1;
                    
                    $rupStats[$kd]['programs'][$progKey] = ($rupStats[$kd]['programs'][$progKey] ?? 0) + $paguItem;
                    $rupStats[$kd]['package_list'][$progKey][] = [
                        'kd_rup' => $kdRup ?: '-',
                        'nama_paket' => $item['nama_paket'],
                        'pagu' => $paguItem,
                        'tipe' => $item['_tipe'],
                        'mak' => $mak
                    ];
                }
            }

            foreach ($satkerPrograms as $kd => &$codes) {
                usort($codes, function($a, $b) { return strlen($b) - strlen($a); });
            }

            // --- COLLECT ALL UNIQUE SATKERS FROM ALL SOURCES ---
            $allSatkerKeys = array_unique(array_merge(
                array_keys($kegiatanStats),
                array_keys($rupStats)
            ));

            $summary = [];
            foreach ($allSatkerKeys as $kd) {
                $ks = $kegiatanStats[$kd] ?? [
                    'total_pagu' => 0, 
                    'program_list' => [], 
                    'nama_satker' => ($rupStats[$kd]['nama_satker_fallback'] ?? 'Satker Tidak Terdaftar di Master')
                ];
                $rs = $rupStats[$kd] ?? ['pagu' => 0, 'paket' => 0, 'programs' => [], 'package_list' => []];
                
                $progDetails = [];
                // Process programs from Master
                foreach ($ks['program_list'] as $pk => $pData) {
                    $paguRup = $rs['programs'][$pk] ?? 0;
                    $progDetails[] = [
                        'code' => $pk,
                        'name' => $pData['name'],
                        'pagu_master' => $pData['pagu'],
                        'pagu_rup' => $paguRup,
                        'percent' => $pData['pagu'] > 0 ? round(($paguRup / $pData['pagu']) * 100, 2) : 0,
                        'packages' => $rs['package_list'][$pk] ?? []
                    ];
                }

                // Add "UNKNOWN" packages if any (those not matched to a Master program)
                if (!empty($rs['package_list']['UNKNOWN'])) {
                    $paguUnknown = $rs['programs']['UNKNOWN'] ?? 0;
                    $progDetails[] = [
                        'code' => 'UNKNOWN',
                        'name' => 'Paket Lainnya (Tidak Terpetakan ke Program)',
                        'pagu_master' => 0,
                        'pagu_rup' => $paguUnknown,
                        'percent' => 0,
                        'packages' => $rs['package_list']['UNKNOWN']
                    ];
                }

                $summary[] = [
                    'kd_satker' => $kd,
                    'kd_satker_str' => (string)$kd,
                    'nama_satker' => $ks['nama_satker'],
                    'rup_pagu' => $rs['pagu'],
                    'rup_paket' => $rs['paket'],
                    'master_pagu' => $ks['total_pagu'],
                    'percent' => $ks['total_pagu'] > 0 ? round(($rs['pagu'] / $ks['total_pagu']) * 100, 2) : 0,
                    'details' => $progDetails
                ];
            }

            usort($summary, function($a, $b) { return $a['percent'] <=> $b['percent']; });
            cache()->save($cacheKey, $summary, 3600);
        }

        $userRole = trim(strtolower(session()->get('role') ?? ''));
        $userSatker = trim(session()->get('kd_satker') ?? '');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $summary = array_values(array_filter($summary, function($s) use ($userSatker) {
                return $s['kd_satker'] == $userSatker;
            }));
        }

        return view('dashboard/rup_opd', [
            'title' => 'Monitoring Keterumuman RUP',
            'user'  => session()->get(),
            'summary' => $summary
        ]);
    }

    public function getData($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');
        
        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        if ($userRole === 'satker' && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        $data = $builder->findAll();
        
        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
        $formatted = [];
        foreach ($data as $item) {
            $formatted[] = [
                'pagu' => (float)$item['pagu'],
                'kd_satker' => $item['kd_satker'],
                'nama_satker' => $item['nama_satker'],
                'jenis_pengadaan' => ($type === 'penyedia' ? $item['jenis_pengadaan'] : 'Swakelola'),
                $metodeField => $item[$metodeField],
                'volume_pekerjaan' => $item['volume_pekerjaan'],
                'urarian_pekerjaan' => $item['uraian_pekerjaan'],
                'tgl_awal_pemilihan' => ($type === 'penyedia' ? $item['tgl_awal_pemilihan'] : $item['tgl_awal_pelaksanaan']),
                'tgl_akhir_pemilihan' => ($type === 'penyedia' ? $item['tgl_akhir_pemilihan'] : $item['tgl_akhir_pelaksanaan']),
                'kd_rup' => $item['kd_rup'],
                'nama_paket' => $item['nama_paket'],
                'status_umumkan_rup' => $item['status_umumkan_rup']
            ];
        }

        return $this->respond($formatted);
    }

    public function getDatatables($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker  = session()->get('kd_satker');
        $userRole    = strtolower(session()->get('role') ?? '');
        
        $model   = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        $builder = $model->where('tahun', $currentYear);

        // RBAC: paksa filter ke satker user jika role satker/opd
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        } else {
            // Terapkan filter OPD dari dropdown jika user admin/operator
            $opdFilter = $this->request->getGet('opd') ?? '';
            if ($opdFilter && $opdFilter !== 'all') {
                $builder->where('nama_satker', $opdFilter);
            }
        }

        $draw   = $this->request->getGet('draw');
        $start  = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        
        if ($search) {
            $builder->groupStart()->like('nama_paket', $search)->orLike('nama_satker', $search)->orLike('kd_rup', $search)->groupEnd();
        }

        $totalRecords    = $builder->countAllResults(false);
        $recordsFiltered = $totalRecords;
        
        if ($length != -1) $builder->limit($length, $start);
        $data = $builder->get()->getResultArray();

        $mapped = array_map(function($item) use ($type) {
            $item['urarian_pekerjaan'] = $item['uraian_pekerjaan'] ?? ($item['nama_paket'] ?? '-');
            if ($type === 'swakelola') {
                $item['tgl_awal_pemilihan']  = $item['tgl_awal_pelaksanaan']  ?? ($item['tgl_awal_pemilihan']  ?? '-');
                $item['tgl_akhir_pemilihan'] = $item['tgl_akhir_pelaksanaan'] ?? ($item['tgl_akhir_pemilihan'] ?? '-');
            } else {
                $item['tgl_awal_pemilihan']  = $item['tgl_awal_pemilihan']  ?? '-';
                $item['tgl_akhir_pemilihan'] = $item['tgl_akhir_pemilihan'] ?? '-';
            }
            return $item;
        }, $data);

        return $this->response->setJSON([
            'draw'            => intval($draw),
            'recordsTotal'    => $totalRecords,
            'recordsFiltered' => $recordsFiltered,
            'data'            => $mapped
        ]);
    }

    public function comparisons()
    {
        ini_set('memory_limit', '512M');
        $userSatker = trim(session()->get('kd_satker') ?? '');
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        
        $fetchRaw = function($url, $cacheKey) {
            if (!$data = cache($cacheKey)) {
                $client = \Config\Services::curlrequest();
                try {
                    $response = $client->get($url, ['timeout' => 60]);
                    $data = json_decode($response->getBody(), true);
                    if (is_array($data)) {
                        cache()->save($cacheKey, $data, 3600); 
                    } else $data = [];
                } catch (\Exception $e) { $data = []; }
            }
            return is_array($data) ? $data : [];
        };

        $aggregate = function($rawData, $type) use ($userSatker, $userRole) {
            $yearly = [];
            $dist1 = [];
            $dist2 = [];
            $field1 = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
            $field2 = 'jenis_pengadaan';

            foreach ($rawData as $item) {
                // Strict Satker Filtering
                if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
                    $kd = trim($item['kd_satker'] ?? ($item['kode_satker'] ?? ($item['kd_organisasi'] ?? '')));
                    if ($kd != $userSatker) continue;
                }

                // Try all common year fields
                $yr = $item['tahun_anggaran'] ?? ($item['tahun_anggaran_dana'] ?? ($item['tahun'] ?? 'Unknown'));
                if ($yr === 'Unknown' || !$yr) continue;

                if (!isset($yearly[$yr])) $yearly[$yr] = ['pagu' => 0, 'paket' => 0];
                $yearly[$yr]['pagu'] += (float)($item['pagu'] ?? 0);
                $yearly[$yr]['paket'] += 1;

                $cat1 = $item[$field1] ?? 'Lainnya';
                $cat2 = $item[$field2] ?? 'Lainnya';
                if (!$cat1) $cat1 = 'Lainnya';
                if (!$cat2) $cat2 = 'Lainnya';

                if (!isset($dist1[$cat1][$yr])) $dist1[$cat1][$yr] = 0;
                $dist1[$cat1][$yr] += 1;

                if (!isset($dist2[$cat2][$yr])) $dist2[$cat2][$yr] = 0;
                $dist2[$cat2][$yr] += 1;
            }
            ksort($yearly);
            return ['yearly' => $yearly, 'dist1' => $dist1, 'dist2' => $dist2];
        };

        $baseUrl = env('AJIP_API_BASE_URL', 'https://ajip-api.cloud');
        $apiPerbandinganPenyedia = $baseUrl . '/api/data/perbandingan-rup-penyedia';
        $apiPerbandinganSwakelola = $baseUrl . '/api/data/perbandingan-swakelola';

        $rawPenyedia = $fetchRaw($apiPerbandinganPenyedia, "rup_data_perbandingan_penyedia_v3");
        $rawSwakelola = $fetchRaw($apiPerbandinganSwakelola, "rup_data_perbandingan_swakelola_v3");

        $data = [
            'title' => 'Dashboard Perbandingan Tahunan',
            'user'  => session()->get(),
            'statsPenyedia'  => $aggregate($rawPenyedia, 'penyedia'),
            'statsSwakelola' => $aggregate($rawSwakelola, 'swakelola')
        ];

        return view('dashboard/comparisons', $data);
    }

    public function getChartData($id)
    {
        $chartModel = new \App\Models\DashboardChartModel();
        $menuModel = new \App\Models\DynamicMenuModel();
        
        $chart = $chartModel->find($id);
        if (!$chart) return $this->failNotFound('Chart not found');
        
        $menu = $menuModel->find($chart['menu_id']);
        if (!$menu) return $this->failNotFound('Source menu not found');

        // Fetch API data
        $client = \Config\Services::curlrequest();
        try {
            $response = $client->get($menu['api_url']);
            $data = json_decode($response->getBody(), true);
            if (!is_array($data)) return $this->respond([]);

            $results = [];
            if ($chart['aggregation'] === 'count') {
                foreach ($data as $item) {
                    $label = $item[$chart['label_field']] ?? 'N/A';
                    $results[$label] = ($results[$label] ?? 0) + 1;
                }
            } else if ($chart['aggregation'] === 'sum') {
                foreach ($data as $item) {
                    $label = $item[$chart['label_field']] ?? 'N/A';
                    $val = floatval($item[$chart['value_field']] ?? 0);
                    $results[$label] = ($results[$label] ?? 0) + $val;
                }
            }

            // Format for Chart.js
            $output = [
                'labels' => array_keys($results),
                'values' => array_values($results)
            ];

            return $this->respond($output);
        } catch (\Exception $e) {
            return $this->fail($e->getMessage());
        }
    }

    public function export($type, $year)
    {
        $userSatker = session()->get('kd_satker');
        $url = ($type === 'swakelola') ? $this->apiSwakelola : $this->apiPenyedia;
        $cacheKey = ($type === 'swakelola') ? "rup_data_perbandingan_swakelola_v3" : "rup_data_perbandingan_penyedia_v3";
        
        if (!$data = cache($cacheKey)) {
            $client = \Config\Services::curlrequest();
            try {
                $response = $client->get($url, ['timeout' => 60]);
                $data = json_decode($response->getBody(), true);
                if (is_array($data)) cache()->save($cacheKey, $data, 3600);
            } catch (\Exception $e) { $data = []; }
        }

        if (!is_array($data)) return redirect()->back()->with('error', 'Data tidak tersedia.');

        $filtered = array_filter($data, function($item) use ($year, $userSatker) {
            $yr = $item['tahun_anggaran'] ?? ($item['tahun_anggaran_dana'] ?? ($item['tahun'] ?? ''));
            return ($yr == $year) && ($userSatker ? (($item['kd_satker'] ?? '') == $userSatker) : true);
        });

        if (empty($filtered)) return redirect()->back()->with('error', 'Data tahun '.$year.' tidak ditemukan.');

        // Generate CSV
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="RUP_'.$type.'_'.$year.'.csv"');
        
        $output = fopen('php://output', 'w');
        // Add UTF-8 BOM for Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Use keys of the first item as headers
        fputcsv($output, array_keys(reset($filtered)));
        
        foreach ($filtered as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }

    public function exportRupOpd()
    {
        $currentYear = date('Y');
        $cacheKey = "rup_opd_v15_full_db_{$currentYear}"; // Must match rupOpd() cache key
        
        $summary = cache($cacheKey);
        if (!$summary) {
            $this->rupOpd(); // Regenerate cache if missing
            $summary = cache($cacheKey);
        }

        if (!$summary) return redirect()->back()->with('error', 'Gagal memproses data laporan.');

        // Apply strict satker filtering
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        $userSatker = trim(session()->get('kd_satker') ?? '');
        
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $summary = array_values(array_filter($summary, function($s) use ($userSatker) {
                return trim($s['kd_satker'] ?? '') == $userSatker;
            }));
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="Laporan_Keterumuman_RUP_OPD_'.$currentYear.'.csv"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM
        
        fputcsv($output, ['Nama OPD', 'Kode Satker', 'Pagu Master (Kegiatan)', 'Pagu Terumumkan (SIRUP)', 'Jumlah Paket', 'Persentase (%)']);
        
        foreach ($summary as $s) {
            fputcsv($output, [
                $s['nama_satker'],
                $s['kd_satker_str'],
                $s['master_pagu'],
                $s['rup_pagu'],
                $s['rup_paket'],
                $s['percent'] . '%'
            ]);
        }
        
        fclose($output);
        exit;
    }

    public function lpse($type)
    {
        $titles = [
            'tender' => 'Data Tender LPSE',
            'nontender' => 'Data Non Tender LPSE',
            'pencatatan-nontender' => 'Pencatatan Non Tender',
            'pencatatan-swakelola' => 'Pencatatan Swakelola'
        ];

        $db = \Config\Database::connect();
        $years = [];
        if ($type === 'tender') {
            $years = $db->table('lpse_tender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'nontender') {
            $years = $db->table('lpse_nontender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'pencatatan-nontender') {
            $years = $db->table('lpse_pencatatan_nontender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'pencatatan-swakelola') {
            $years = $db->table('lpse_pencatatan_swakelola')->select('tahun')->distinct()->get()->getResultArray();
        }
        $availableYears = array_filter(array_column($years, 'tahun'));
        rsort($availableYears);
        if (empty($availableYears)) {
            $availableYears = [date('Y')];
        }

        return view('dashboard/table_lpse', [
            'title' => $titles[$type] ?? 'Data LPSE',
            'user'  => session()->get(),
            'type'  => $type,
            'availableYears' => $availableYears
        ]);
    }

    public function epurchasing()
    {
        return view('dashboard/dashboard_epurchasing', [
            'title' => 'Dashboard E-Purchasing',
            'user'  => session()->get(),
            'type'  => 'epurchasing'
        ]);
    }

    public function tableEpurchasing()
    {
        return view('dashboard/table_epurchasing', [
            'title' => 'Data Detail E-Purchasing',
            'user'  => session()->get(),
            'type'  => 'epurchasing'
        ]);
    }

    public function getEpurchasingDashboardData()
    {
        $cacheKey = "epurchasing_dashboard_v10";

        if (!$result = cache($cacheKey)) {
            $model = new \App\Models\EpurchasingModel();
            $rows = $model->findAll();
            
            if (!is_array($rows)) $rows = [];

            $history = []; // [year] => [realisasi, count]
            $topSatker = []; // [kd_satker] => [nama, realisasi, count]
            $topVendor = []; // [nama_penyedia] => [realisasi, count]
            $statusSummary = []; // [status] => [realisasi, count]
            $totalRealisasi = 0;
            $totalPackages = 0;
            $otherStatusPackagesCount = 0;

            $currentYearNum = (int)date('Y');
            $monthly = array_fill(1, 12, ['realisasi' => 0, 'count' => 0]); // [month] => [realisasi, count]

            foreach ($rows as $row) {
                $status = strtoupper(str_replace('_', ' ', (string)($row['status'] ?? '')));
                $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
                if (!in_array($status, $allowed)) continue;

                $yr = (int)$row['tahun'];
                if ($yr <= 0) continue;

                $real = (float)($row['total_harga'] ?? 0);
                
                // Status summary aggregation for current active year (includes all 5 statuses)
                if ($yr === $currentYearNum) {
                    if (!isset($statusSummary[$status])) {
                        $statusSummary[$status] = ['count' => 0, 'realisasi' => 0];
                    }
                    $statusSummary[$status]['count'] += 1;
                    $statusSummary[$status]['realisasi'] += $real;

                    if (!in_array($status, ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM'])) {
                        $otherStatusPackagesCount += 1;
                    }
                }

                // Filter out statuses other than ON PROCESS and PAYMENT OUTSIDE SYSTEM for all other dashboard metrics
                if (!in_array($status, ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM'])) {
                    continue;
                }

                // History aggregation (All years for chart - restricted statuses only)
                if (!isset($history[$yr])) $history[$yr] = ['realisasi' => 0, 'count' => 0];
                $history[$yr]['realisasi'] += $real;
                $history[$yr]['count'] += 1;

                // Current Year ONLY for Stats, Top Satker, and Top Vendor
                if ($yr === $currentYearNum) {
                    $totalRealisasi += $real;
                    $totalPackages += 1;

                    // Enrichment from local JSON
                    $kdVendor = trim($row['kode_penyedia'] ?? '');
                    $namaPenyedia = 'Penyedia ID: ' . $kdVendor;
                    
                    if ($kdVendor !== '') {
                        $vFile = WRITEPATH . 'inaproc/vendors/' . $kdVendor . '.json';
                        if (file_exists($vFile)) {
                            $vData = json_decode(file_get_contents($vFile), true);
                            $namaPenyedia = $vData['nama_penyedia'] ?? $namaPenyedia;
                        }
                    }

                    // Satker aggregation
                    $kdSatker = $row['kd_satker'] ?? 'UNKNOWN';
                    if (!isset($topSatker[$kdSatker])) {
                        $topSatker[$kdSatker] = [
                            'nama' => $row['nama_satker'] ?? 'Satker Tidak Diketahui',
                            'realisasi' => 0,
                            'count' => 0
                        ];
                    }
                    $topSatker[$kdSatker]['realisasi'] += $real;
                    $topSatker[$kdSatker]['count'] += 1;

                    // Vendor aggregation
                    if (!isset($topVendor[$namaPenyedia])) {
                        $topVendor[$namaPenyedia] = [
                            'realisasi' => 0,
                            'count' => 0,
                            'packages' => []
                        ];
                    }
                    $topVendor[$namaPenyedia]['realisasi'] += $real;
                    $topVendor[$namaPenyedia]['count'] += 1;
                    
                    $rawDate = $row['order_date'] ?? '';
                    $fmtDate = ($rawDate && strtotime($rawDate)) ? date('d-m-Y', strtotime($rawDate)) : '-';

                    $topVendor[$namaPenyedia]['packages'][] = [
                        'kd_paket' => $row['kd_paket'] ?? '-',
                        'rup_code' => $row['rup_code'] ?? '-',
                        'nama_paket' => $row['nama_paket'] ?? '-',
                        'nama_program' => $row['rup_desc'] ?? '-',
                        'nama_produk' => '-', 
                        'realisasi' => $real,
                        'tgl_order' => $fmtDate,
                        'satker' => $row['nama_satker'] ?? '-',
                        '_kdVendor' => $kdVendor,
                        '_productIds' => trim($row['product_id'] ?? '')
                    ];

                    // Monthly aggregation for current year
                    if ($rawDate) {
                        $month = (int)date('n', strtotime($rawDate));
                        if ($month >= 1 && $month <= 12) {
                            $monthly[$month]['realisasi'] += $real;
                            $monthly[$month]['count'] += 1;
                        }
                    }
                }
            }

            ksort($history);
            uasort($topSatker, function($a, $b) {
                return $b['realisasi'] <=> $a['realisasi'];
            });
            uasort($topVendor, function($a, $b) {
                return $b['count'] <=> $a['count'];
            });

            // Late Enrichment: Only fetch product names from JSON for the Top 10 Vendors to ensure high performance
            $topVendorSlice = array_slice($topVendor, 0, 10, true);
            foreach ($topVendorSlice as $vName => &$vData) {
                foreach ($vData['packages'] as &$pkg) {
                    $kdV = $pkg['_kdVendor'];
                    $pIds = $pkg['_productIds'];
                    if ($kdV !== '' && $pIds !== '') {
                        $actualProduct = $this->_getInaprocProductNames($kdV, $pIds, $pkg['nama_paket']);
                        if ($actualProduct && $actualProduct !== '-') {
                            $pkg['nama_produk'] = $actualProduct;
                        }
                    }
                    unset($pkg['_kdVendor'], $pkg['_productIds']); // Cleanup
                }
            }

            // Generate Leadership Narrative
            $currentYear = date('Y');
            $currStats = $history[$currentYear] ?? ['realisasi' => 0, 'count' => 0];
            $prevYear = (string)($currentYear - 1);
            $prevStats = $history[$prevYear] ?? ['realisasi' => 0, 'count' => 0];
            
            $growth = $prevStats['realisasi'] > 0 ? (($currStats['realisasi'] - $prevStats['realisasi']) / $prevStats['realisasi']) * 100 : 0;
            $topS = !empty($topSatker) ? reset($topSatker) : ['nama' => '-', 'realisasi' => 0];
            $topV = !empty($topVendor) ? reset($topVendor) : ['realisasi' => 0, 'count' => 0];
            
            reset($topVendor);
            $topVName = !empty($topVendor) ? key($topVendor) : '-';

            $narrative = "Analisis Tahun Berjalan (" . $currentYearNum . "): Total realisasi mencapai Rp " . number_format($totalRealisasi, 0, ',', '.') . " dari " . number_format($totalPackages, 0, ',', '.') . " paket. ";
            if ($topVName !== '-') {
                $narrative .= "Satker paling aktif saat ini adalah " . ($topS['nama'] ?? '-') . " dengan realisasi Rp " . number_format($topS['realisasi'] ?? 0, 0, ',', '.') . ". ";
                $narrative .= "Penyedia utama tahun ini adalah " . $topVName . " dengan perolehan " . ($topV['count'] ?? 0) . " paket.";
            }

            $result = [
                'summary' => [
                    'total_realisasi' => $totalRealisasi,
                    'total_packages' => $totalPackages,
                    'other_status_packages' => $otherStatusPackagesCount,
                    'years_count' => count($history),
                    'year_active' => $currentYearNum
                ],
                'history' => $history,
                'monthly' => $monthly,
                'top_satker' => array_slice($topSatker, 0, 10, true),
                'top_vendor' => $topVendorSlice,
                'status_summary' => $statusSummary,
                'report' => [
                    'narrative' => $narrative,
                    'growth' => round($growth, 2),
                    'top_performer' => $topS['nama'] ?? '-',
                    'top_vendor_name' => $topVName
                ]
            ];

            cache()->save($cacheKey, $result, 3600);
        }

        return $this->response->setJSON($result);
    }

    public function dashboardLpse()
    {
        return view('dashboard/dashboard_lpse', [
            'title' => 'Dashboard LPSE',
            'user'  => session()->get(),
        ]);
    }

    public function getDashboardLpseData()
    {
        $yearFilter = $this->request->getGet('year') ?? 'all';
        $cacheKey   = "dashboard_lpse_v19_{$yearFilter}";

        if (!$result = cache($cacheKey)) {
            $client = \Config\Services::curlrequest();

            $sources = [
                'Tender'              => [$this->apiTender,              'tahun_anggaran', 'nilai_kontrak', 'pagu'],
                'Non Tender'          => [$this->apiNonTender,           'tahun_anggaran', 'pagu',          'pagu'],
                'Pencatatan Non Tender' => [$this->apiPencatatanNonTender,'tahun_anggaran','nilai_realisasi','pagu'],
                'Pencatatan Swakelola'  => [$this->apiListPencatatanSwakelola,'tahun_anggaran','nilai_realisasi','pagu'],
            ];

            $allYears  = [];
            $byYear    = []; // [type][year] => [pagu, count]
            $totalPagu = []; // [type] => pagu
            $totalRealisasi = []; // [type] => realisasi
            $byJenis   = []; // [jenis_pengadaan][year] => [pagu, count]
            $totalJenis = []; // [jenis_pengadaan] => pagu
            $seenPackages = []; // [label][year][id] => true
            
            // Pre-fetch Non-Tender Selesai map for accurate Realisasi values
            $nontenderSelesaiMap = [];
            try {
                $resSelesai = $client->get($this->apiNonTenderSelesai, ['timeout' => 30]);
                $rowsSelesai = json_decode($resSelesai->getBody(), true);
                if (is_array($rowsSelesai)) {
                    foreach ($rowsSelesai as $s) {
                        $sid = $s['kd_nontender'] ?? ($s['kd_paket'] ?? null);
                        if ($sid) $nontenderSelesaiMap[$sid] = (float)($s['nilai_kontrak'] ?? ($s['nilai_pemenang'] ?? 0));
                    }
                }
            } catch (\Exception $e) {}
            
            // Pre-fetch Tender e-Kontrak map for final values
            $tenderEkontrakMap = [];
            try {
                $resEkontrak = $client->get($this->apiTenderEkontrak, ['timeout' => 60]);
                $rowsEkontrak = json_decode($resEkontrak->getBody(), true);
                if (is_array($rowsEkontrak)) {
                    foreach ($rowsEkontrak as $ek) {
                        $kd = trim((string)($ek['kd_tender'] ?? ($ek['kd_paket'] ?? '')));
                        $rup = trim((string)($ek['kd_rup'] ?? ''));
                        
                        if ($kd !== '') $tenderEkontrakMap[$kd] = $ek;
                        if ($rup !== '') $tenderEkontrakMap['rup_' . $rup] = $ek;
                    }
                }
            } catch (\Exception $e) {}

            // Pre-fetch Swakelola Realisasi map (Sum of all payments per package)
            $swakelolaRealMap = [];
            $swakelolaYearMap = []; // Map package ID to year since list API lacks year
            try {
                $resSw = $client->get($this->apiPencatatanSwakelolaRealisasi, ['timeout' => 90]);
                $rowsSw = json_decode($resSw->getBody(), true);
                if (is_array($rowsSw)) {
                    foreach ($rowsSw as $s) {
                        $sid = trim((string)($s['kd_swakelola_pct'] ?? ($s['kd_swakelola'] ?? ($s['kd_paket'] ?? ''))));
                        if ($sid !== '') {
                            if (!isset($swakelolaRealMap[$sid])) $swakelolaRealMap[$sid] = 0;
                            $swakelolaRealMap[$sid] += (float)($s['nilai_realisasi'] ?? ($s['realisasi'] ?? 0));
                            
                            $syr = (string)($s['tahun_anggaran'] ?? ($s['tahun'] ?? ''));
                            if ($syr) $swakelolaYearMap[$sid] = $syr;
                        }
                    }
                }
            } catch (\Exception $e) {}

            foreach ($sources as $label => [$url, $yearField, $valueField, $paguField]) {
                try {
                    $res  = $client->get($url, ['timeout' => 90]);
                    $rows = json_decode($res->getBody(), true);
                    if (!is_array($rows)) $rows = [];
                } catch (\Exception $e) { $rows = []; }

                foreach ($rows as $row) {
                    $pkgId = $row['kd_nontender_pct'] ?? ($row['kd_swakelola_pct'] ?? ($row['kd_nontender'] ?? ($row['kd_tender'] ?? ($row['kd_paket'] ?? ($row['kode_paket'] ?? null)))));
                    $cleanPkgId = trim((string)$pkgId);

                    // Restricted Statuses for E-Purchasing
                    if ($label === 'E-Purchasing') {
                        $status = strtoupper(str_replace('_', ' ', (string)($row['status'] ?? '')));
                        $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
                        if (!in_array($status, $allowed)) continue;

                        // Priority 1: order_date year
                        $rawDate = $row['order_date'] ?? '';
                        $yr = (strlen($rawDate) >= 4) ? substr($rawDate, 0, 4) : '';
                        
                        // Priority 2: fallback to other fields
                        if (!$yr) {
                            $yr = (string)($row['fiscal_year'] ?? ($row['tahun_anggaran'] ?? ($row['tahun'] ?? '')));
                        }
                    } else {
                        $yr = (string)($row['fiscal_year'] ?? ($row[$yearField] ?? ($row['tahun'] ?? ($row['tahun_anggaran_paket'] ?? ($row['tahun_paket'] ?? '')))));
                    }
                    
                    // If yr is still a full date string, extract year
                    if (strlen($yr) > 4 && strpos($yr, '-') !== false) {
                        $yr = substr($yr, 0, 4);
                    }
                    
                    // Fallback year for Swakelola from the realisasi map
                    if (!$yr && $cleanPkgId !== '' && isset($swakelolaYearMap[$cleanPkgId])) {
                        $yr = $swakelolaYearMap[$cleanPkgId];
                    }
                    
                    // Final fallback: if no year, assume current year for dashboard summary if it matches label
                    if (!$yr || !is_numeric($yr)) {
                        $yr = date('Y');
                    }

                    if ($yearFilter !== 'all' && (string)$yr !== (string)$yearFilter) continue;

                    // Deteksi Pagu (Anggaran) - Sangat Exhaustive
                    $pagu = (float)($row['pagu'] ?? ($row['Pagu'] ?? ($row['nilai_pagu'] ?? ($row['total_pagu'] ?? ($row['jumlah_pagu'] ?? ($row['pagu_rup'] ?? ($row['nilai_pagu_paket'] ?? ($row['nilai_pekerjaan'] ?? ($row['hps'] ?? ($row[$paguField] ?? 0))))))))));
                    
                    // Deteksi Realisasi (Penyerapan)
                    $nilaiTerkoreksi = (float)($row['nilai_terkoreksi'] ?? 0);
                    $nilaiNegosiasi = (float)($row['nilai_negosiasi'] ?? 0);
                    $realisasi = (float)($row['nilai_kontrak'] ?? ($row['nilai_pemenang'] ?? ($row['nilai_realisasi'] ?? ($row['realisasi'] ?? 0))));
                    if ($realisasi <= 0) $realisasi = ($nilaiTerkoreksi > 0) ? $nilaiTerkoreksi : $nilaiNegosiasi;
                    
                    // Fallback Pagu khusus untuk Pencatatan: Jika Pagu tetap 0, gunakan Realisasi sebagai Pagu minimum
                    if ($pagu <= 0 && stripos($label, 'Pencatatan') !== false) {
                        $pagu = $realisasi;
                    }
                    
                    // Identify unique package ID for deduplication and mapping
                    $pkgId = $row['kd_nontender_pct'] ?? ($row['kd_swakelola_pct'] ?? ($row['kd_nontender'] ?? ($row['kd_tender'] ?? ($row['kd_paket'] ?? ($row['kode_paket'] ?? null)))));

                    // Smart Mapping: Non-Tender (from previous logic)
                    if (stripos($label, 'Non Tender') !== false && $pkgId && isset($nontenderSelesaiMap[$pkgId])) {
                        $realisasi = $nontenderSelesaiMap[$pkgId];
                    }

                    // Smart Mapping: Tender e-Kontrak (Final Values)
                    if (stripos($label, 'Tender') !== false) {
                        $ek = $tenderEkontrakMap[$cleanPkgId] ?? ($tenderEkontrakMap['rup_' . trim((string)($row['rup_code'] ?? ($row['kd_rup'] ?? '')))] ?? []);
                        $hargaFinal = (float)($ek['harga_final'] ?? 0);
                        if ($hargaFinal > 0) {
                            $realisasi = $hargaFinal;
                        }
                    }
                    
                    // Smart Mapping: Swakelola (Match list with realisasi API)
                    $cleanPkgId = trim((string)$pkgId);
                    if (stripos($label, 'Swakelola') !== false && $cleanPkgId !== '' && isset($swakelolaRealMap[$cleanPkgId])) {
                        $realisasi = $swakelolaRealMap[$cleanPkgId];
                    }
                    
                    // Fallback to pagu if no contract value found at all
                    if ($realisasi <= 0) $realisasi = (float)($row[$valueField] ?? 0);

                    // Exclude tender if there is no winner, no contract value, or status is not completed
                    if (stripos($label, 'Tender') !== false) {
                        $ek = $tenderEkontrakMap[$cleanPkgId] ?? ($tenderEkontrakMap['rup_' . trim((string)($row['rup_code'] ?? ($row['kd_rup'] ?? '')))] ?? []);
                        $pemenangName = trim($row['nama_penyedia'] ?? ($row['pemenang'] ?? ($ek['nama_penyedia'] ?? '')));
                        
                        $status = $row['status_nontender_pct_ket'] ?? ($row['status_paket'] ?? ($row['status'] ?? ($row['tahapan'] ?? ($row['status_tender'] ?? ($row['status_nontender'] ?? ($row['status_realisasi'] ?? ($row['keterangan'] ?? 'Selesai')))))));
                        
                        if ($pemenangName === '' || $realisasi <= 0 || stripos($status, 'selesai') === false) {
                            continue;
                        }
                    }

                    $allYears[$yr] = true;

                    // Deduplication Logic: Pagu is counted once, Realisasi is summed
                    $isNewPackage = true;
                    if ($pkgId) {
                        if (isset($seenPackages[$label][$yr][$pkgId])) {
                            $isNewPackage = false;
                        }
                        $seenPackages[$label][$yr][$pkgId] = true;
                    }

                    // Filter: Only "Selesai" for Non-Tender categories
                    $status = $row['status_nontender_pct_ket'] ?? ($row['status_paket'] ?? ($row['status'] ?? ($row['tahapan'] ?? ($row['status_tender'] ?? ($row['status_nontender'] ?? ($row['status_realisasi'] ?? ($row['keterangan'] ?? 'Selesai')))))));
                    if (stripos($label, 'Non Tender') !== false) {
                        if (stripos($status, 'selesai') === false) continue;
                    }

                    if (!isset($byYear[$label][$yr])) $byYear[$label][$yr] = ['pagu' => 0, 'realisasi' => 0, 'count' => 0];
                    if ($isNewPackage) {
                        $byYear[$label][$yr]['pagu'] += $pagu;
                        $byYear[$label][$yr]['count'] += 1;
                        if (!isset($totalPagu[$label])) $totalPagu[$label] = 0;
                        $totalPagu[$label] += $pagu;
                        
                        $byYear[$label][$yr]['realisasi'] += $realisasi;
                        if (!isset($totalRealisasi[$label])) $totalRealisasi[$label] = 0;
                        $totalRealisasi[$label] += $realisasi;
                    }

                    // Aggregate by jenis_pengadaan
                    $jenis = $row['jenis_pengadaan'] ?? ($row['kgr_nama'] ?? ($row['kategori'] ?? ''));
                    if (!$jenis) $jenis = 'Lainnya';

                    if (!isset($byJenis[$jenis][$yr])) $byJenis[$jenis][$yr] = ['pagu' => 0, 'realisasi' => 0, 'count' => 0];
                    if ($isNewPackage) {
                        $byJenis[$jenis][$yr]['pagu'] += $pagu;
                        $byJenis[$jenis][$yr]['count'] += 1;
                        if (!isset($totalJenis[$jenis])) $totalJenis[$jenis] = ['pagu' => 0, 'realisasi' => 0];
                        $totalJenis[$jenis]['pagu'] += $pagu;
                    }
                    $byJenis[$jenis][$yr]['realisasi'] += $realisasi;
                    if (!isset($totalJenis[$jenis])) $totalJenis[$jenis] = ['pagu' => 0, 'realisasi' => 0];
                    $totalJenis[$jenis]['realisasi'] += $realisasi;
                }
            }

            // Sort jenis by total pagu descending
            uasort($totalJenis, function($a, $b) {
                return $b['pagu'] <=> $a['pagu'];
            });

            ksort($allYears);
            $years = array_keys($allYears);

            $result = [
                'years'           => $years,
                'labels'          => array_keys($sources),
                'by_year'         => $byYear,
                'total_pagu'      => $totalPagu,
                'total_realisasi' => $totalRealisasi,
                'jenis_labels'    => array_keys($totalJenis),
                'by_jenis'        => $byJenis,
                'total_jenis'     => $totalJenis,
            ];

            cache()->save($cacheKey, $result, 1800);
        }

        return $this->response->setJSON($result);
    }

    public function getEpurchasingDatatables()
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');

        $cacheKey = "epurchasing_data_v100_{$currentYear}";

        if (!$allData = cache($cacheKey)) {
            $model = new \App\Models\EpurchasingModel();
            
            if ($currentYear !== 'all') {
                $raw = $model->where('tahun', $currentYear)->findAll();
            } else {
                $raw = $model->findAll();
            }

            if (!is_array($raw) || empty($raw)) {
                $allData = [];
            } else {
                $allData = [];
                foreach ($raw as $item) {
                    // Restricted Statuses for E-Purchasing (Flexible Check)
                    $status = strtoupper(str_replace('_', ' ', (string)($item['status'] ?? '')));
                    $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
                    if (!in_array($status, $allowed)) continue;

                    $allData[] = [
                        'no_referensi'   => $item['kd_paket'] ?? '-',
                        'nama_paket'     => $item['nama_paket'] ?? '-',
                        'nama_program'   => $item['rup_desc'] ?? '-',
                        'nama_produk'    => $item['rup_desc'] ?? '-', // Default, enriched later
                        'nama_penyedia'  => $item['nama_penyedia'] ?? null, // Use stored DB value (null means "enrich later")
                        'kode_penyedia'  => trim($item['kode_penyedia'] ?? ''),
                        'product_id'     => trim($item['product_id'] ?? ''),
                        'nama_satker'    => $item['nama_satker'] ?? '-',
                        'kd_satker'      => $item['kd_satker'] ?? '',
                        'pagu'           => (float)($item['total_harga'] ?? 0),
                        'sumber_dana'    => $item['sumber_dana'] ?? '-',
                        'jumlah'         => (int)($item['total_qty'] ?? 0),
                        'satuan'         => 'Unit',
                        'tanggal'        => $item['order_date'] ?? '-',
                        'fiscal_year'    => $item['tahun'] ?? '-',
                        'status'         => $status,
                        'shipment_status'=> $item['shipment_status'] ?? '-',
                        'rup_code'       => $item['rup_code'] ?? '-',
                    ];

                }

                if (!empty($allData)) {
                    cache()->save($cacheKey, $allData, 3600);
                }
            }
        }

        // RBAC filter
        if ($userRole === 'satker' && $userSatker) {
            $allData = array_values(array_filter($allData, function($item) use ($userSatker) {
                return ($item['kd_satker'] ?? '') == $userSatker;
            }));
        }

                // Jika user role satker, paksa filter ke satker miliknya
        if ($userRole === 'satker' && $userSatker) {
            $satkerFilter = $userSatker;
        }
        $satkerFilter = $this->request->getGet('satker_filter') ?? '';
        if ($satkerFilter) {
            $allData = array_values(array_filter($allData, function($item) use ($satkerFilter) {
                return ($item['nama_satker'] ?? '') == $satkerFilter;
            }));
        }

        // DataTables parameters
        $draw = $this->request->getGet('draw');
        $start = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        $statusFilter = $this->request->getGet('status_filter') ?? '';
        $order = $this->request->getGet('order');

        $totalRecords = count($allData);

        // Filter by status
        if ($statusFilter) {
            $allData = array_values(array_filter($allData, function($item) use ($statusFilter) {
                return strcasecmp($item['status'] ?? '', $statusFilter) === 0;
            }));
        }

        // Search
        if ($search) {
            $allData = array_values(array_filter($allData, function($item) use ($search) {
                return stripos($item['nama_paket'] ?? '', $search) !== false ||
                       stripos($item['nama_satker'] ?? '', $search) !== false ||
                       stripos($item['no_referensi'] ?? '', $search) !== false ||
                       stripos($item['kode_penyedia'] ?? '', $search) !== false ||
                       stripos($item['product_id'] ?? '', $search) !== false;
            }));
        }

        $filteredRecords = count($allData);

        // Sorting
        if (!empty($order)) {
            $colIdx = $order[0]['column'];
            $dir = $order[0]['dir'];
            $cols = $this->request->getGet('columns');
            $colName = $cols[$colIdx]['data'] ?? null;

            if ($colName) {
                usort($allData, function($a, $b) use ($colName, $dir) {
                    $valA = $a[$colName] ?? '';
                    $valB = $b[$colName] ?? '';
                    if (is_numeric($valA) && is_numeric($valB)) return ($dir === 'asc') ? ($valA <=> $valB) : ($valB <=> $valA);
                    return ($dir === 'asc') ? strnatcasecmp((string)$valA, (string)$valB) : strnatcasecmp((string)$valB, (string)$valA);
                });
            }
        }

        // Pagination
        $data = ($length == -1) ? $allData : array_slice($allData, $start, $length);

        // ENRICH visible rows only (Fast)
        // Priority: 1) DB stored nama_penyedia  2) Local JSON cache  3) Inaproc API (live)
        foreach ($data as &$item) {
            // 1. Use stored value from DB if available
            if (!empty($item['nama_penyedia'])) {
                // Already set from DB — also enrich product name if needed
                $kdVendor   = $item['kode_penyedia'];
                $prodIdsStr = $item['product_id'];
                if ($kdVendor !== '' && $prodIdsStr !== '') {
                    $item['nama_produk'] = $this->_getInaprocProductNames($kdVendor, $prodIdsStr, $item['nama_paket']);
                }
                continue;
            }

            // 2. Fallback: lookup from JSON cache / Inaproc API
            $kdVendor   = $item['kode_penyedia'];
            $prodIdsStr = $item['product_id'];
            if ($kdVendor !== '') {
                $item['nama_penyedia'] = $this->_getInaprocVendorName($kdVendor);
                if ($prodIdsStr !== '') {
                    $item['nama_produk'] = $this->_getInaprocProductNames($kdVendor, $prodIdsStr, $item['nama_paket']);
                }
            }
        }


        // Final result with unique statuses metadata
        $uniqueStatuses = array_values(array_unique(array_column($allData, 'status')));

        return $this->response->setJSON([
            'draw' => intval($draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'unique_statuses' => $uniqueStatuses,
            'data' => array_values($data)
        ]);
    }

    public function getLpseDatatables($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');
        
        $models = [
            'tender' => new \App\Models\LpseTenderModel(),
            'nontender' => new \App\Models\LpseNontenderModel(),
            'pencatatan-nontender' => new \App\Models\LpsePencatatanNontenderModel(),
            'pencatatan-swakelola' => new \App\Models\LpsePencatatanSwakelolaModel()
        ];

        $model = $models[$type] ?? null;
        if (!$model) return $this->response->setJSON(['data' => []]);

        // Build base query — only filter by year if not 'all'
        $builder = $model->builder();
        if ($currentYear && $currentYear !== 'all') {
            $builder->where('tahun', (int)$currentYear);
        }

        // RBAC: satker/opd filter
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        // Apply status filter from frontend
        $statusFilter = $this->request->getGet('status') ?? '';
        if ($statusFilter && $statusFilter !== 'all') {
            $builder->where('status', $statusFilter);
        }

        // Apply opd filter from frontend (for swakelola mostly)
        $opdFilter = $this->request->getGet('opd') ?? '';
        if ($opdFilter && $opdFilter !== 'all') {
            $builder->where('nama_satker', $opdFilter);
        }

        // Apply jenis_pengadaan filter (for tender/nontender)
        $jenisPengadaanFilter = $this->request->getGet('jenis_pengadaan') ?? '';
        if ($jenisPengadaanFilter && $jenisPengadaanFilter !== 'all') {
            $builder->where('jenis_pengadaan', $jenisPengadaanFilter);
        }

        // Apply jenis filter (for pencatatan types)
        $jenisFilter = $this->request->getGet('jenis') ?? '';
        if ($jenisFilter && $jenisFilter !== 'all') {
            if ($type === 'pencatatan-nontender') {
                $builder->where('jenis_realisasi', $jenisFilter);
            } elseif ($type === 'pencatatan-swakelola') {
                $builder->where('jenis_realisasi', $jenisFilter);
            }
        }

        $draw   = $this->request->getGet('draw');
        $start  = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        
        if ($search) {
            $builder->groupStart()
                    ->like('nama_paket', $search)
                    ->orLike('nama_satker', $search)
                    ->orLike('kd_rup', $search)
                    ->orLike('kd_paket', $search)
                    ->orLike('tahun', $search);
            
            if ($type === 'pencatatan-swakelola') {
                $builder->orLike('nama_pelaksana', $search)
                        ->orLike('jenis_realisasi', $search)
                        ->orLike('status', $search);
            } elseif ($type === 'pencatatan-nontender') {
                $builder->orLike('nama_penyedia', $search)
                        ->orLike('jenis_realisasi', $search)
                        ->orLike('status', $search);
            } elseif ($type === 'tender' || $type === 'nontender') {
                $builder->orLike('nama_penyedia', $search)
                        ->orLike('jenis_pengadaan', $search)
                        ->orLike('status', $search);
            }
            $builder->orLike('pagu', $search);
            $builder->groupEnd();
        }

        // Total records (unfiltered except year + satker)
        $totalBuilder = $model->builder();
        if ($currentYear && $currentYear !== 'all') {
            $totalBuilder->where('tahun', (int)$currentYear);
        }
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $totalBuilder->where('kd_satker', $userSatker);
        }
        $totalRecords = $totalBuilder->countAllResults(false);

        $recordsFiltered = $builder->countAllResults(false);
        
        if ($length != -1) $builder->limit($length, $start);
        $data = $builder->get()->getResultArray();

        return $this->response->setJSON([
            'draw' => intval($draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data
        ]);
    }

    public function clearCache()
    {
        cache()->clean();
        return redirect()->back()->with('success', 'Berhasil membersihkan cache. Seluruh data akan ditarik ulang dari API.');
    }

    private function _getInaprocVendorName($kode)
    {
        $dir = WRITEPATH . 'inaproc/vendors/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file = $dir . $kode . '.json';

        if (file_exists($file)) {
            $saved = json_decode(file_get_contents($file), true);

            // Return cached name (even if null/not-found)
            if (array_key_exists('nama_penyedia', $saved)) {
                // If marked as not-found, only retry after 24 hours
                if (!empty($saved['_not_found'])) {
                    $lastAttempt = strtotime($saved['_last_attempt'] ?? '2000-01-01');
                    if ((time() - $lastAttempt) < 86400) {
                        // Still within 24h cooldown — return full kode as fallback
                        return $kode;
                    }
                    // Retry after 24h — fall through to API call below
                } else {
                    return $saved['nama_penyedia'] ?? '-';
                }
            }
        }

        $client = \Config\Services::curlrequest();
        $token = getenv('INAPROC_BEARER_TOKEN') ?: 'inprc73221b186ad14d568b02f22b214c9574';
        try {
            $url = "https://data.inaproc.id/api/legacy/ekatalog/penyedia-detail?kode_penyedia={$kode}";
            $res = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                ],
                'timeout' => 10
            ]);
            $body = json_decode($res->getBody(), true);
            // Legacy endpoint returns direct array [{...}]; v1 returns {"data":[{...}]}
            $vendor = $body[0] ?? ($body['data'][0] ?? null);
            if (is_array($vendor) && isset($vendor['nama_penyedia'])) {
                $name = $vendor['nama_penyedia'];
                file_put_contents($file, json_encode(['nama_penyedia' => $name, '_synced_at' => date('Y-m-d H:i:s')]));
                return $name;
            }
        } catch (\Exception $e) {}

        // API call failed or returned no data — save a not-found marker
        // This prevents hammering the API on every page load
        file_put_contents($file, json_encode([
            'nama_penyedia' => null,
            '_not_found'    => true,
            '_last_attempt' => date('Y-m-d H:i:s'),
        ]));
        return $kode;
    }

    private function _getInaprocProductNames($kodePenyedia, $prodIdsStr, $namaPaket = '')
    {
        $dir = WRITEPATH . 'inaproc/products/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file = $dir . $kodePenyedia . '.json';

        $prodMap = [];
        if (file_exists($file)) {
            $prodMap = json_decode(file_get_contents($file), true) ?: [];
        }

        $searchIds = array_map('trim', explode(',', $prodIdsStr));
        $missingIds = [];
        foreach ($searchIds as $sid) {
            if (!isset($prodMap[$sid])) $missingIds[] = $sid;
        }

        // If we have missing IDs and the file is old or non-existent, fetch from API
        if (!empty($missingIds)) {
            $client = \Config\Services::curlrequest();
            $token = getenv('INAPROC_BEARER_TOKEN') ?: 'inprc73221b186ad14d568b02f22b214c9574';
            try {
                $url = "https://data.inaproc.id/api/v1/ekatalog/list-produk-penyedia?kode_penyedia={$kodePenyedia}&limit=1000";
                $res = $client->get($url, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token,
                        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    ],
                    'timeout' => 15
                ]);
                $body = json_decode($res->getBody(), true);
                if (isset($body['data']) && is_array($body['data'])) {
                    foreach ($body['data'] as $p) {
                        $pid = $p['kd_produk'] ?? null;
                        $pname = $p['nama_produk'] ?? null;
                        if ($pid) $prodMap[$pid] = $pname;
                    }
                    file_put_contents($file, json_encode($prodMap, JSON_UNESCAPED_UNICODE));
                }
            } catch (\Exception $e) {}
        }

        $found = [];
        $hasNewFallback = false;
        foreach ($searchIds as $sid) {
            if (isset($prodMap[$sid])) {
                $found[] = $prodMap[$sid];
            } else {
                $fallback = $sid;
                if (!empty($namaPaket)) {
                    if (preg_match('/\(([^)]+)\)/', $namaPaket, $matches)) {
                        $fallback = trim($matches[1]);
                    } else {
                        $fallback = $namaPaket;
                    }
                }
                $prodMap[$sid] = $fallback;
                $hasNewFallback = true;
                $found[] = $fallback;
            }
        }

        if ($hasNewFallback) {
            file_put_contents($file, json_encode($prodMap, JSON_UNESCAPED_UNICODE));
        }

        return count($found) > 0 ? implode(', ', $found) : '-';
    }
}
