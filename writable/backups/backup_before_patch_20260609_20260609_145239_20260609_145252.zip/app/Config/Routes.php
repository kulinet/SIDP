<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::index');
$routes->get('auth', 'Auth::index');
$routes->post('auth/login', 'Auth::login');
$routes->get('auth/logout', 'Auth::logout');

$routes->group('dashboard', ['filter' => ['auth', 'rbac']], function($routes) {
    $routes->get('/', 'Dashboard::index');
    $routes->get('layanan', 'Dashboard::layanan');
    $routes->get('statistik', 'Dashboard::statistik');
    $routes->get('comparisons', 'Dashboard::comparisons');
    $routes->get('penyedia', 'Dashboard::penyedia');
    $routes->get('swakelola', 'Dashboard::swakelola');
    $routes->get('rup-opd', 'Dashboard::rupOpd');
    $routes->get('monev-proyek', 'Dashboard::monevProyek');
    $routes->get('monev-summary', 'Dashboard::monevSummary');
    $routes->get('export-monev-summary', 'Dashboard::exportMonevSummary');
    $routes->get('getData/(:any)', 'Dashboard::getData/$1');
    $routes->get('getDashboardSummary/(:any)', 'Dashboard::getDashboardSummary/$1');
    $routes->get('getDatatables/(:any)', 'Dashboard::getDatatables/$1');
    $routes->get('getFilterOptions/(:any)', 'Dashboard::getFilterOptions/$1');
    
    // Data Pengadaan Routes
    $routes->get('lpse/(:any)', 'Dashboard::lpse/$1');
    $routes->get('epurchasing', 'Dashboard::epurchasing');
    $routes->get('table-epurchasing', 'Dashboard::tableEpurchasing');
    $routes->get('dashboard-lpse', 'Dashboard::dashboardLpse');
    $routes->get('getDashboardLpseData', 'Dashboard::getDashboardLpseData');
    $routes->get('getEpurchasingDashboardData', 'Dashboard::getEpurchasingDashboardData');
    $routes->get('getLpseDatatables/(:any)', 'Dashboard::getLpseDatatables/$1');
    $routes->get('getEpurchasingDatatables', 'Dashboard::getEpurchasingDatatables');
    $routes->get('getChartData/(:num)', 'Dashboard::getChartData/$1');
    $routes->get('export/(:any)/(:num)', 'Dashboard::export/$1/$2');
    $routes->get('export-rup-opd', 'Dashboard::exportRupOpd');
    $routes->get('clear-cache', 'Dashboard::clearCache');
    
    // PPK Claiming Routes
    $routes->get('get-rup-details/(:segment)', 'Dashboard::getRupDetails/$1');
    $routes->post('add-monev-paket', 'Dashboard::addMonevPaket');
    $routes->post('remove-monev-paket/(:segment)', 'Dashboard::removeMonevPaket/$1');

    // PPK Monev Proyek Routes
    $routes->post('monev/setup-proyek', 'Dashboard::saveMonevProyek');
    $routes->post('monev/save-jadwal', 'Dashboard::saveMonevJadwal');
    $routes->post('monev/add-harian', 'Dashboard::saveMonevHarian');
    $routes->post('monev/verify-harian/(:num)', 'Dashboard::verifyMonevHarian/$1');
    $routes->post('monev/upload-dokumen', 'Dashboard::saveMonevDokumen');
    $routes->get('monev/get-chart-data/(:num)', 'Dashboard::getMonevChartData/$1');
    $routes->post('monev/delete-proyek/(:num)', 'Dashboard::deleteMonevProyek/$1');
    $routes->post('monev/weekly-ai-analysis', 'Dashboard::generateWeeklyAiAnalysis');
    $routes->post('analyze-anomaly', 'Dashboard::analyzeAnomaly');
    $routes->post('analyze-epurchasing', 'Dashboard::analyzeEpurchasing');
});

$routes->get('alter-db', 'Dashboard::alterDb');

$routes->group('report', ['filter' => ['auth', 'rbac']], function($routes) {
    $routes->get('/', 'Report::index');
    $routes->get('getSummaryData', 'Report::getSummaryData');
});


$routes->group('user', ['filter' => ['auth', 'admin']], function($routes) {
    $routes->get('/', 'UserController::index');
    $routes->get('create', 'UserController::create');
    $routes->post('store', 'UserController::store');
    $routes->get('edit/(:any)', 'UserController::edit/$1');
    $routes->post('update/(:any)', 'UserController::update/$1');
    $routes->get('delete/(:any)', 'UserController::delete/$1');
    
    // Custom Permissions per User
    $routes->get('permissions/(:any)', 'UserPermissionController::index/$1');
    $routes->post('permissions/save/(:any)', 'UserPermissionController::save/$1');
    $routes->post('permissions/reset/(:any)', 'UserPermissionController::reset/$1');
    $routes->get('logs', 'UserLogController::index');
    $routes->get('logs/getDatatables', 'UserLogController::getDatatables');
    $routes->post('logs/clear', 'UserLogController::clear');
    
    // Chatbot Settings
    $routes->get('chatbot-settings', 'SettingsController::chatbot');
    $routes->post('chatbot-settings/save', 'SettingsController::saveChatbot');
    
    // Chatbot Knowledge RAG
    $routes->get('chatbot-knowledge', 'ChatbotKnowledge::index');
    $routes->post('chatbot-knowledge/upload', 'ChatbotKnowledge::upload');
    $routes->post('chatbot-knowledge/delete', 'ChatbotKnowledge::delete');
    
    // API Security Settings
    $routes->get('api-settings', 'SettingsController::api');
    $routes->post('api-settings/generate', 'SettingsController::generateToken');

    // Sync Management
    $routes->get('sync', 'SettingsController::sync');
    $routes->get('do-sync/(:any)', 'SettingsController::doSync/$1');

    // RBAC Management
    $routes->get('rbac', 'RbacController::index');
    $routes->post('rbac/save', 'RbacController::save');
});

$routes->group('development', ['filter' => ['auth', 'operator']], function($routes) {
    $routes->get('/', 'Development::index');
    $routes->get('create', 'Development::create');
    $routes->post('store', 'Development::store');
    $routes->get('edit/(:num)', 'Development::edit/$1');
    $routes->post('update/(:num)', 'Development::update/$1');
    $routes->get('delete/(:num)', 'Development::delete/$1');
    $routes->post('addColumn/(:num)', 'Development::addColumn/$1');
    $routes->get('deleteColumn/(:num)', 'Development::deleteColumn/$1');
    $routes->post('fetchApiKeys', 'Development::fetchApiKeys');
    
    // Charts
    $routes->get('charts', 'Development::charts');
    $routes->post('storeChart', 'Development::storeChart');
    $routes->post('updateChart/(:num)', 'Development::updateChart/$1');
    $routes->get('deleteChart/(:num)', 'Development::deleteChart/$1');

    // System Patcher
    $routes->get('patch', 'PatchController::index');
    $routes->post('patch/upload', 'PatchController::upload');
    $routes->get('patch/rollback/(:any)', 'PatchController::rollback/$1');
    $routes->get('patch/delete-backup/(:any)', 'PatchController::deleteBackup/$1');
    $routes->get('patch/generate', 'PatchController::generate');
    $routes->post('patch/download', 'PatchController::downloadPatch');
});

$routes->group('dynamic', ['filter' => ['auth', 'dynamic_access']], function($routes) {
    $routes->get('getDatatables/(:any)', 'DynamicData::getDatatables/$1');
    $routes->get('(:any)', 'DynamicData::view/$1');
});

// Chatbot Route
$routes->post('chatbot/ask', 'Chatbot::ask');

/**
 * Mobile App API Routes
 * Accessed via /api/...
 */
$routes->group('api', function($routes) {
    $routes->post('login', 'Api::login');
    $routes->get('summary', 'Api::getSummary');
    $routes->get('monev-summary', 'Api::getMonevSummary');
    $routes->get('lpse/(:segment)', 'Api::getLpse/$1');
    $routes->get('rup-opd', 'Api::getRupOpd');
    $routes->post('chatbot/ask', 'Chatbot::ask'); // Also accessible via API
});
