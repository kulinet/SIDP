<?= $this->extend(service('request')->getUserAgent()->isMobile() ? 'layout/mobile_main' : 'layout/main') ?>
<?= $this->section('content') ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <h4 class="fw-bold py-3 mb-0">
            <span class="text-muted fw-light">Data Pengadaan /</span> Monev OPD
        </h4>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <select id="yearFilter" class="form-select form-select-sm" style="width: 100px;">
                <?php for($y = date('Y'); $y >= 2020; $y--): ?>
                    <option value="<?= $y ?>" <?= $y == date('Y') ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <button id="btnFilter" class="btn btn-sm btn-primary">
                <i class="bx bx-filter-alt me-1"></i> Filter
            </button>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div class="card card-border-shadow-primary h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-2 pb-1">
                        <div class="avatar me-2">
                            <span class="avatar-initial rounded bg-label-primary"><i class="bx bx-buildings"></i></span>
                        </div>
                        <h4 class="ms-1 mb-0" id="valTotalOpd">0</h4>
                    </div>
                    <p class="mb-1 fw-semibold">Total OPD</p>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div class="card card-border-shadow-info h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-2 pb-1">
                        <div class="avatar me-2">
                            <span class="avatar-initial rounded bg-label-info"><i class="bx bx-money"></i></span>
                        </div>
                        <h4 class="ms-1 mb-0" id="valTotalPagu">Rp 0</h4>
                    </div>
                    <p class="mb-1 fw-semibold">Total Pagu</p>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div class="card card-border-shadow-success h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-2 pb-1">
                        <div class="avatar me-2">
                            <span class="avatar-initial rounded bg-label-success"><i class="bx bx-check-circle"></i></span>
                        </div>
                        <h4 class="ms-1 mb-0 text-success" id="valTotalRealisasi">Rp 0</h4>
                    </div>
                    <p class="mb-1 fw-semibold">Total Realisasi</p>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div class="card card-border-shadow-warning h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-2 pb-1">
                        <div class="avatar me-2">
                            <span class="avatar-initial rounded bg-label-warning"><i class="bx bx-pie-chart-alt"></i></span>
                        </div>
                        <h4 class="ms-1 mb-0 text-warning" id="valAvgProgress">0%</h4>
                    </div>
                    <p class="mb-1 fw-semibold">Rata-rata Persentase</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart -->
    <div class="card mb-4 shadow-sm border-0">
        <div class="card-header border-bottom">
            <h5 class="card-title mb-0 fw-bold"><i class="bx bx-bar-chart-alt-2 me-2"></i>Persentase Realisasi per OPD</h5>
        </div>
        <div class="card-body pt-4">
            <div id="opdChart" style="min-height: 400px;"></div>
        </div>
    </div>

    <!-- Table Card -->
    <div class="card shadow-sm border-0">
        <div class="card-header border-bottom d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0 fw-bold"><i class="bx bx-list-ul me-2"></i>Detail Paket per OPD</h5>
        </div>
        <div class="card-body pt-4">
            <div class="table-responsive text-nowrap">
                <table class="table table-hover w-100" id="table-monev-opd">
                    <thead class="table-light">
                        <tr>
                            <th width="30"></th>
                            <th>Nama OPD / Satker</th>
                            <th>Total Paket</th>
                            <th>Total Pagu</th>
                            <th>Total Realisasi</th>
                            <th>Persentase (%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data will be populated by JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="<?= base_url('assets') ?>/vendor/libs/apex-charts/apexcharts.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>

<script>
    let opdChart = null;
    let dtTable = null;

    function formatIDR(amount) {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
    }

    function initChart(data) {
        if(opdChart) opdChart.destroy();
        
        let sortedData = [...data].sort((a, b) => b.persentase - a.persentase);
        
        let categories = sortedData.map(d => d.nama_satker);
        let percentages = sortedData.map(d => d.persentase);
        
        let options = {
            series: [{
                name: 'Realisasi (%)',
                data: percentages
            }],
            chart: {
                type: 'bar',
                height: Math.max(400, categories.length * 30),
                toolbar: { show: true }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    borderRadius: 4,
                    dataLabels: { position: 'top' }
                }
            },
            colors: ['#696cff'],
            dataLabels: {
                enabled: true,
                offsetX: -6,
                style: { fontSize: '12px', colors: ['#fff'] },
                formatter: function (val) { return val + "%" }
            },
            xaxis: {
                categories: categories,
                max: 100,
                labels: {
                    formatter: function (val) { return val + "%" }
                }
            },
            tooltip: {
                y: {
                    formatter: function (val, opts) {
                        let idx = opts.dataPointIndex;
                        let item = sortedData[idx];
                        return val + "% (" + formatIDR(item.total_realisasi) + " dari " + formatIDR(item.total_pagu) + ")";
                    }
                }
            }
        };

        opdChart = new ApexCharts(document.querySelector("#opdChart"), options);
        opdChart.render();
    }

    function escapeHtml(unsafe) {
        if(!unsafe) return '';
        return unsafe
            .toString()
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function initTable(data) {
        if (dtTable) {
            dtTable.destroy();
            $('#table-monev-opd tbody').empty();
        }

        let tbody = '';
        data.forEach((opd, index) => {
            let percentClass = opd.persentase >= 100 ? 'bg-success' : (opd.persentase >= 50 ? 'bg-info' : 'bg-danger');
            
            // Create a temporary object to hold packages and convert it to string safely
            let packagesJson = escapeHtml(JSON.stringify(opd.packages || []));
            
            tbody += `
                <tr data-packages="${packagesJson}">
                    <td class="details-control text-center">
                        <button class="btn btn-sm btn-icon btn-outline-primary rounded-circle">
                            <i class="bx bx-plus"></i>
                        </button>
                    </td>
                    <td class="fw-bold">${escapeHtml(opd.nama_satker)}</td>
                    <td><span class="badge bg-label-primary">${opd.paket_terealisasi} / ${opd.total_paket} pkt</span></td>
                    <td>${formatIDR(opd.total_pagu)}</td>
                    <td class="text-success fw-bold">${formatIDR(opd.total_realisasi)}</td>
                    <td data-order="${opd.persentase}">
                        <div class="d-flex align-items-center">
                            <span class="me-2 fw-bold">${opd.persentase}%</span>
                            <div class="progress w-100" style="height: 6px;">
                                <div class="progress-bar ${percentClass}" role="progressbar" style="width: ${Math.min(100, opd.persentase)}%"></div>
                            </div>
                        </div>
                    </td>
                </tr>
            `;
        });
        
        $('#table-monev-opd tbody').html(tbody);

        dtTable = $('#table-monev-opd').DataTable({
            responsive: true,
            pageLength: 25,
            order: [[5, 'desc']], // sort by percentage descending
            columnDefs: [
                { orderable: false, targets: 0 }
            ],
            dom: '<"row"<"col-md-4"l><"col-md-4 text-center"B><"col-md-4"f>>t<"row"<"col-md-6"i><"col-md-6"p>>',
            buttons: [
                {
                    extend: 'excel',
                    text: '<i class="bx bx-export me-1"></i> Excel',
                    className: 'btn btn-success btn-sm'
                }
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/id.json'
            }
        });

        // Expand/collapse logic
        $('#table-monev-opd tbody').off('click', 'td.details-control').on('click', 'td.details-control', function () {
            let tr = $(this).closest('tr');
            let row = dtTable.row(tr);
            let btn = $(this).find('button i');

            if (row.child.isShown()) {
                row.child.hide();
                tr.removeClass('shown');
                btn.removeClass('bx-minus').addClass('bx-plus');
            } else {
                let packagesRaw = tr.attr('data-packages');
                let opdName = tr.find('td:eq(1)').text();
                let packages = [];
                try {
                    // We need to unescape HTML entities before parsing JSON
                    let unescaped = $('<textarea/>').html(packagesRaw).text();
                    packages = JSON.parse(unescaped);
                } catch(e) { console.error("Error parsing packages", e); }
                
                let childId = 'child-table-' + Math.random().toString(36).substr(2, 9);
                row.child(formatChild(packages, childId)).show();
                tr.addClass('shown');
                btn.removeClass('bx-plus').addClass('bx-minus');
                
                $('#' + childId).DataTable({
                    dom: 'Brtip',
                    buttons: [
                        {
                            extend: 'excel',
                            text: '<i class="bx bx-export me-1"></i> Export Rincian RUP',
                            className: 'btn btn-success btn-sm mb-2',
                            title: 'Rincian_Monev_' + opdName
                        }
                    ],
                    paging: false,
                    ordering: false,
                    info: false
                });
            }
        });
    }

    function formatChild(packages, tableId) {
        if(packages.length === 0) {
            return '<div class="text-center p-3 text-muted">Tidak ada paket RUP.</div>';
        }

        let html = `
            <div class="p-3 bg-lighter rounded" style="border-left: 3px solid #696cff;">
                <h6 class="fw-bold mb-3"><i class="bx bx-package me-2"></i>Detail Paket RUP</h6>
                <table id="${tableId}" class="table table-sm table-bordered bg-white">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Kode RUP</th>
                            <th>Nama Paket (RUP)</th>
                            <th>Nama Paket (Realisasi)</th>
                            <th>Jenis Barang/Jasa</th>
                            <th>Metode</th>
                            <th>Pagu (Rp)</th>
                            <th>Realisasi (Rp)</th>
                            <th>Sumber Realisasi</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        packages.forEach((pkg, idx) => {
            let trClass = pkg.realisasi > 0 ? 'table-success' : '';
            html += `
                <tr class="${trClass}">
                    <td>${idx + 1}</td>
                    <td><span class="badge bg-label-secondary">${escapeHtml(pkg.kd_rup)}</span></td>
                    <td>${escapeHtml(pkg.nama_paket)}</td>
                    <td>${escapeHtml(pkg.nama_paket_realisasi)}</td>
                    <td>${escapeHtml(pkg.jenis)}</td>
                    <td>${escapeHtml(pkg.metode)}</td>
                    <td>${formatIDR(pkg.pagu)}</td>
                    <td class="fw-bold text-success">${formatIDR(pkg.realisasi)}</td>
                    <td>${escapeHtml(pkg.sumber)}</td>
                </tr>
            `;
        });
        
        html += `</tbody></table></div>`;
        return html;
    }

    function loadData() {
        let year = $('#yearFilter').val();
        
        Swal.fire({
            title: 'Memuat Data...',
            text: 'Mengambil data monev per OPD',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        $.ajax({
            url: '<?= base_url('dashboard/getMonevOpdData') ?>',
            type: 'GET',
            data: { year: year },
            dataType: 'json',
            success: function(data) {
                Swal.close();
                
                let sumPagu = 0;
                let sumRealisasi = 0;
                
                data.forEach(d => {
                    sumPagu += d.total_pagu;
                    sumRealisasi += d.total_realisasi;
                });
                
                let avg = sumPagu > 0 ? (sumRealisasi / sumPagu * 100).toFixed(2) : 0;
                
                $('#valTotalOpd').text(data.length);
                $('#valTotalPagu').text(formatIDR(sumPagu));
                $('#valTotalRealisasi').text(formatIDR(sumRealisasi));
                $('#valAvgProgress').text(avg + '%');
                
                initChart(data);
                initTable(data);
            },
            error: function() {
                Swal.fire('Error', 'Gagal memuat data dari server.', 'error');
            }
        });
    }

    $(document).ready(function() {
        loadData();
        $('#btnFilter').click(function() { loadData(); });
    });
</script>
<?= $this->endSection() ?>
