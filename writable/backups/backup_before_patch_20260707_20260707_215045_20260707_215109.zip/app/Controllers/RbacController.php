<?php

namespace App\Controllers;

use App\Models\RolePermissionModel;
use App\Models\UserModel;

class RbacController extends BaseController
{
    public function index()
    {
        $roleModel = new RolePermissionModel();
        $userModel = new UserModel();
        
        // Get unique roles from users table
        $roles = $userModel->select('role')->distinct()->findAll();
        $roles = array_column($roles, 'role');
        
        // Ensure standard roles exist in list
        $standardRoles = ['admin', 'operator', 'opd', 'satker', 'ppk', 'user'];
        $roles = array_unique(array_merge($roles, $standardRoles));

        $menus = [
            ['key' => 'report', 'label' => 'Summary - Laporan Realisasi'],
            ['key' => 'dashboard', 'label' => 'Data RUP - Dashboard'],
            ['key' => 'comparisons', 'label' => 'Data RUP - Perbandingan Tahunan'],
            ['key' => 'penyedia', 'label' => 'Data RUP - Penyedia'],
            ['key' => 'swakelola', 'label' => 'Data RUP - Swakelola'],
            ['key' => 'rup-opd', 'label' => 'Data RUP - RUP OPD'],
            ['key' => 'dashboard-lpse', 'label' => 'Data Pengadaan - Dashboard LPSE'],
            ['key' => 'lpse_tender', 'label' => 'Data Pengadaan - Data LPSE - Tender'],
            ['key' => 'lpse_nontender', 'label' => 'Data Pengadaan - Data LPSE - Non Tender'],
            ['key' => 'lpse_pencatatan_nontender', 'label' => 'Data Pengadaan - Data LPSE - Pencatatan Non Tender'],
            ['key' => 'lpse_pencatatan_swakelola', 'label' => 'Data Pengadaan - Data LPSE - Pencatatan Swakelola'],
            ['key' => 'epurchasing', 'label' => 'Data Pengadaan - E-Purchasing'],
            ['key' => 'penyedia-katalog', 'label' => 'Data Pengadaan - Penyedia Katalog'],
            ['key' => 'monev', 'label' => 'MONEV - Monev Proyek'],
            ['key' => 'monev_summary', 'label' => 'MONEV - Summary Progres'],
            ['key' => 'user_management', 'label' => 'Aplikasi - Manage User'],
            ['key' => 'chatbot_settings', 'label' => 'Aplikasi - Chatbot Settings'],
            ['key' => 'api_settings', 'label' => 'Aplikasi - API Security'],
            ['key' => 'sync_data', 'label' => 'Aplikasi - Sinkronisasi Data'],
            ['key' => 'master_menu', 'label' => 'Aplikasi - Master Menu'],
            ['key' => 'patch_app', 'label' => 'Aplikasi - System Patcher'],
            ['key' => 'user_logs', 'label' => 'Aplikasi - Activity Logs'],
        ];

        // Fetch current permissions using the checkPermission method (so defaults are resolved properly in UI checkboxes)
        $permissions = [];
        foreach ($roles as $role) {
            foreach ($menus as $menu) {
                $permissions[$role][$menu['key']] = $roleModel->checkPermission($role, $menu['key']) ? 1 : 0;
            }
        }

        return view('user/rbac', [
            'title' => 'Manage RBAC',
            'user'  => session()->get(),
            'roles' => $roles,
            'menus' => $menus,
            'permissions' => $permissions
        ]);
    }

    public function save()
    {
        $roleModel = new RolePermissionModel();
        $userModel = new UserModel();
        $perms = $this->request->getPost('perms'); // [role][menu_key] = 1

        // Get standard roles and menus to save explicit states for all
        $roles = $userModel->select('role')->distinct()->findAll();
        $roles = array_column($roles, 'role');
        $standardRoles = ['admin', 'operator', 'opd', 'satker', 'ppk', 'user'];
        $roles = array_unique(array_merge($roles, $standardRoles));

        $menus = [
            'report', 'dashboard', 'comparisons', 'penyedia', 'swakelola', 'rup-opd',
            'dashboard-lpse', 'lpse_tender', 'lpse_nontender', 'lpse_pencatatan_nontender',
            'lpse_pencatatan_swakelola', 'epurchasing', 'penyedia-katalog', 'monev', 'monev_summary',
            'user_management', 'chatbot_settings', 'api_settings', 'sync_data', 'master_menu',
            'patch_app', 'user_logs'
        ];

        // Clear existing permissions to sync
        $roleModel->truncate();

        foreach ($roles as $role) {
            if ($role === 'admin') continue; // admin always allowed, no need to store
            foreach ($menus as $menuKey) {
                $isAllowed = isset($perms[$role][$menuKey]) ? 1 : 0;
                $roleModel->insert([
                    'role'       => $role,
                    'menu_key'   => $menuKey,
                    'is_allowed' => $isAllowed
                ]);
            }
        }

        return redirect()->to(base_url('user/rbac'))->with('success', 'Hak akses berhasil diperbarui.');
    }
}
