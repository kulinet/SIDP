<?php

namespace App\Services;

use App\Models\RupPenyediaModel;
use App\Models\RupSwakelolaModel;
use App\Models\LpseTenderModel;
use App\Models\LpseNontenderModel;
use App\Models\EpurchasingModel;
use App\Models\MasterAnggaranModel;
use App\Models\LpsePencatatanNontenderModel;
use App\Models\LpsePencatatanSwakelolaModel;
use CodeIgniter\Config\Services;

class SyncService
{
    protected $client;
    protected $baseUrl;

    public function __construct()
    {
        $this->client = Services::curlrequest();
        $this->baseUrl = env('AJIP_API_BASE_URL', 'https://ajip-api.cloud');
    }

    private function fetchApi($url)
    {
        try {
            $response = $this->client->get($url, ['timeout' => 120, 'verify' => false]);
            $body = $response->getBody();
            $data = json_decode($body, true);
            if (!is_array($data)) {
                log_message('error', "API $url tidak mengembalikan array. Body: " . substr($body, 0, 200));
                return [];
            }
            // Handle if API wraps response in a 'data' key
            if (isset($data['data']) && is_array($data['data'])) {
                return $data['data'];
            }
            return $data;
        } catch (\Exception $e) {
            log_message('error', "Gagal fetch API $url: " . $e->getMessage());
            return [];
        }
    }

    private function fetchApisConcurrent(array $urls)
    {
        $multi = curl_multi_init();
        $channels = [];
        $results = [];

        foreach ($urls as $key => $url) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            
            curl_multi_add_handle($multi, $ch);
            $channels[$key] = $ch;
        }

        $active = null;
        do {
            $mrc = curl_multi_exec($multi, $active);
        } while ($mrc == CURLM_CALL_MULTI_PERFORM);

        while ($active && $mrc == CURLM_OK) {
            if (curl_multi_select($multi) != -1) {
                do {
                    $mrc = curl_multi_exec($multi, $active);
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);
            }
        }

        foreach ($channels as $key => $ch) {
            $body = curl_multi_getcontent($ch);
            $url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            curl_multi_remove_handle($multi, $ch);
            
            $data = json_decode($body, true);
            if (!is_array($data)) {
                log_message('error', "API $url tidak mengembalikan array. Body: " . substr((string)$body, 0, 200));
                $results[$key] = [];
                continue;
            }
            
            if (isset($data['data']) && is_array($data['data'])) {
                $results[$key] = $data['data'];
            } else {
                $results[$key] = $data;
            }
        }

        curl_multi_close($multi);
        return $results;
    }

    public function syncPenyedia($year, $callback = null)
    {
        $urlRup = $this->baseUrl . '/api/data/perbandingan-rup-penyedia';
        $urlAnggaran = $this->baseUrl . '/api/data/rup-paket-anggaran';
        $model = new RupPenyediaModel();

        if ($callback) $callback('Mengambil data RUP Penyedia & Anggaran (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'rup' => $urlRup,
            'anggaran' => $urlAnggaran
        ]);
        
        $rawRup = $apiResults['rup'];
        $rawAnggaran = $apiResults['anggaran'];

        $anggaranMap = [];
        foreach ($rawAnggaran as $a) {
            $kd = $a['kd_rup'] ?? null;
            if ($kd) $anggaranMap[$kd] = $a;
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($rawRup as $item) {
            $kdRup = $item['kd_rup'] ?? null;
            $ang = $anggaranMap[$kdRup] ?? [];
            
            // Standardize Year
            $yr = $item['tahun_anggaran'] ?? ($item['tahun_anggaran_sirup'] ?? ($item['tahun_anggaran_dana'] ?? ($item['tahun'] ?? ($ang['tahun_anggaran'] ?? date('Y')))));
            if ((int)$yr !== (int)$year) continue; // HANYA PROSES TAHUN TERPILIH
            
            $batch[] = [
                'kd_rup'           => $kdRup,
                'nama_paket'       => $item['nama_paket'] ?? ($ang['nama_paket'] ?? ''),
                'kd_satker'        => $item['kd_satker'] ?? ($item['kode_satker'] ?? ($item['kd_organisasi'] ?? ($ang['kd_satker'] ?? ''))),
                'nama_satker'      => $item['nama_satker'] ?? ($item['satker'] ?? ($item['Nama_Satker'] ?? ($ang['nama_satker'] ?? ''))),
                'pagu'             => (float)($item['pagu'] ?? ($ang['pagu'] ?? 0)),
                'jenis_pengadaan'  => $item['jenis_pengadaan'] ?? ($item['jenis'] ?? ($ang['jenis_pengadaan'] ?? '')),
                'metode_pengadaan' => $item['metode_pengadaan'] ?? ($item['metode'] ?? ($item['tipe'] ?? ($item['metode_pengadaan_sirup'] ?? ''))),
                'volume_pekerjaan' => $item['volume_pekerjaan'] ?? '',
                'uraian_pekerjaan' => $item['uraian_pekerjaan'] ?? ($item['urarian_pekerjaan'] ?? ($item['spesifikasi_pekerjaan'] ?? '')),
                'mak'              => $ang['mak'] ?? '',
                'tgl_awal_pemilihan'  => $item['tgl_awal_pemilihan'] ?? ($item['tgl_awal_kontrak'] ?? ''),
                'tgl_akhir_pemilihan' => $item['tgl_akhir_pemilihan'] ?? ($item['tgl_akhir_kontrak'] ?? ''),
                'status_umumkan_rup'  => $item['status_umumkan_rup'] ?? ($ang['status_umumkan_rup'] ?? 'Terumumkan'),
                'tahun'            => $yr,
                'created_at'       => date('Y-m-d H:i:s'),
                'updated_at'       => date('Y-m-d H:i:s')
            ];

            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncSwakelola($year, $callback = null)
    {
        $urlRup = $this->baseUrl . '/api/data/perbandingan-swakelola';
        $urlAnggaran = $this->baseUrl . '/api/data/rup-paket-swakelola';
        $model = new RupSwakelolaModel();

        if ($callback) $callback('Mengambil data RUP Swakelola & Anggaran (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'rup' => $urlRup,
            'anggaran' => $urlAnggaran
        ]);
        
        $rawRup = $apiResults['rup'];
        $rawAnggaran = $apiResults['anggaran'];

        $anggaranMap = [];
        foreach ($rawAnggaran as $a) {
            $kd = $a['kd_rup'] ?? null;
            if ($kd) $anggaranMap[$kd] = $a;
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($rawRup as $item) {
            $kdRup = $item['kd_rup'] ?? null;
            $ang = $anggaranMap[$kdRup] ?? [];
            
            $yr = $item['tahun_anggaran'] ?? ($item['tahun_anggaran_sirup'] ?? ($item['tahun_anggaran_dana'] ?? ($item['tahun'] ?? ($ang['tahun_anggaran'] ?? date('Y')))));
            if ((int)$yr !== (int)$year) continue;
            
            $batch[] = [
                'kd_rup'           => $kdRup,
                'nama_paket'       => $item['nama_paket'] ?? ($ang['nama_paket'] ?? ''),
                'kd_satker'        => $item['kd_satker'] ?? ($item['kode_satker'] ?? ($item['kd_organisasi'] ?? ($ang['kd_satker'] ?? ''))),
                'nama_satker'      => $item['nama_satker'] ?? ($item['satker'] ?? ($item['Nama_Satker'] ?? ($ang['nama_satker'] ?? ''))),
                'pagu'             => (float)($item['pagu'] ?? ($ang['pagu'] ?? 0)),
                'tipe_swakelola'   => $item['tipe_swakelola'] ?? ($item['tipe'] ?? ($item['metode'] ?? ($item['tipe_swakelola_sirup'] ?? ''))),
                'volume_pekerjaan' => $item['volume_pekerjaan'] ?? '',
                'uraian_pekerjaan' => $item['uraian_pekerjaan'] ?? ($item['urarian_pekerjaan'] ?? ($item['kegiatan'] ?? '')),
                'mak'              => $ang['mak'] ?? '',
                'tgl_awal_pelaksanaan'  => $item['tgl_awal_pelaksanaan_kontrak'] ?? ($item['tgl_awal_pelaksanaan'] ?? ($item['tgl_awal_pemilihan'] ?? '')),
                'tgl_akhir_pelaksanaan' => $item['tgl_akhir_pelaksanaan_kontrak'] ?? ($item['tgl_akhir_pelaksanaan'] ?? ($item['tgl_akhir_pemilihan'] ?? '')),
                'status_umumkan_rup'    => $item['status_umumkan_rup'] ?? ($ang['status_umumkan_rup'] ?? 'Terumumkan'),
                'tahun'            => $yr,
                'created_at'       => date('Y-m-d H:i:s'),
                'updated_at'       => date('Y-m-d H:i:s')
            ];

            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncTender($year, $callback = null)
    {
        $urlTender = $this->baseUrl . '/api/data/tender-selesai';
        $urlKontrak = $this->baseUrl . '/api/data/list-tender-kontrak';
        $urlAnn = $this->baseUrl . '/api/data/pengumuman-tender';
        $model = new LpseTenderModel();

        if ($callback) $callback('Mengambil data Tender, Kontrak & Pengumuman (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'tender' => $urlTender,
            'kontrak' => $urlKontrak,
            'ann' => $urlAnn
        ]);
        
        $rawTender = $apiResults['tender'];
        $rawKontrak = $apiResults['kontrak'];
        $rawAnn = $apiResults['ann'];

        $kontrakMap = [];
        foreach ($rawKontrak as $k) {
            $kd = trim((string)($k['kd_tender'] ?? ($k['kd_paket'] ?? '')));
            $rup = trim((string)($k['kd_rup'] ?? ''));
            if ($kd !== '') $kontrakMap[$kd] = $k;
            if ($rup !== '') $kontrakMap['rup_'.$rup] = $k;
        }

        $annMap = [];
        foreach ($rawAnn as $a) {
            $kd = trim((string)($a['kd_tender'] ?? ''));
            $kdPkt = trim((string)($a['kd_pkt_dce'] ?? ($a['kd_paket'] ?? '')));
            if ($kd !== '') $annMap[$kd] = $a;
            if ($kdPkt !== '') $annMap[$kdPkt] = $a;
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($rawTender as $item) {
            $kdTender = trim((string)($item['kd_tender'] ?? ($item['kd_paket'] ?? ($item['kode_paket'] ?? ($item['order_id'] ?? '')))));
            $ann = $annMap[$kdTender] ?? [];
            $kdRup = $item['kd_rup'] ?? ($item['rup_code'] ?? ($ann['kd_rup'] ?? ($ann['kode_rup'] ?? null)));
            
            $kontrak = $kontrakMap[$kdTender] ?? ($kontrakMap['rup_'.$kdRup] ?? []);

            $yr = $item['fiscal_year'] ?? ($item['tahun_anggaran'] ?? ($item['tahun'] ?? ($kontrak['tahun_anggaran'] ?? ($ann['tahun_anggaran'] ?? date('Y')))));
            if (strlen($yr) > 4 && strpos($yr, '-') !== false) $yr = substr($yr, 0, 4);
            if ((int)$yr !== (int)$year) continue;

            $namaPenyedia = trim($item['nama_penyedia'] ?? ($kontrak['nama_penyedia'] ?? ($ann['nama_penyedia'] ?? ($item['pemenang'] ?? ''))));
            $status = $item['status_tender'] ?? ($item['status'] ?? ($item['tahapan'] ?? ($kontrak['status_kontrak'] ?? ($ann['status'] ?? 'Selesai'))));
            if ($namaPenyedia === '') {
                $status = 'Sedang Berlangsung';
                $nilaiKontrak = 0.0;
            } else {
                $nilaiKontrak = (float)($item['nilai_kontrak'] ?? ($kontrak['harga_final'] ?? ($kontrak['nilai_kontrak'] ?? ($ann['nilai_kontrak'] ?? 0))));
                if ($nilaiKontrak == 0) {
                    $nilaiKontrak = (float)($item['nilai_terkoreksi'] ?? ($ann['nilai_terkoreksi'] ?? ($item['nilai_negosiasi'] ?? ($ann['nilai_negosiasi'] ?? 0))));
                }
            }

            $batch[] = [
                'kd_rup' => $kdRup,
                'tahun' => (int)$yr,
                'kd_paket' => $kdTender,
                'nama_paket' => $item['nama_paket'] ?? ($item['rup_name'] ?? ($item['nama_tender'] ?? ($kontrak['nama_paket'] ?? ($ann['nama_paket'] ?? '')))),
                'pagu' => (float)($item['pagu'] ?? ($item['total'] ?? ($kontrak['pagu'] ?? ($ann['pagu'] ?? 0)))),
                'hps' => (float)($item['hps'] ?? ($item['nilai_hps'] ?? ($kontrak['nilai_hps'] ?? ($ann['hps'] ?? 0)))),
                'nilai_penawaran' => (float)($item['nilai_penawaran'] ?? ($item['nilai_terkoreksi'] ?? 0)),
                'nilai_kontrak' => $nilaiKontrak,
                'nama_penyedia' => $namaPenyedia,
                'nama_satker' => $item['nama_satker'] ?? ($item['satker'] ?? ($kontrak['nama_satker'] ?? ($ann['nama_satker'] ?? ''))),
                'kd_satker' => $item['kd_satker'] ?? ($item['kode_satker'] ?? ($kontrak['kd_satker'] ?? '')),
                'metode' => $item['metode_pengadaan'] ?? ($item['metode'] ?? ($item['mtd_pemilihan'] ?? ($ann['mtd_pemilihan'] ?? ''))),
                'status' => $status,
                'tgl_pemenang' => $item['tgl_penetapan_pemenang'] ?? ($item['tgl_pemenang'] ?? ($ann['tgl_pemenang'] ?? '')),
                'tgl_kontrak' => $kontrak['tgl_kontrak'] ?? ($item['tgl_kontrak'] ?? ''),
                'no_kontrak' => $kontrak['no_kontrak'] ?? ($item['no_kontrak'] ?? ''),
                'jenis_pengadaan' => $item['jenis_pengadaan'] ?? ($ann['jenis_pengadaan'] ?? ''),
                'mtd_evaluasi' => $ann['mtd_evaluasi'] ?? ($item['mtd_evaluasi'] ?? ''),
                'mtd_kualifikasi' => $ann['mtd_kualifikasi'] ?? ($item['mtd_kualifikasi'] ?? ''),
                'kontrak_pembayaran' => $kontrak['jenis_kontrak'] ?? ($ann['kontrak_pembayaran'] ?? ($item['kontrak_pembayaran'] ?? '')),
                'status_kontrak' => $kontrak['status_kontrak'] ?? '',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncNontender($year, $callback = null)
    {
        $urlNontender = $this->baseUrl . '/api/data/nontender-selesai';
        $urlKontrak = $this->baseUrl . '/api/data/list-nontender-ekontrak';
        $model = new LpseNontenderModel();

        if ($callback) $callback('Mengambil data Non-Tender & Kontrak (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'nontender' => $urlNontender,
            'kontrak' => $urlKontrak
        ]);
        
        $rawNontender = $apiResults['nontender'];
        $rawKontrak = $apiResults['kontrak'];

        $kontrakMap = [];
        foreach ($rawKontrak as $k) {
            $kd = trim((string)($k['kd_nontender'] ?? ($k['kd_paket'] ?? '')));
            $rup = trim((string)($k['kd_rup'] ?? ''));
            if ($kd !== '') $kontrakMap[$kd] = $k;
            if ($rup !== '') $kontrakMap['rup_'.$rup] = $k;
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($rawNontender as $item) {
            $kdNontender = trim((string)($item['kd_nontender'] ?? ($item['kd_pkt_dce'] ?? ($item['kd_paket'] ?? ''))));
            $kdRup = $item['kd_rup'] ?? null;
            $kontrak = $kontrakMap[$kdNontender] ?? ($kontrakMap['rup_'.$kdRup] ?? []);

            $yr = $item['tahun_anggaran'] ?? ($item['tahun'] ?? ($kontrak['tahun_anggaran'] ?? date('Y')));
            if (strlen($yr) > 4 && strpos($yr, '-') !== false) $yr = substr($yr, 0, 4);
            if ((int)$yr !== (int)$year) continue;

            $batch[] = [
                'kd_rup' => $kdRup,
                'tahun' => (int)$yr,
                'kd_paket' => $kdNontender,
                'nama_paket' => $item['nama_paket'] ?? ($kontrak['nama_paket'] ?? ''),
                'pagu' => (float)($item['pagu'] ?? ($kontrak['pagu'] ?? 0)),
                'hps' => (float)($item['hps'] ?? ($kontrak['nilai_hps'] ?? 0)),
                'nilai_kontrak' => (float)($kontrak['nilai_kontrak'] ?? ($item['nilai_kontrak'] ?? 0)),
                'nilai_negosiasi' => (float)($item['nilai_negosiasi'] ?? ($kontrak['nilai_negosiasi'] ?? 0)),
                'nama_penyedia' => $item['nama_penyedia'] ?? ($kontrak['nama_penyedia'] ?? ($item['pemenang'] ?? '')),
                'nama_satker' => $item['nama_satker'] ?? ($kontrak['nama_satker'] ?? ''),
                'kd_satker' => $item['kd_satker'] ?? ($kontrak['kd_satker'] ?? ''),
                'metode' => $item['metode_pengadaan'] ?? ($item['metode'] ?? ($item['mtd_pemilihan'] ?? '')),
                'jenis_pengadaan' => $item['jenis_pengadaan'] ?? ($kontrak['jenis_pengadaan'] ?? ''),
                'tgl_kontrak' => $kontrak['tgl_kontrak'] ?? ($item['tgl_kontrak'] ?? ''),
                'no_kontrak' => $kontrak['no_kontrak'] ?? ($item['no_kontrak'] ?? ''),
                'status' => $item['status_nontender'] ?? ($item['status'] ?? ($item['status_nontender_pct_ket'] ?? ($kontrak['status_kontrak'] ?? 'Selesai'))),
                'kualifikasi_paket' => $item['kualifikasi_paket'] ?? ($kontrak['kualifikasi_paket'] ?? ''),
                'kontrak_pembayaran' => $kontrak['jenis_kontrak'] ?? ($item['kontrak_pembayaran'] ?? ''),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncEpurchasing($year, $callback = null)
    {
        $url = $this->baseUrl . '/api/data/paket-epurchasing';
        $model = new EpurchasingModel();
        
        if ($callback) $callback('Mengambil data E-Purchasing...');
        $raw = $this->fetchApi($url);

        // ===== PRE-FETCH vendor names from Inaproc (batch) =====
        $vendorDir  = WRITEPATH . 'inaproc/vendors/';
        $inaprocToken = getenv('INAPROC_BEARER_TOKEN') ?: 'inprc73221b186ad14d568b02f22b214c9574';
        if (!is_dir($vendorDir)) mkdir($vendorDir, 0777, true);

        // Collect all unique kode_penyedia from raw data
        $allKodes = array_values(array_unique(array_filter(array_column($raw, 'kode_penyedia'))));
        $vendorMap = []; // [kode_penyedia] => nama_penyedia

        if ($callback) $callback('Mengambil nama penyedia dari Inaproc (' . count($allKodes) . ' vendor)...');

        foreach ($allKodes as $kode) {
            $kode = trim($kode);
            if ($kode === '') continue;

            $file = $vendorDir . $kode . '.json';

            // 1. Check local JSON cache first
            if (file_exists($file)) {
                $saved = json_decode(file_get_contents($file), true);
                if (!empty($saved['nama_penyedia'])) {
                    $vendorMap[$kode] = $saved['nama_penyedia'];
                    continue;
                }
                // If marked not-found within 24h, skip API call
                if (!empty($saved['_not_found'])) {
                    $lastAttempt = strtotime($saved['_last_attempt'] ?? '2000-01-01');
                    if ((time() - $lastAttempt) < 86400) {
                        $vendorMap[$kode] = null; // Known not-found
                        continue;
                    }
                }
            }

            // 2. Fetch from Inaproc API
            try {
                $apiUrl = "https://data.inaproc.id/api/legacy/ekatalog/penyedia-detail?kode_penyedia={$kode}";
                $res = $this->client->get($apiUrl, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $inaprocToken,
                        'User-Agent'    => 'Mozilla/5.0 (compatible; SIDP-Sync/1.0)',
                    ],
                    'timeout' => 10,
                ]);
                $body = json_decode($res->getBody(), true);
                // Legacy endpoint returns direct array [{...}]; v1 returns {"data":[{...}]}
                $vendor = $body[0] ?? ($body['data'][0] ?? null);
                $name   = is_array($vendor) ? ($vendor['nama_penyedia'] ?? null) : null;

                if ($name) {
                    file_put_contents($file, json_encode(['nama_penyedia' => $name, '_synced_at' => date('Y-m-d H:i:s')]));
                    $vendorMap[$kode] = $name;
                } else {
                    // Save not-found marker
                    file_put_contents($file, json_encode([
                        'nama_penyedia' => null, '_not_found' => true, '_last_attempt' => date('Y-m-d H:i:s')
                    ]));
                    $vendorMap[$kode] = null;
                }
            } catch (\Exception $e) {
                $vendorMap[$kode] = null;
            }

            usleep(200000); // 200ms delay to avoid rate limiting
        }
        // ===== END vendor pre-fetch =====

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($raw as $item) {
            $status = strtoupper(str_replace('_', ' ', (string)($item['status'] ?? '')));
            $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
            if (!in_array($status, $allowed)) continue;

            $rawDate = $item['order_date'] ?? '';
            $yr = (strlen($rawDate) >= 4) ? substr($rawDate, 0, 4) : ($item['fiscal_year'] ?? ($item['tahun_anggaran'] ?? ($item['tahun'] ?? date('Y'))));
            if ((int)$yr !== (int)$year) continue;

            $kode = trim($item['kode_penyedia'] ?? '');
            $namaPenyedia = ($kode !== '') ? ($vendorMap[$kode] ?? null) : null;
            
            $batch[] = [
                'kd_paket'        => $item['order_id'] ?? ($item['kd_paket'] ?? null),
                'nama_paket'      => $item['rup_name'] ?? ($item['nama_paket'] ?? ''),
                'pagu'            => (float)($item['total'] ?? ($item['pagu'] ?? 0)),
                'total_harga'     => (float)($item['total_harga'] ?? ($item['total'] ?? 0)),
                'nama_satker'     => $item['nama_satker'] ?? '',
                'kd_satker'       => $item['kode_satker'] ?? ($item['kd_satker'] ?? ''),
                'tahun'           => (int)$yr,
                'sumber_dana'     => $item['funding_source'] ?? '',
                'status'          => $status,
                'order_date'      => $item['order_date'] ?? '',
                'kode_penyedia'   => $kode,
                'nama_penyedia'   => $namaPenyedia,   // Stored from Inaproc lookup
                'product_id'      => $item['product_id'] ?? '',
                'rup_desc'        => $item['rup_desc'] ?? '',
                'total_qty'       => (int)($item['total_qty'] ?? ($item['count_product'] ?? 0)),
                'shipment_status' => $item['shipment_status'] ?? '',
                'rup_code'        => $item['rup_code'] ?? '',
                'created_at'      => date('Y-m-d H:i:s'),
                'updated_at'      => date('Y-m-d H:i:s'),
            ];
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncMasterAnggaran($year, $callback = null)
    {

        $urlKegiatan = $this->baseUrl . '/api/data/kegiatan-master';
        $urlSatker = $this->baseUrl . '/api/data/master-satker';
        $model = new MasterAnggaranModel();

        if ($callback) $callback('Mengambil Master Satker & Kegiatan (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'satker' => $urlSatker,
            'kegiatan' => $urlKegiatan
        ]);
        
        $rawSatker = $apiResults['satker'];
        $raw = $apiResults['kegiatan'];
        
        $satkerMap = [];
        foreach ($rawSatker as $s) {
            $kd = $s['kd_satker'] ?? null;
            if ($kd) $satkerMap[$kd] = $s['nama_satker'] ?? '';
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($raw as $item) {
            $yr = $item['tahun_anggaran'] ?? ($item['tahun'] ?? date('Y'));
            if ((int)$yr !== (int)$year) continue;
            
            $kdSatker = $item['kd_satker'] ?? '';
            $batch[] = [
                'kd_satker' => $kdSatker,
                'nama_satker' => $satkerMap[$kdSatker] ?? ($item['nama_satker'] ?? ''),
                'kd_program_str' => trim($item['kd_program_str'] ?? ''),
                'nama_program' => $item['nama_program'] ?? '',
                'pagu_program' => (float)($item['pagu_program'] ?? 0),
                'tahun' => (int)$yr,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncPencatatanNontender($year, $callback = null)
    {
        $urlReal = $this->baseUrl . '/api/data/pencatatan-nontender-realisasi';
        $urlPenyedia = $this->baseUrl . '/api/data/penyedia_pct_nontender';
        $model = new LpsePencatatanNontenderModel();

        if ($callback) $callback('Mengambil data Pencatatan Non-Tender Realisasi & Penyedia (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'real' => $urlReal,
            'penyedia' => $urlPenyedia
        ]);
        
        $raw = $apiResults['real'];
        $rawPenyedia = $apiResults['penyedia'];

        $penyediaMap = [];
        foreach ($rawPenyedia as $p) {
            $kd = trim((string)($p['kd_nontender_pct'] ?? ''));
            if ($kd !== '') {
                $penyediaMap[$kd] = $p;
            }
        }
        
        // Build RUP Year Map from local DB as fallback
        $rupIds = array_filter(array_unique(array_map(function($i) { return trim((string)($i['kd_rup_paket'] ?? ($i['kd_rup'] ?? ''))); }, $raw)));
        $rupYearMap = [];
        if (!empty($rupIds)) {
            $db = \Config\Database::connect();
            $chunks = array_chunk($rupIds, 1000);
            foreach ($chunks as $chunk) {
                $res = $db->table('rup_penyedia')->select('kd_rup, tahun')->whereIn('kd_rup', $chunk)->get()->getResultArray();
                foreach ($res as $r) { $rupYearMap[$r['kd_rup']] = $r['tahun']; }
                
                $missingIds = array_diff($chunk, array_keys($rupYearMap));
                if (!empty($missingIds)) {
                    $res = $db->table('rup_swakelola')->select('kd_rup, tahun')->whereIn('kd_rup', $missingIds)->get()->getResultArray();
                    foreach ($res as $r) { $rupYearMap[$r['kd_rup']] = $r['tahun']; }
                }
            }
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        foreach ($raw as $item) {
            $rup = trim((string)($item['kd_rup_paket'] ?? ($item['kd_rup'] ?? '')));
            $yr = $item['tahun_anggaran'] ?? ($item['tahun'] ?? ($item['tahun_anggaran_paket'] ?? ($item['tahun_paket'] ?? null)));
            
            if (empty($yr) && !empty($rup) && isset($rupYearMap[$rup])) {
                $yr = $rupYearMap[$rup];
            }
            if (empty($yr)) $yr = date('Y');
            if ((int)$yr !== (int)$year) continue;

            $status = $item['status_nontender_pct_ket'] ?? ($item['status_nontender_pct'] ?? ($item['status'] ?? 'Selesai'));
            $statusLower = strtolower(trim($status));
            
            $isAllowed = false;
            foreach (['berjalan', 'selesai', 'tayang'] as $allowed) {
                if (strpos($statusLower, $allowed) !== false) {
                    $isAllowed = true;
                    break;
                }
            }
            
            if (!$isAllowed) {
                continue;
            }

            $kdPaket = $item['kd_nontender_pct'] ?? ($item['kd_pkt_dce'] ?? null);
            $supp = $kdPaket ? ($penyediaMap[$kdPaket] ?? []) : [];

            $batch[] = [
                'kd_rup' => $rup,
                'tahun' => (int)$yr,
                'kd_paket' => $kdPaket,
                'nama_paket' => $item['nama_paket'] ?? '',
                'nama_satker' => $item['nama_satker'] ?? '',
                'kd_satker' => $item['kd_satker'] ?? '',
                'pagu' => (float)($item['pagu'] ?? 0),
                'realisasi' => (float)($item['total_realisasi'] ?? ($item['nilai_realisasi'] ?? 0)),
                'nama_penyedia' => $supp['nama_penyedia'] ?? ($item['nama_penyedia'] ?? ''),
                'jenis_realisasi' => $supp['jenis_realisasi'] ?? ($item['jenis_realisasi'] ?? ''),
                'no_pembayaran' => $supp['no_realisasi'] ?? ($item['no_realisasi'] ?? ''),
                'jenis_pembayaran' => $item['bukti_pembayaran'] ?? null,
                'ket_realisasi' => $supp['ket_realisasi'] ?? null,
                'status' => $status,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }

    public function syncPencatatanSwakelola($year, $callback = null)
    {
        $urlList = $this->baseUrl . '/api/data/list-pencatatan-swakelola';
        $urlReal = $this->baseUrl . '/api/data/encatatan-swakelola-realisasi';
        $urlSatker = $this->baseUrl . '/api/data/master-satker';
        $model = new LpsePencatatanSwakelolaModel();

        if ($callback) $callback('Mengambil Daftar, Realisasi & Master Satker (Paralel)...');
        $apiResults = $this->fetchApisConcurrent([
            'satker' => $urlSatker,
            'list' => $urlList,
            'real' => $urlReal
        ]);
        
        $rawSatker = $apiResults['satker'];
        $rawList = $apiResults['list'];
        $rawReal = $apiResults['real'];

        $satkerMap = [];
        foreach ($rawSatker as $s) {
            $kd = $s['kd_satker'] ?? null;
            if ($kd) $satkerMap[$kd] = $s['nama_satker'] ?? '';
        }

        $realMap = [];
        foreach ($rawReal as $r) {
            $kd = trim((string)($r['kd_swakelola_pct'] ?? ($r['kd_swakelola'] ?? ($r['kd_paket'] ?? ''))));
            $rup = trim((string)($r['kd_rup_paket'] ?? ($r['kd_rup'] ?? '')));
            
            if ($kd !== '') {
                if (!isset($realMap[$kd])) $realMap[$kd] = ['val' => 0, 'items' => []];
                $realMap[$kd]['val'] += (float)($r['nilai_realisasi'] ?? 0);
                $realMap[$kd]['items'][] = $r;
            }
            if ($rup !== '') {
                if (!isset($realMap['rup_'.$rup])) $realMap['rup_'.$rup] = ['val' => 0, 'items' => []];
                $realMap['rup_'.$rup]['val'] += (float)($r['nilai_realisasi'] ?? 0);
                $realMap['rup_'.$rup]['items'][] = $r;
            }
        }

        $model->where('tahun', $year)->delete();
        $batch = []; $count = 0;
        
        // Build RUP Year Map from local DB as fallback
        $rupIds = array_filter(array_unique(array_map(function($i) { return trim((string)($i['kd_rup'] ?? '')); }, $rawList)));
        $rupIds = array_unique(array_merge($rupIds, array_filter(array_map(function($r) { return trim((string)($r['kd_rup_paket'] ?? ($r['kd_rup'] ?? ''))); }, $rawReal))));
        $rupYearMap = [];
        if (!empty($rupIds)) {
            $db = \Config\Database::connect();
            $chunks = array_chunk($rupIds, 1000);
            foreach ($chunks as $chunk) {
                $res = $db->table('rup_swakelola')->select('kd_rup, tahun')->whereIn('kd_rup', $chunk)->get()->getResultArray();
                foreach ($res as $r) { $rupYearMap[$r['kd_rup']] = $r['tahun']; }
                
                $missingIds = array_diff($chunk, array_keys($rupYearMap));
                if (!empty($missingIds)) {
                    $res = $db->table('rup_penyedia')->select('kd_rup, tahun')->whereIn('kd_rup', $missingIds)->get()->getResultArray();
                    foreach ($res as $r) { $rupYearMap[$r['kd_rup']] = $r['tahun']; }
                }
            }
        }

        foreach ($rawList as $item) {
            $kd = trim((string)($item['kd_swakelola_pct'] ?? ''));
            $rup = trim((string)($item['kd_rup'] ?? ''));
            
            $real = $realMap[$kd] ?? ($realMap['rup_'.$rup] ?? ['val' => 0, 'items' => []]);
            $yr = $item['tahun_anggaran'] ?? ($item['tahun'] ?? ($item['tahun_anggaran_paket'] ?? ($item['tahun_paket'] ?? null)));
            
            // Get best info from real items if available
            $bestReal = !empty($real['items']) ? $real['items'][0] : [];
            if (empty($yr) && !empty($bestReal)) {
                $yr = $bestReal['tahun_anggaran'] ?? ($bestReal['tahun'] ?? ($bestReal['tahun_anggaran_paket'] ?? ($bestReal['tahun_paket'] ?? null)));
            }
            if (empty($yr) && !empty($rup) && isset($rupYearMap[$rup])) {
                $yr = $rupYearMap[$rup];
            }
            if (empty($yr)) $yr = date('Y');
            if ((int)$yr !== (int)$year) continue;

            $kdSatker = $item['kd_satker'] ?? ($bestReal['kd_satker'] ?? '');

            $batch[] = [
                'kd_rup' => $rup,
                'tahun' => (int)$yr,
                'kd_paket' => $kd,
                'nama_paket' => $item['nama_paket'] ?? '',
                'nama_satker' => $item['nama_satker'] ?? ($satkerMap[$kdSatker] ?? ($bestReal['nama_satker'] ?? '')),
                'kd_satker' => $kdSatker,
                'pagu' => (float)($item['pagu'] ?? 0),
                'realisasi' => (float)$real['val'],
                'jenis_realisasi' => $item['metode'] ?? ($bestReal['jenis_realisasi'] ?? ''),
                'no_pembayaran' => $bestReal['no_realisasi'] ?? '',
                'ket_realisasi' => $item['ket_realisasi'] ?? ($bestReal['ket_realisasi'] ?? ($item['keterangan'] ?? '')),
                'nama_pelaksana' => $item['nama_pelaksana'] ?? ($bestReal['nama_pelaksana'] ?? '-'),
                'status' => $item['status'] ?? 'Selesai',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            if (count($batch) >= 500) { $model->insertBatch($batch); $count += count($batch); $batch = []; }
        }
        if (!empty($batch)) { $model->insertBatch($batch); $count += count($batch); }
        return $count;
    }
}
