<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\EpurchasingModel;

class Chatbot extends ResourceController
{
    public function index()
    {
        return view('components/chatbot');
    }

    public function ask()
    {
        $senderId = $this->request->getPost('sender_id');
        $isApiCall = !empty($senderId);

        if (!$this->request->isAJAX() && !$isApiCall) {
            return $this->failForbidden('Hanya menerima request AJAX.');
        }

        $message = $this->request->getPost('message');
        $settingsModel = new \App\Models\SettingsModel();
        
        $apiKey = $settingsModel->getSetting('chatbot_api_key', env('OPENAI_API_KEY'));
        $model = $settingsModel->getSetting('chatbot_model', 'gpt-5.4-mini');
        $apiUrl = $settingsModel->getSetting('chatbot_api_url', 'https://api.ai.cc/v1/chat/completions');

        if (empty($message)) {
            return $this->respond([
                'status' => 'error',
                'message' => 'Pesan tidak boleh kosong.'
            ], 400);
        }

        // --- Chatbot Memory ( Session / Cache for API ) ---
        $session = session();
        $cache = \Config\Services::cache();
        if ($senderId) {
            $history = $cache->get('chat_history_' . $senderId) ?? [];
        } else {
            $history = $session->get('chat_history') ?? [];
        }

        // Keep only last 4 messages to reduce token load
        if (count($history) > 4) $history = array_slice($history, -4);

        // Check if user asks for e‑purchasing winner
        if (preg_match('/pemenang\s+paket\s+(.+)/i', $message, $m)) {
            $paketName = trim($m[1], " .?,!\"'");
            $winnerData = $this->findPaketWinner($paketName);
            if ($winnerData) {
                $nama = $winnerData['nama_penyedia'] ?? 'Tidak diketahui';
                $kode = $winnerData['kode_penyedia'] ?? '';
                $reply = "Pemenang paket **{$paketName}** adalah **{$nama}**";
                if ($kode) $reply .= " (Kode: {$kode})";
                
                // Save to history
                $history[] = ['role' => 'user', 'content' => $message];
                $history[] = ['role' => 'assistant', 'content' => $reply];
                if ($senderId) {
                    $cache->save('chat_history_' . $senderId, $history, 3600);
                } else {
                    $session->set('chat_history', $history);
                }

                return $this->respond([
                    'status' => 'success',
                    'reply' => $reply
                ]);
            } else {
                return $this->respond([
                    'status' => 'error',
                    'message' => "Tidak ditemukan pemenang untuk paket **{$paketName}**."
                ], 404);
            }
        }

        if (empty($apiKey)) {
            return $this->respond([
                'status' => 'error',
                'message' => 'API Key tidak dikonfigurasi.'
            ], 500);
        }

        // Build smart context based on user's message keywords
        $smartContext = $this->_buildSmartContext($message);
        
        $response = $this->callOpenAI($message, $apiKey, $model, $apiUrl, $history, $smartContext);

        if (isset($response['error'])) {
            $errorMessage = is_array($response['error']) 
                ? ($response['error']['message'] ?? json_encode($response['error'])) 
                : $response['error'];

            // Log the error
            $logModel = new \App\Models\ChatbotLogModel();
            $logModel->insert([
                'user_id'    => session()->get('id'),
                'username'   => session()->get('username') ?? session()->get('nama') ?? ($senderId ?? 'API'),
                'ip_address' => $this->request->getIPAddress(),
                'question'   => $message,
                'response'   => 'ERROR: ' . $errorMessage,
                'model'      => $model,
                'status'     => 'error',
            ]);
            
            return $this->respond([
                'status' => 'error',
                'message' => 'Gagal terhubung ke AI. ' . $errorMessage
            ], 500);
        }

        $reply = $response['choices'][0]['message']['content'] ?? 'Maaf, saya tidak mengerti.';

        // Log the conversation
        $logModel = new \App\Models\ChatbotLogModel();
        $logModel->insert([
            'user_id'    => session()->get('id'),
            'username'   => session()->get('username') ?? session()->get('nama') ?? ($senderId ?? 'API'),
            'ip_address' => $this->request->getIPAddress(),
            'question'   => $message,
            'response'   => $reply,
            'model'      => $model,
            'status'     => 'success',
        ]);

        // Save to History
        $history[] = ['role' => 'user', 'content' => $message];
        $history[] = ['role' => 'assistant', 'content' => $reply];
        
        if ($senderId) {
            $cache->save('chat_history_' . $senderId, $history, 3600);
        } else {
            $session->set('chat_history', $history);
        }

        return $this->respond([
            'status' => 'success',
            'reply'  => $reply
        ]);
    }

    private function getRupData($type)
    {
        $currentYear = date('Y');
        $model = ($type === 'swakelola') ? new \App\Models\RupSwakelolaModel() : new \App\Models\RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        
        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        
        // Filter by OPD/Satker if user is a Satker
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }
        
        $data = $builder->findAll();
        
        return is_array($data) ? $data : [];
    }

    private function getPaguSummary($argsStr)
    {
        $args = json_decode($argsStr, true);
        $tipe = $args['tipe'] ?? 'penyedia';
        $opd = $args['opd'] ?? '';
        $metode = $args['metode'] ?? '';
        $jenis = $args['jenis_pengadaan'] ?? '';
        
        $data = $this->getRupData($tipe);
        
        if ($opd) {
            $data = array_filter($data, function($item) use ($opd) {
                return stripos($item['nama_satker'] ?? '', $opd) !== false;
            });
        }
        
        if ($metode) {
            $data = array_filter($data, function($item) use ($metode, $tipe) {
                $m = $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '') : ($item['tipe_swakelola'] ?? '');
                return stripos($m, $metode) !== false;
            });
        }
        
        if ($jenis && $tipe === 'penyedia') {
            $data = array_filter($data, function($item) use ($jenis) {
                return stripos($item['jenis_pengadaan'] ?? '', $jenis) !== false;
            });
        }
        
        $totalPagu = array_sum(array_column($data, 'pagu'));
        $totalPaket = count($data);
        $opdName = $opd ? ($data[array_key_first($data)]['nama_satker'] ?? $opd) : 'Seluruh OPD';

        return json_encode([
            'tipe' => $tipe,
            'opd' => $opdName,
            'metode' => $metode ?: 'Semua',
            'jenis_pengadaan' => $jenis ?: 'Semua',
            'total_paket' => $totalPaket,
            'total_pagu_rupiah' => $totalPagu
        ]);
    }

    private function searchPaket($argsStr)
    {
        $args = json_decode($argsStr, true);
        $query = $args['query'] ?? '';
        $opd = $args['opd'] ?? '';
        $metodeFilter = $args['metode'] ?? '';
        $jenisFilter = $args['jenis_pengadaan'] ?? '';
        $tipe = $args['tipe'] ?? 'penyedia';
        $sortPagu = $args['sort_pagu'] ?? ''; // 'terbesar' atau 'terkecil'
        
        $data = $this->getRupData($tipe);
        $results = [];
        $totalPaguAggregated = 0;

        foreach ($data as $item) {
            $match = true;

            // Search Keyword (Pencarian Luas - Multi word AND search)
            if ($query && $match) {
                // Menggabungkan berbagai field teks untuk pencarian yang lebih baik
                $searchContent = implode(' ', [
                    $item['nama_paket'] ?? '',
                    $item['uraian_pekerjaan'] ?? '',
                    $item['urarian_pekerjaan'] ?? '', // Typo handling untuk data penyedia
                    $item['spesifikasi_pekerjaan'] ?? '',
                    $item['kegiatan'] ?? '',
                    $item['nama_satker'] ?? '',
                    $item['metode_pengadaan'] ?? '',
                    $item['volume_pekerjaan'] ?? ''
                ]);

                $searchContentLower = strtolower($searchContent);
                $queryWords = explode(' ', strtolower($query));
                
                foreach ($queryWords as $word) {
                    $word = trim($word);
                    if ($word && strpos($searchContentLower, $word) === false) {
                        $match = false;
                        break;
                    }
                }
            }

            if ($opd && $match) {
                if (stripos($item['nama_satker'] ?? '', $opd) === false) {
                    $match = false;
                }
            }
            
            if ($metodeFilter && $match) {
                $m = $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '') : ($item['tipe_swakelola'] ?? '');
                if (stripos($m, $metodeFilter) === false) {
                    $match = false;
                }
            }

            // Filter Jenis Pengadaan (Hanya berlaku untuk tipe Penyedia)
            if ($jenisFilter && $match && $tipe === 'penyedia') {
                if (stripos($item['jenis_pengadaan'] ?? '', $jenisFilter) === false) {
                    $match = false;
                }
            }

            if ($match) {
                $pagu = (float) ($item['pagu'] ?? 0);
                $totalPaguAggregated += $pagu;

                $results[] = [
                    'opd' => $item['nama_satker'] ?? '',
                    'nama_paket' => $item['nama_paket'] ?? '',
                    'pagu' => $pagu,
                    'jenis_pengadaan' => $item['jenis_pengadaan'] ?? '-',
                    'metode' => $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '-') : ($item['tipe_swakelola'] ?? '-'),
                    'uraian' => $item['uraian_pekerjaan'] ?? ($item['urarian_pekerjaan'] ?? ($item['spesifikasi_pekerjaan'] ?? ($item['kegiatan'] ?? '-')))
                ];
            }
        }
        
        if ($sortPagu === 'terbesar') {
            usort($results, function($a, $b) {
                return $b['pagu'] <=> $a['pagu'];
            });
        } else if ($sortPagu === 'terkecil') {
            usort($results, function($a, $b) {
                return $a['pagu'] <=> $b['pagu'];
            });
        }

        $totalFound = count($results);
        // Limit the items inside PHP so OpenAI doesn't exceed max tokens
        $results = array_slice($results, 0, 15);

        if (empty($results)) {
            return json_encode(['message' => 'Tidak ditemukan data paket yang cocok.']);
        }

        return json_encode([
            'total_paket_ditemukan' => $totalFound,
            'total_pagu_seluruh_pencarian_rupiah' => $totalPaguAggregated,
            'keterangan' => $totalFound > 15 ? 'Menampilkan detail top 15 data saja.' : 'Menampilkan semua data detail.',
            'data_detail' => $results
        ]);
    }

    private function searchRealisasiPaket($argsStr)
    {
        $args = json_decode($argsStr, true);
        $query = $args['query'] ?? '';
        $opd = $args['opd'] ?? '';
        $type = $args['tipe'] ?? 'all'; // tender, nontender, pencatatan_nontender, swakelola, pencatatan_swakelola, epurchasing, all
        $year = $args['tahun'] ?? date('Y');
        $sortReal = $args['sort_realisasi'] ?? ''; // 'terbesar' atau 'terkecil'

        $db = \Config\Database::connect();
        
        $typesToSearch = [];
        if ($type === 'all') {
            $typesToSearch = ['tender', 'nontender', 'pencatatan_nontender', 'pencatatan_swakelola', 'epurchasing'];
        } else {
            $typesToSearch = [$type];
        }

        $results = [];
        $totalRealAggregated = 0;

        foreach ($typesToSearch as $t) {
            $builder = null;
            $realField = 'nilai_kontrak';
            
            if ($t === 'tender') {
                $builder = $db->table('lpse_tender');
                $realField = 'nilai_kontrak';
            } elseif ($t === 'nontender') {
                $builder = $db->table('lpse_nontender');
                $realField = 'nilai_kontrak';
            } elseif ($t === 'pencatatan_nontender') {
                $builder = $db->table('lpse_pencatatan_nontender');
                $realField = 'realisasi';
            } elseif ($t === 'swakelola' || $t === 'pencatatan_swakelola') {
                $builder = $db->table('lpse_pencatatan_swakelola');
                $realField = 'realisasi';
            } elseif ($t === 'epurchasing') {
                $builder = $db->table('epurchasing');
                $realField = 'total_harga';
            }

            if (!$builder) continue;

            // Strict Role/Satker checking
            $userRole = strtolower(session()->get('role') ?? '');
            $userSatker = session()->get('kd_satker');
            if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
                $builder->where('kd_satker', $userSatker);
            }

            if ($year && $year !== 'all') {
                $builder->where('tahun', $year);
            }

            $data = $builder->get()->getResultArray();

            foreach ($data as $item) {
                $match = true;

                // Search query against multiple text fields
                if ($query && $match) {
                    $searchContent = implode(' ', [
                        $item['nama_paket'] ?? '',
                        $item['nama_satker'] ?? '',
                        $item['nama_penyedia'] ?? '',
                        $item['nama_pelaksana'] ?? '',
                        $item['ket_realisasi'] ?? '',
                        $item['no_kontrak'] ?? '',
                        $item['no_pembayaran'] ?? ''
                    ]);

                    $searchContentLower = strtolower($searchContent);
                    $queryWords = explode(' ', strtolower($query));
                    
                    foreach ($queryWords as $word) {
                        $word = trim($word);
                        if ($word && strpos($searchContentLower, $word) === false) {
                            $match = false;
                            break;
                        }
                    }
                }

                if ($opd && $match) {
                    if (stripos($item['nama_satker'] ?? '', $opd) === false) {
                        $match = false;
                    }
                }

                if ($match) {
                    $realVal = (float)($item[$realField] ?? 0);
                    $totalRealAggregated += $realVal;

                    $results[] = [
                        'tipe_realisasi' => $t,
                        'kd_rup' => $item['kd_rup'] ?? ($item['rup_code'] ?? '-'),
                        'nama_paket' => $item['nama_paket'] ?? '',
                        'opd' => $item['nama_satker'] ?? '',
                        'pagu' => (float)($item['pagu'] ?? 0),
                        'realisasi' => $realVal,
                        'penyedia_atau_pelaksana' => $item['nama_penyedia'] ?? ($item['nama_pelaksana'] ?? '-'),
                        'keterangan' => $item['ket_realisasi'] ?? ($item['status'] ?? '-'),
                        'no_referensi' => $item['no_kontrak'] ?? ($item['no_pembayaran'] ?? '-')
                    ];
                }
            }
        }

        if ($sortReal === 'terbesar') {
            usort($results, function($a, $b) {
                return $b['realisasi'] <=> $a['realisasi'];
            });
        } else if ($sortReal === 'terkecil') {
            usort($results, function($a, $b) {
                return $a['realisasi'] <=> $b['realisasi'];
            });
        }

        $totalFound = count($results);
        $results = array_slice($results, 0, 15);

        if (empty($results)) {
            return json_encode(['message' => 'Tidak ditemukan data realisasi paket yang cocok dengan kriteria pencarian.']);
        }

        return json_encode([
            'total_paket_realisasi_ditemukan' => $totalFound,
            'total_realisasi_seluruh_pencarian_rupiah' => $totalRealAggregated,
            'keterangan' => $totalFound > 15 ? 'Menampilkan detail top 15 data realisasi saja.' : 'Menampilkan semua data detail realisasi.',
            'data_detail' => $results
        ]);
    }

    private function getOpdPaguRanking($argsStr)
    {
        $args = json_decode($argsStr, true);
        $tipe = $args['tipe'] ?? 'penyedia';
        $sort = $args['sort'] ?? 'terbesar'; // 'terbesar' atau 'terkecil'
        
        $data = $this->getRupData($tipe);
        
        // Group & sum by OPD
        $opdTotals = [];
        foreach ($data as $item) {
            $opd = $item['nama_satker'] ?? 'Tanpa Nama OPD';
            if (!isset($opdTotals[$opd])) {
                $opdTotals[$opd] = 0;
            }
            $opdTotals[$opd] += (float) ($item['pagu'] ?? 0);
        }
        
        if ($sort === 'terkecil') {
            asort($opdTotals);
        } else {
            arsort($opdTotals);
        }
        
        $results = [];
        $i = 1;
        foreach ($opdTotals as $opd => $totalPagu) {
            $results[] = [
                'peringkat' => $i,
                'opd' => $opd,
                'total_pagu_rupiah' => $totalPagu
            ];
            $i++;
            if ($i > 15) break; // Limit 15 OPD
        }

        $ket = $sort === 'terkecil' ? 'terkecil / terendah' : 'terbesar / tertinggi';

        return json_encode([
            'tipe' => $tipe,
            'keterangan' => "Menampilkan daftar Top 15 OPD dengan agregasi/akumulasi total pagu $ket.",
            'data' => $results
        ]);
    }

    private function getEpurchasingStats()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('epurchasing');
        
        $year = date('Y');
        $builder->where('tahun', $year);
        
        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }
        
        $builder->select("COUNT(*) as total_paket, SUM(total_harga) as total_realisasi");
        $row = $builder->get()->getRowArray();
        
        $builderTop = $db->table('epurchasing')->where('tahun', $year);
        $builderTop->select('nama_satker, SUM(total_harga) as total');
        $builderTop->groupBy('nama_satker');
        $builderTop->orderBy('total', 'DESC');
        $topSatkerRow = $builderTop->get()->getRowArray();
        $topSatker = $topSatkerRow ? $topSatkerRow['nama_satker'] . ' (Rp ' . number_format((float)$topSatkerRow['total'], 0, ',', '.') . ')' : '-';
        
        $summary = [
            'tahun_berjalan' => $year,
            'total_realisasi_rupiah' => (float)($row['total_realisasi'] ?? 0),
            'total_paket' => (int)($row['total_paket'] ?? 0),
            'top_satker_saat_ini' => $topSatker
        ];

        return json_encode($summary);
    }

    private function getLpseRealisasiStats($argsStr)
    {
        $args = json_decode($argsStr, true);
        $type = $args['tipe'] ?? 'tender'; // tender, nontender, pencatatan_nontender, swakelola, pencatatan_swakelola, epurchasing
        $year = $args['tahun'] ?? date('Y');

        $db = \Config\Database::connect();
        $builder = null;
        $sumField = 'nilai_kontrak';
        $paguField = 'pagu';

        if ($type === 'tender') {
            $builder = $db->table('lpse_tender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'nontender') {
            $builder = $db->table('lpse_nontender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'pencatatan_nontender') {
            $builder = $db->table('lpse_pencatatan_nontender');
            $sumField = 'realisasi';
        } elseif ($type === 'swakelola' || $type === 'pencatatan_swakelola') {
            $builder = $db->table('lpse_pencatatan_swakelola');
            $sumField = 'realisasi';
        } elseif ($type === 'epurchasing') {
            $builder = $db->table('epurchasing');
            $sumField = 'total_harga';
        }

        if (!$builder) {
            return json_encode(['error' => 'Tipe pengadaan tidak valid.']);
        }

        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        if ($year && $year !== 'all') {
            $builder->where('tahun', $year);
        }

        $builder->select("COUNT(*) as jumlah_paket, SUM($paguField) as total_pagu, SUM($sumField) as total_realisasi");
        $row = $builder->get()->getRowArray();

        $totalPagu = (float)($row['total_pagu'] ?? 0);
        $totalReal = (float)($row['total_realisasi'] ?? 0);
        $count = (int)($row['jumlah_paket'] ?? 0);

        return json_encode([
            'tipe_pengadaan' => $type,
            'tahun' => $year,
            'jumlah_paket' => $count,
            'total_pagu_rupiah' => $totalPagu,
            'total_realisasi_rupiah' => $totalReal,
            'persentase_realisasi' => $totalPagu > 0 ? round(($totalReal / $totalPagu) * 100, 2) . '%' : '0%'
        ]);
    }
    private function getMonevSummary()
    {
        $proyekModel = new \App\Models\MonevProyekModel();
        $jadwalModel = new \App\Models\MonevJadwalModel();
        $harianModel = new \App\Models\MonevHarianModel();
        $dashboard = new \App\Controllers\Dashboard();
        $dashboard->initController($this->request, $this->response, $this->logger);

        $proyekList = $proyekModel->findAll();
        
        $summaryData = [];
        $totalProyek = count($proyekList);
        $totalKritis = 0;
        
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $dashboard->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            $realisasiTerakhir = 0;
            if (!empty($scurve['actual'])) {
                foreach (array_reverse($scurve['actual']) as $val) {
                    if ($val !== null) { $realisasiTerakhir = $val; break; }
                }
            }
            
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $val) {
                    if ($val !== null) { $lastWeekIndex = $idx; }
                }
                if ($lastWeekIndex >= 0) {
                    $currentActual = $scurve['actual'][$lastWeekIndex] ?? 0;
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    $currentPlan = $scurve['plan'][$lastWeekIndex] ?? 0;
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }
            
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah (Kritis)';
                $totalKritis++;
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning (Perhatian)';
            } else {
                $statusIndikator = 'Hijau (Sesuai Rencana)';
            }
            
            $tglSelesai = strtotime($p['tgl_selesai']);
            if ($tglSelesai < time() && $p['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah (Kritis)';
                } elseif (strpos($statusIndikator, 'Merah') === false) {
                    $statusIndikator = 'Kuning (Perhatian)';
                }
            }
            
            $summaryData[] = [
                'nama_proyek' => $p['nama_proyek'],
                'opd' => $p['nama_satker'] ?? 'Dinas Terkait',
                'penyedia' => $p['nama_penyedia'],
                'realisasi_kumulatif' => $realisasiTerakhir . '%',
                'deviasi_kumulatif' => $deviasiTerakhir . '%',
                'deviasi_mingguan' => $deviasiMingguan . '%',
                'status' => $statusIndikator
            ];
        }

        return json_encode([
            'keterangan' => 'Ringkasan Monitoring dan Evaluasi Proyek Berjalan',
            'total_proyek' => $totalProyek,
            'total_proyek_kritis' => $totalKritis,
            'detail_proyek' => $summaryData
        ]);
    }

    private function getRealisasiPerOpd($argsStr)
    {
        $args = json_decode($argsStr, true);
        $type = $args['tipe'] ?? 'tender'; // tender, nontender, swakelola, epurchasing
        $year = $args['tahun'] ?? date('Y');

        $db = \Config\Database::connect();
        $builder = null;
        $sumField = 'nilai_kontrak';

        if ($type === 'tender') {
            $builder = $db->table('lpse_tender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'nontender' || $type === 'pencatatan_nontender') {
            $builder = $db->table('lpse_nontender');
            $sumField = 'nilai_kontrak';
            if ($type === 'pencatatan_nontender') {
                $builder = $db->table('lpse_pencatatan_nontender');
                $sumField = 'realisasi';
            }
        } elseif ($type === 'swakelola' || $type === 'pencatatan_swakelola') {
            $builder = $db->table('lpse_pencatatan_swakelola');
            $sumField = 'realisasi';
        } elseif ($type === 'epurchasing') {
            $builder = $db->table('epurchasing');
            $sumField = 'total_harga';
        }

        if (!$builder) {
            return json_encode(['error' => 'Tipe pengadaan tidak valid.']);
        }

        $builder->select("nama_satker as opd, SUM($sumField) as total_realisasi, COUNT(*) as jumlah_paket");
        if ($year && $year !== 'all') {
            $builder->where('tahun', $year);
        }
        $builder->groupBy('nama_satker');
        $builder->orderBy('total_realisasi', 'DESC');
        $data = $builder->get()->getResultArray();

        $totalKeseluruhan = 0;
        foreach ($data as $k => $v) {
            $data[$k]['total_realisasi'] = (float) $v['total_realisasi'];
            $totalKeseluruhan += $data[$k]['total_realisasi'];
        }

        return json_encode([
            'tipe_pengadaan' => $type,
            'tahun' => $year,
            'total_realisasi_seluruh_opd' => $totalKeseluruhan,
            'data_per_opd' => $data
        ]);
    }

    private function findPaketWinner($query)
    {
        $model = new EpurchasingModel();
        // Try to find a winner entry first (status indicating winner), fallback to any matching paket
        $winner = $model->where('status', 'pemenang')->like('nama_paket', $query)->first();
        if ($winner) return $winner;
        return $model->like('nama_paket', $query)->first();
    }
    private function _buildDataContext()
    {
        $db   = \Config\Database::connect();
        $year = date('Y');
        $ctx  = "=== DATA PENGADAAN REAL-TIME (Tahun {$year}) ===\n";

        // RUP Penyedia
        try {
            $pagu = $db->table('rup_penyedia')->where('tahun', $year)->selectSum('pagu', 'total')->get()->getRow();
            $jml  = $db->table('rup_penyedia')->where('tahun', $year)->countAllResults();
            $ctx .= "RUP Penyedia: Total Pagu = Rp " . number_format($pagu->total ?? 0, 0, ',', '.') . " ({$jml} paket)\n";
        } catch (\Exception $e) { $ctx .= "RUP Penyedia: Data tidak tersedia\n"; }

        // RUP Swakelola
        try {
            $pagus = $db->table('rup_swakelola')->where('tahun', $year)->selectSum('pagu', 'total')->get()->getRow();
            $jmls  = $db->table('rup_swakelola')->where('tahun', $year)->countAllResults();
            $ctx .= "RUP Swakelola: Total Pagu = Rp " . number_format($pagus->total ?? 0, 0, ',', '.') . " ({$jmls} paket)\n";
        } catch (\Exception $e) { $ctx .= "RUP Swakelola: Data tidak tersedia\n"; }

        // Realisasi Tender - dengan breakdown status
        try {
            $tender    = $db->table('lpse_tender')->where('tahun', $year)->selectSum('nilai_kontrak', 'total')->get()->getRow();
            $jmlt      = $db->table('lpse_tender')->where('tahun', $year)->countAllResults();
            $ctx .= "Realisasi Tender: Rp " . number_format($tender->total ?? 0, 0, ',', '.') . " (Total: {$jmlt} paket)\n";
            // Breakdown per status
            $statusTender = $db->query(
                "SELECT status, COUNT(*) as jml, SUM(nilai_kontrak) as total_nilai FROM lpse_tender WHERE tahun=? GROUP BY status ORDER BY jml DESC",
                [$year]
            )->getResultArray();
            foreach ($statusTender as $s) {
                $st = $s['status'] ?: '(tanpa status)';
                $ctx .= "  - Status '{$st}': {$s['jml']} paket (Rp " . number_format($s['total_nilai'] ?? 0, 0, ',', '.') . ")\n";
            }
        } catch (\Exception $e) { $ctx .= "Realisasi Tender: Data tidak tersedia\n"; }

        // Realisasi Non-Tender - dengan breakdown status
        try {
            $nt  = $db->table('lpse_nontender')->where('tahun', $year)->selectSum('nilai_kontrak', 'total')->get()->getRow();
            $jnt = $db->table('lpse_nontender')->where('tahun', $year)->countAllResults();
            $ctx .= "Realisasi Non-Tender: Rp " . number_format($nt->total ?? 0, 0, ',', '.') . " (Total: {$jnt} paket)\n";
            // Breakdown per status
            $statusNt = $db->query(
                "SELECT status, COUNT(*) as jml FROM lpse_nontender WHERE tahun=? GROUP BY status ORDER BY jml DESC",
                [$year]
            )->getResultArray();
            foreach ($statusNt as $s) {
                $st = $s['status'] ?: '(tanpa status)';
                $ctx .= "  - Status '{$st}': {$s['jml']} paket\n";
            }
        } catch (\Exception $e) { $ctx .= "Realisasi Non-Tender: Data tidak tersedia\n"; }

        // Realisasi E-Purchasing
        try {
            $ep  = $db->table('epurchasing')->where('tahun', $year)->selectSum('total_harga', 'total')->get()->getRow();
            $jep = $db->table('epurchasing')->where('tahun', $year)->countAllResults();
            $ctx .= "Realisasi E-Purchasing: Rp " . number_format($ep->total ?? 0, 0, ',', '.') . " ({$jep} transaksi)\n";
        } catch (\Exception $e) { $ctx .= "Realisasi E-Purchasing: Data tidak tersedia\n"; }

        // Pencatatan Non-Tender
        try {
            $pnt  = $db->table('lpse_pencatatan_nontender')->where('tahun', $year)->selectSum('realisasi', 'total')->get()->getRow();
            $jpnt = $db->table('lpse_pencatatan_nontender')->where('tahun', $year)->countAllResults();
            $ctx .= "Pencatatan Non-Tender: Rp " . number_format($pnt->total ?? 0, 0, ',', '.') . " ({$jpnt} paket)\n";
        } catch (\Exception $e) {}

        // Pencatatan Swakelola
        try {
            $psw  = $db->table('lpse_pencatatan_swakelola')->where('tahun', $year)->selectSum('realisasi', 'total')->get()->getRow();
            $jpsw = $db->table('lpse_pencatatan_swakelola')->where('tahun', $year)->countAllResults();
            $ctx .= "Pencatatan Swakelola: Rp " . number_format($psw->total ?? 0, 0, ',', '.') . " ({$jpsw} paket)\n";
        } catch (\Exception $e) {}

        // Monev Proyek - dengan breakdown status
        try {
            $totalProyek = $db->table('monev_proyek')->countAllResults();
            $statusMonev = $db->query(
                "SELECT status, COUNT(*) as jml FROM monev_proyek GROUP BY status ORDER BY jml DESC"
            )->getResultArray();
            $ctx .= "Monev Proyek: Total={$totalProyek} proyek\n";
            foreach ($statusMonev as $s) {
                $st = $s['status'] ?: '(tanpa status)';
                $ctx .= "  - Status '{$st}': {$s['jml']} proyek\n";
            }
        } catch (\Exception $e) { $ctx .= "Monev Proyek: Data tidak tersedia\n"; }

        $ctx .= "=== AKHIR DATA ===\n";
        return $ctx;
    }


    private function _buildSmartContext($message)
    {
        $db   = \Config\Database::connect();
        $year = date('Y');
        $ctx  = '';
        $msgLower = strtolower($message);

        // Helper: extract keyword by stripping common stopwords
        $stopwords = ['berapa', 'total', 'data', 'semua', 'seluruh', 'realisasi', 'pagu', 'nilai', 'kontrak',
                      'pengadaan', 'paket', 'tender', 'non-tender', 'epurchasing', 'e-purchasing', 'katalog',
                      'tampilkan', 'cari', 'ada', 'yang', 'dari', 'pada', 'di', 'ke', 'dan', 'atau',
                      'untuk', 'dengan', 'tahun', 'tahu', 'berjalan', 'ini'];
        $words = array_filter(explode(' ', preg_replace('/[^\w\s]/u', ' ', $msgLower)));
        $keywords = array_values(array_diff($words, $stopwords));
        $mainKeyword = count($keywords) > 0 ? $keywords[0] : '';

        // 1. Pencarian spesifik nama paket / barang di seluruh tabel realisasi
        if ($mainKeyword && strlen($mainKeyword) >= 3) {
            $ctx .= "\n=== HASIL PENCARIAN PAKET TERKAIT: '{$mainKeyword}' ===\n";
            $found = false;

            // E-Purchasing
            try {
                $builder = $db->table('epurchasing')
                    ->where('tahun', $year)
                    ->groupStart()
                        ->like('nama_paket', $mainKeyword)
                        ->orLike('nama_penyedia', $mainKeyword)
                    ->groupEnd();
                
                $agg = clone $builder;
                $aggRes = $agg->select('SUM(total_harga) as total, COUNT(id) as jml')->get()->getRow();
                
                $epRows = $builder->select('nama_paket, nama_penyedia, nama_satker, total_harga')
                    ->orderBy('total_harga', 'DESC')->limit(5)->get()->getResultArray();

                if ($epRows || ($aggRes && $aggRes->jml > 0)) {
                    $found = true;
                    $ctx .= "[E-Purchasing]\n";
                    if ($aggRes && $aggRes->jml > 0) {
                        $ctx .= "  Total Transaksi '{$mainKeyword}': Rp " . number_format($aggRes->total ?? 0, 0, ',', '.') . " (dari {$aggRes->jml} paket)\n";
                    }
                    if ($epRows) {
                        $ctx .= "  Top 5 Paket Terbesar:\n";
                        foreach ($epRows as $r) {
                            $ctx .= "    - {$r['nama_paket']} | Penyedia: {$r['nama_penyedia']} | OPD: {$r['nama_satker']} | Nilai: Rp " . number_format($r['total_harga'],0,',','.') . "\n";
                        }
                    }
                }
            } catch (\Exception $e) {}

            // Tender
            try {
                $builder = $db->table('lpse_tender')
                    ->where('tahun', $year)
                    ->groupStart()
                        ->like('nama_paket', $mainKeyword)
                        ->orLike('pemenang', $mainKeyword)
                    ->groupEnd();
                
                $agg = clone $builder;
                $aggRes = $agg->select('SUM(nilai_kontrak) as total, COUNT(id) as jml')->get()->getRow();

                $tRows = $builder->select('nama_paket, pemenang, nama_satker, nilai_kontrak')
                    ->orderBy('nilai_kontrak', 'DESC')->limit(5)->get()->getResultArray();
                
                if ($tRows || ($aggRes && $aggRes->jml > 0)) {
                    $found = true;
                    $ctx .= "[Tender]\n";
                    if ($aggRes && $aggRes->jml > 0) {
                        $ctx .= "  Total Tender '{$mainKeyword}': Rp " . number_format($aggRes->total ?? 0, 0, ',', '.') . " (dari {$aggRes->jml} paket)\n";
                    }
                    if ($tRows) {
                        $ctx .= "  Top 5 Paket Terbesar:\n";
                        foreach ($tRows as $r) {
                            $ctx .= "    - {$r['nama_paket']} | Pemenang: {$r['pemenang']} | OPD: {$r['nama_satker']} | Nilai: Rp " . number_format($r['nilai_kontrak'],0,',','.') . "\n";
                        }
                    }
                }
            } catch (\Exception $e) {}

            // Non-Tender
            try {
                $builder = $db->table('lpse_nontender')
                    ->where('tahun', $year)
                    ->groupStart()
                        ->like('nama_paket', $mainKeyword)
                        ->orLike('pemenang', $mainKeyword)
                    ->groupEnd();
                
                $agg = clone $builder;
                $aggRes = $agg->select('SUM(nilai_kontrak) as total, COUNT(id) as jml')->get()->getRow();

                $ntRows = $builder->select('nama_paket, pemenang, nama_satker, nilai_kontrak')
                    ->orderBy('nilai_kontrak', 'DESC')->limit(5)->get()->getResultArray();
                
                if ($ntRows || ($aggRes && $aggRes->jml > 0)) {
                    $found = true;
                    $ctx .= "[Non-Tender]\n";
                    if ($aggRes && $aggRes->jml > 0) {
                        $ctx .= "  Total Non-Tender '{$mainKeyword}': Rp " . number_format($aggRes->total ?? 0, 0, ',', '.') . " (dari {$aggRes->jml} paket)\n";
                    }
                    if ($ntRows) {
                        $ctx .= "  Top 5 Paket Terbesar:\n";
                        foreach ($ntRows as $r) {
                            $ctx .= "    - {$r['nama_paket']} | Pemenang: {$r['pemenang']} | OPD: {$r['nama_satker']} | Nilai: Rp " . number_format($r['nilai_kontrak'],0,',','.') . "\n";
                        }
                    }
                }
            } catch (\Exception $e) {}

            // Pencatatan Non-Tender
            try {
                $builder = $db->table('lpse_pencatatan_nontender')
                    ->where('tahun', $year)
                    ->groupStart()
                        ->like('nama_paket', $mainKeyword)
                        ->orLike('nama_penyedia', $mainKeyword)
                    ->groupEnd();
                
                $agg = clone $builder;
                $aggRes = $agg->select('SUM(realisasi) as total, COUNT(id) as jml')->get()->getRow();

                $pntRows = $builder->select('nama_paket, nama_penyedia, nama_satker, realisasi')
                    ->orderBy('realisasi', 'DESC')->limit(5)->get()->getResultArray();

                if ($pntRows || ($aggRes && $aggRes->jml > 0)) {
                    $found = true;
                    $ctx .= "[Pencatatan Non-Tender]\n";
                    if ($aggRes && $aggRes->jml > 0) {
                        $ctx .= "  Total Realisasi '{$mainKeyword}': Rp " . number_format($aggRes->total ?? 0, 0, ',', '.') . " (dari {$aggRes->jml} paket)\n";
                    }
                    if ($pntRows) {
                        $ctx .= "  Top 5 Paket Terbesar:\n";
                        foreach ($pntRows as $r) {
                            $ctx .= "    - {$r['nama_paket']} | Penyedia: {$r['nama_penyedia']} | OPD: {$r['nama_satker']} | Realisasi: Rp " . number_format($r['realisasi'],0,',','.') . "\n";
                        }
                    }
                }
            } catch (\Exception $e) {}

            // RUP Penyedia
            try {
                $builder = $db->table('rup_penyedia')
                    ->where('tahun', $year)
                    ->groupStart()
                        ->like('nama_paket', $mainKeyword)
                        ->orLike('uraian_pekerjaan', $mainKeyword)
                        ->orLike('urarian_pekerjaan', $mainKeyword)
                    ->groupEnd();
                
                $agg = clone $builder;
                $aggRes = $agg->select('SUM(pagu) as total, COUNT(id) as jml')->get()->getRow();

                $rupRows = $builder->select('nama_paket, nama_satker, pagu, metode_pengadaan')
                    ->orderBy('pagu', 'DESC')->limit(5)->get()->getResultArray();

                if ($rupRows || ($aggRes && $aggRes->jml > 0)) {
                    $found = true;
                    $ctx .= "[RUP Penyedia]\n";
                    if ($aggRes && $aggRes->jml > 0) {
                        $ctx .= "  Total Pagu '{$mainKeyword}': Rp " . number_format($aggRes->total ?? 0, 0, ',', '.') . " (dari {$aggRes->jml} paket)\n";
                    }
                    if ($rupRows) {
                        $ctx .= "  Top 5 Paket Terbesar:\n";
                        foreach ($rupRows as $r) {
                            $ctx .= "    - {$r['nama_paket']} | OPD: {$r['nama_satker']} | Pagu: Rp " . number_format($r['pagu'],0,',','.') . " | Metode: {$r['metode_pengadaan']}\n";
                        }
                    }
                }
            } catch (\Exception $e) {}

            if (!$found) {
                $ctx .= "  (Tidak ditemukan paket terkait kata kunci '{$mainKeyword}' di tahun {$year})\n";
            }
            $ctx .= "=== AKHIR HASIL PENCARIAN ===\n";
        }

        // 2. Jika ada keyword OPD / Satker, tampilkan realisasi per OPD tersebut
        $opdKeywords = ['dinas', 'badan', 'kantor', 'kecamatan', 'sekretariat', 'rsud', 'uptd', 'opd', 'satker'];
        foreach ($opdKeywords as $ok) {
            if (strpos($msgLower, $ok) !== false) {
                // Cari nama OPD dari pesan
                if (preg_match('/' . $ok . '[\s]+([\w\s]+)/iu', $message, $match)) {
                    $opdName = trim($match[1]);
                    if (strlen($opdName) >= 3) {
                        $ctx .= "\n=== DATA OPD: '{$opdName}' ===\n";
                        try {
                            $tRes = $db->table('lpse_tender')->where('tahun', $year)->like('nama_satker', $opdName)->selectSum('nilai_kontrak','total')->get()->getRow();
                            $ntRes = $db->table('lpse_nontender')->where('tahun', $year)->like('nama_satker', $opdName)->selectSum('nilai_kontrak','total')->get()->getRow();
                            $epRes = $db->table('epurchasing')->where('tahun', $year)->like('nama_satker', $opdName)->selectSum('total_harga','total')->get()->getRow();
                            $ctx .= "  Realisasi Tender: Rp " . number_format($tRes->total ?? 0, 0, ',', '.') . "\n";
                            $ctx .= "  Realisasi Non-Tender: Rp " . number_format($ntRes->total ?? 0, 0, ',', '.') . "\n";
                            $ctx .= "  Realisasi E-Purchasing: Rp " . number_format($epRes->total ?? 0, 0, ',', '.') . "\n";
                        } catch (\Exception $e) {}
                        $ctx .= "=== AKHIR DATA OPD ===\n";
                    }
                }
                break;
            }
        }

        // 3. Jika ada keyword penyedia / vendor
        if (preg_match('/(?:penyedia|vendor|rekanan|cv\.?|pt\.?)\s+([\w\s]+)/iu', $message, $vmatch)) {
            $vendorName = trim($vmatch[1]);
            if (strlen($vendorName) >= 3) {
                $ctx .= "\n=== DATA PENYEDIA: '{$vendorName}' ===\n";
                try {
                    $tVend = $db->table('lpse_tender')->like('pemenang', $vendorName)->where('tahun', $year)->selectSum('nilai_kontrak','total')->countAllResults(false);
                    $tVal  = $db->table('lpse_tender')->like('pemenang', $vendorName)->where('tahun', $year)->selectSum('nilai_kontrak','total')->get()->getRow();
                    $epVend = $db->table('epurchasing')->like('nama_penyedia', $vendorName)->where('tahun', $year)->selectSum('total_harga','total')->get()->getRow();
                    $ctx .= "  Tender: {$tVend} paket, Total: Rp " . number_format($tVal->total ?? 0, 0, ',', '.') . "\n";
                    $ctx .= "  E-Purchasing: Rp " . number_format($epVend->total ?? 0, 0, ',', '.') . "\n";
                } catch (\Exception $e) {}
            }
        }

        // 4. Pembelajaran dari Log Chatbot (User questions)
        try {
            $recentLogs = $db->table('chatbot_logs')
                             ->select('question')
                             ->orderBy('id', 'DESC')
                             ->limit(15)
                             ->get()
                             ->getResultArray();
            if ($recentLogs) {
                $ctx .= "\n=== TOPIK TERKINI YANG DITANYAKAN USER LAIN ===\n";
                $ctx .= "Sebagai referensi (pembelajaran tren), ini adalah hal-hal yang baru-baru ini ditanyakan:\n";
                $uniqueQs = [];
                foreach ($recentLogs as $lg) {
                    $q = trim($lg['question']);
                    if (!empty($q) && !in_array($q, $uniqueQs)) {
                        $uniqueQs[] = $q;
                        $ctx .= "- " . $q . "\n";
                    }
                }
                $ctx .= "=== AKHIR TOPIK TERKINI ===\n";
            }
        } catch (\Exception $e) {}

        // --- KNOWLEDGE BASE RAG SEARCH ---
        // Cari referensi dari library kepintaran AI untuk setiap pertanyaan
        try {
            $kbJson = $this->searchKnowledgeBase(json_encode(['query' => $message]));
            $kbParsed = json_decode($kbJson, true);
            if (isset($kbParsed['top_relevant_rules']) && is_array($kbParsed['top_relevant_rules'])) {
                $hasKb = false;
                $kbCtx = "\n=== REFERENSI DARI PUSTAKA / KNOWLEDGE BASE ===\n";
                foreach ($kbParsed['top_relevant_rules'] as $kbItem) {
                    // Hanya ambil jika kemiripan (similarity) cukup baik (misal > 0.25)
                    if (($kbItem['similarity'] ?? 0) > 0.25) {
                        $hasKb = true;
                        $kbCtx .= "- Sumber: " . ($kbItem['document'] ?? 'Pustaka') . "\n";
                        $kbCtx .= "  Isi: " . ($kbItem['text'] ?? '') . "\n\n";
                    }
                }
                if ($hasKb) {
                    $ctx .= $kbCtx;
                }
            }
        } catch (\Exception $e) {}

        return $ctx;
    }

    private function callOpenAI($message, $apiKey, $model, $url, $history = [], $smartContext = '')
    {
        // Inject real-time data context into system prompt (for models without tool calling support)
        $dataContext = $this->_buildDataContext();
        // Merge smart context (specific search results)
        if ($smartContext) {
            $dataContext .= "\n" . $smartContext;
        }

        $systemPrompt = "Kamu adalah AJIP (Asisten Jenius Informasi Pengadaan). 
        Kamu memiliki akses ke seluruh data pengadaan di aplikasi ini, termasuk RUP (Rencana Umum Pengadaan), REALISASI LPSE & E-Purchasing (Realisasi Tender, Non-Tender, Pencatatan Non-Tender, Pencatatan Swakelola, dan E-Purchasing), serta MONEV PROYEK (Monitoring dan Evaluasi).
        Kamu juga bertindak sebagai Auditor dan Konsultan Manajemen Proyek Konstruksi yang cerdas. Kamu dapat menganalisis laporan mingguan PPK, memvalidasi kewajaran alasan keterlambatan, mengevaluasi deviasi jadwal (S-Curve), dan memberikan saran mitigasi teknis jika proyek berstatus kritis (deviasi di bawah -10%).
        Tugasmu adalah membantu user terkait statistik, progres, deviasi proyek, lokasi spasial, dan realisasi tiap OPD secara akurat dan jenius.
        Kamu juga pintar mempelajari tren pertanyaan dari log chat user ('TOPIK TERKINI') untuk menyesuaikan konteks jawabanmu.
        
        ANALISIS KEWAJARAN HARGA:
        Jika pengguna meminta 'analisis harga', 'kewajaran harga', atau 'bandingkan harga' (misalnya barang katalog), kamu WAJIB memperkirakan harga pasar online untuk barang tersebut berdasarkan general knowledge-mu. Bandingkan harga dari data pengadaan (jika ada) dengan estimasi harga pasar online, lalu berikan analisis komprehensif apakah harga tersebut Wajar, Terlalu Mahal, atau Murah, beserta rasionalisasinya.

        Selalu format angka rupiah (contoh: Rp 10.000.000) dan persentase dengan rapi agar mudah dibaca.

        BATASAN MUTLAK DAN KETAT:
        Kamu HANYA diperbolehkan menjawab pertanyaan, menganalisis, atau memberikan penjelasan tentang hal-hal yang berkaitan dengan PENGADAAN BARANG/JASA PEMERINTAH (seperti RUP, LPSE, Tender, Non-Tender, E-Purchasing/E-Katalog, Proyek Konstruksi, Metode Kontrak, dan S-Curve).
        Jika pengguna bertanya di luar ruang lingkup pengadaan barang/jasa pemerintah (misalnya bertanya tentang matematika umum, fisika, sejarah umum, resep masakan, tips percintaan, tugas coding/pemrograman umum, gosip artis, lelucon umum, dsb.), kamu WAJIB MENOLAK dengan sopan dan menegaskan bahwa kamu dirancang khusus HANYA untuk membantu konsultasi seputar pengadaan barang/jasa pemerintah.

        PENGGUNAAN KNOWLEDGE BASE (RAG):
        Jika dalam konteks data di bawah terdapat 'REFERENSI DARI PUSTAKA / KNOWLEDGE BASE', kamu WAJIB menjadikan referensi tersebut sebagai dasar acuan utama dan pertama sebelum kamu memberikan analisis, opini, jawaban, atau saran. Pastikan jawabanmu selaras dengan referensi tersebut.

        PENTING: Di akhir setiap jawabanmu, SELALU berikan daftar pilihan lanjutan menggunakan nomor urut (1, 2, 3) agar user bisa membalas dengan nomor untuk pertanyaan selanjutnya. Pastikan daftar pilihan relevan dengan konteks pembahasan saat ini.

        {$dataContext}";

        $messages = [['role' => 'system', 'content' => $systemPrompt]];
        
        foreach ($history as $h) {
            // Filter out tool_call messages since model doesn't support it
            if (isset($h['role']) && in_array($h['role'], ['user', 'assistant'])) {
                $filteredMsg = ['role' => $h['role'], 'content' => $h['content'] ?? ''];
                if (!empty($filteredMsg['content'])) {
                    $messages[] = $filteredMsg;
                }
            }
        }

        $messages[] = ['role' => 'user', 'content' => $message];

        $retryCount = 0;
        $maxRetries = 3;
        $delay = 1000000;
        $response = '';
        $error = '';
        $responseArray = [];

        do {
            $data = [
                'model'       => $model,
                'messages'    => $messages,
                'max_tokens'  => 2000,
                'temperature' => 0.7
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
                'api-key: ' . $apiKey
            ]);

            $response = curl_exec($ch);
            $error    = curl_error($ch);
            curl_close($ch);

            // Debugging log
            file_put_contents(FCPATH . 'debug_chat.log', "Payload: " . json_encode($data) . "\nResponse: " . $response . "\nCurlError: " . $error . "\n");

            if ($error) break;

            $responseArray = json_decode($response, true);
            if (isset($responseArray['error'])) {
                $errCode = $responseArray['error']['code'] ?? '';
                $errMsg  = $responseArray['error']['message'] ?? '';
                if ($errCode == '429' || strpos(strtolower($errMsg), 'too many requests') !== false || strpos(strtolower($errMsg), 'rate limit') !== false) {
                    $retryCount++;
                    if ($retryCount <= $maxRetries) {
                        usleep($delay);
                        $delay *= 2;
                        continue;
                    }
                }
            }
            break;
        } while ($retryCount <= $maxRetries);

        if ($error) return ['error' => $error];
        if (isset($responseArray['error'])) return $responseArray;

        $responseMessage = $responseArray['choices'][0]['message'] ?? null;
        if (!$responseMessage) {
            return ['error' => 'Invalid response from AI'];
        }

        return $responseArray;
    }


    public function searchKnowledgeBase($argsStr)
    {
        $settingsModel = new \App\Models\SettingsModel();
        $apiKey = $settingsModel->getSetting('embedding_api_key', env('OPENAI_API_KEY'));
        $url = $settingsModel->getSetting('embedding_api_url', 'https://api.openai.com/v1/embeddings');
        $modelName = $settingsModel->getSetting('embedding_model', 'text-embedding-3-small');

        $args = json_decode($argsStr, true);
        $query = $args['query'] ?? '';
        if (!$query) return json_encode(['error' => 'Query kosong']);

        // Dapatkan vektor dari query
        $data = [
            'model' => $modelName,
            'input' => $query
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        curl_close($ch);
        $resObj = json_decode($response, true);
        if (!isset($resObj['data'][0]['embedding'])) {
            return json_encode(['error' => 'Gagal mendapatkan embedding', 'response' => $response]);
        }

        $queryEmbedding = $resObj['data'][0]['embedding'];

        // Ambil data dari DB
        $db = \Config\Database::connect();
        try {
            $chunks = $db->table('chatbot_knowledge')->get()->getResultArray();
        } catch (\Exception $e) {
            return json_encode(['error' => 'Belum ada library knowledge yang diunggah']);
        }

        if (empty($chunks)) {
            return json_encode(['error' => 'Belum ada library knowledge yang diunggah']);
        }

        $results = [];
        foreach ($chunks as $chunk) {
            $dbVec = json_decode($chunk['embedding_vector'], true);
            if (!$dbVec) continue;

            $similarity = $this->cosineSimilarity($queryEmbedding, $dbVec);
            $results[] = [
                'document' => $chunk['document_title'],
                'text' => $chunk['chunk_text'],
                'similarity' => $similarity
            ];
        }

        // Urutkan berdasarkan similarity tertinggi
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });

        // Ambil top 4
        $top = array_slice($results, 0, 4);
        return json_encode(['top_relevant_rules' => $top]);
    }

    private function cosineSimilarity($vec1, $vec2) {
        $dotProduct = 0;
        $normA = 0;
        $normB = 0;
        foreach ($vec1 as $i => $v) {
            $dotProduct += $v * $vec2[$i];
            $normA += pow($v, 2);
            $normB += pow($vec2[$i], 2);
        }
        if ($normA == 0 || $normB == 0) return 0;
        return $dotProduct / (sqrt($normA) * sqrt($normB));
    }

    private function getVendorPerformance($argsStr)
    {
        $args = json_decode($argsStr, true);
        $vendor = $args['nama_penyedia'] ?? '';
        if (!$vendor) return json_encode(['error' => 'Nama penyedia kosong']);

        $db = \Config\Database::connect();
        $summary = [];

        // LPSE Tender
        try {
            $tender = $db->table('lpse_tender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->countAllResults(false);
            $tenderVal = $db->table('lpse_tender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->get()->getRow()->total ?? 0;
            $tenderDetail = $db->table('lpse_tender')->like('pemenang', $vendor)->select('nama_paket, nilai_penawaran, tahun')->limit(5)->get()->getResultArray();
            $summary['Tender'] = ['jumlah_paket' => $tender, 'total_nilai' => $tenderVal, 'contoh_paket' => $tenderDetail];
        } catch (\Exception $e) {}

        // LPSE Non Tender
        try {
            $nontender = $db->table('lpse_nontender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->countAllResults(false);
            $ntVal = $db->table('lpse_nontender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->get()->getRow()->total ?? 0;
            $ntDetail = $db->table('lpse_nontender')->like('pemenang', $vendor)->select('nama_paket, nilai_penawaran, tahun')->limit(5)->get()->getResultArray();
            $summary['Non_Tender'] = ['jumlah_paket' => $nontender, 'total_nilai' => $ntVal, 'contoh_paket' => $ntDetail];
        } catch (\Exception $e) {}

        // LPSE Pencatatan Non Tender
        try {
            $pencatatanNontender = $db->table('lpse_pencatatan_nontender')->like('nama_penyedia', $vendor)->selectSum('realisasi', 'total')->countAllResults(false);
            $pntVal = $db->table('lpse_pencatatan_nontender')->like('nama_penyedia', $vendor)->selectSum('realisasi', 'total')->get()->getRow()->total ?? 0;
            $pntDetail = $db->table('lpse_pencatatan_nontender')->like('nama_penyedia', $vendor)->select('nama_paket, realisasi as nilai_penawaran, tahun')->limit(5)->get()->getResultArray();
            $summary['Pencatatan_Non_Tender'] = ['jumlah_paket' => $pencatatanNontender, 'total_nilai' => $pntVal, 'contoh_paket' => $pntDetail];
        } catch (\Exception $e) {}

        // EPurchasing
        try {
            $epur = $db->table('epurchasing')->like('nama_penyedia', $vendor)->selectSum('total_harga', 'total')->countAllResults(false);
            $epurVal = $db->table('epurchasing')->like('nama_penyedia', $vendor)->selectSum('total_harga', 'total')->get()->getRow()->total ?? 0;
            $epurDetail = $db->table('epurchasing')->like('nama_penyedia', $vendor)->select('nama_paket, total_harga, tahun')->limit(5)->get()->getResultArray();
            $summary['E_Purchasing'] = ['jumlah_paket' => $epur, 'total_nilai' => $epurVal, 'contoh_paket' => $epurDetail];
        } catch (\Exception $e) {}

        // Monev
        try {
            $monevBuilder = $db->table('monev_proyek')->like('nama_penyedia', $vendor);
            $monevTotal = $monevBuilder->countAllResults(false);
            $monevTerlambat = $db->table('monev_proyek')->like('nama_penyedia', $vendor)->where('status', 'Terlambat')->countAllResults();
            $monevSelesai = $db->table('monev_proyek')->like('nama_penyedia', $vendor)->where('status', 'Selesai')->countAllResults();
            
            $monevDetail = $db->table('monev_proyek')
                              ->like('nama_penyedia', $vendor)
                              ->select('nama_proyek, nilai_kontrak, status, tgl_mulai, tgl_selesai')
                              ->orderBy('tgl_mulai', 'DESC')
                              ->limit(10)
                              ->get()
                              ->getResultArray();

            $summary['Monev_Proyek'] = [
                'total_proyek_dimonev' => $monevTotal, 
                'selesai' => $monevSelesai, 
                'terlambat' => $monevTerlambat,
                'detail_proyek' => $monevDetail
            ];
        } catch (\Exception $e) {}

        return json_encode([
            'nama_penyedia_dicari' => $vendor,
            'summary_kinerja' => $summary
        ]);
    }



    private function analyzeMonevProject($argsStr)
    {
        $args = json_decode($argsStr, true);
        $namaProyek = $args['nama_proyek'] ?? '';
        
        $proyekModel = new \App\Models\MonevProyekModel();
        $jadwalModel = new \App\Models\MonevJadwalModel();
        $harianModel = new \App\Models\MonevHarianModel();
        
        $builder = $proyekModel->builder();
        
        if (strtolower($namaProyek) === 'kritis') {
            // Find all projects, we will compute them below
            $proyekList = $proyekModel->findAll();
        } else if (!empty($namaProyek)) {
            $builder->like('nama_proyek', $namaProyek);
            $proyekList = $proyekModel->findAll();
        } else {
            $proyekList = $proyekModel->findAll();
        }

        if (empty($proyekList)) {
            return json_encode(['error' => 'Proyek tidak ditemukan.']);
        }

        $dashboard = new \App\Controllers\Dashboard();
        $dashboard->initController($this->request, $this->response, $this->logger);

        $results = [];
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $dashboard->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            // Extract latest "Kendala" and "Keterangan"
            $laporanPenting = [];
            foreach (array_reverse($harianItems) as $hari) {
                if (!empty($hari['kendala']) || !empty($hari['keterangan'])) {
                    $laporanPenting[] = [
                        'tanggal' => $hari['tanggal'],
                        'kendala' => $hari['kendala'],
                        'keterangan' => $hari['keterangan'],
                        'progres_hari_itu' => $hari['progres_persen'] . '%'
                    ];
                }
                if (count($laporanPenting) >= 5) break; // Limit top 5 recent issues
            }

            $isKritis = ($deviasiTerakhir <= -10);

            // Filter if user specifically asked for "kritis"
            if (strtolower($namaProyek) === 'kritis' && !$isKritis) {
                continue;
            }

            // KNOWLEDGE BASE RAG SEMANTIC ANALYSIS:
            // Cari referensi regulasi/SOP penanganan kendala proyek dari pustaka kecerdasan jika proyek tidak aman / kritis
            $pustakaKecerdasan = [];
            if ($deviasiTerakhir < 0 || !empty($laporanPenting)) {
                // Gunakan jenis pekerjaan dan kendala utama sebagai query RAG
                $mainKendala = !empty($laporanPenting) ? ($laporanPenting[0]['kendala'] ?? '') : '';
                $searchQuery = ($p['jenis_pekerjaan'] ?? '') . ' ' . $mainKendala . ' keterlambatan penanganan denda';
                $searchQuery = trim(preg_replace('/\s+/', ' ', $searchQuery));

                if ($searchQuery) {
                    try {
                        $kbJson = $this->searchKnowledgeBase(json_encode(['query' => $searchQuery]));
                        $kbParsed = json_decode($kbJson, true);
                        if (isset($kbParsed['top_relevant_rules']) && is_array($kbParsed['top_relevant_rules'])) {
                            foreach (array_slice($kbParsed['top_relevant_rules'], 0, 3) as $kbItem) {
                                // Hanya ambil jika kemiripan (similarity) cukup baik (misal > 0.3)
                                if (($kbItem['similarity'] ?? 0) > 0.3) {
                                    $pustakaKecerdasan[] = [
                                        'sumber_panduan' => $kbItem['document'] ?? 'Pustaka Pengadaan',
                                        'klausul_referensi' => $kbItem['text'] ?? '',
                                        'tingkat_relevansi' => round(($kbItem['similarity'] ?? 0) * 100, 1) . '%'
                                    ];
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        // Silent fail if KB search has errors, to ensure chatbot keeps running smoothly
                    }
                }
            }

            $results[] = [
                'nama_proyek' => $p['nama_proyek'],
                'penyedia' => $p['nama_penyedia'],
                'tgl_mulai' => $p['tgl_mulai'],
                'tgl_selesai' => $p['tgl_selesai'],
                'nilai_kontrak' => (float)$p['nilai_kontrak'],
                'status_proyek' => $p['status'],
                'deviasi_terakhir' => $deviasiTerakhir . '%',
                'status_indikator' => $isKritis ? 'Kritis' : ($deviasiTerakhir <= -5 ? 'Perhatian' : 'Aman'),
                'pejabat_ppk' => $p['ppk'] ?? '-',
                'lokasi_spesifik' => $p['lokasi'] ?? '-',
                'sumber_dana' => $p['sumber_dana'] ?? '-',
                'jenis_pekerjaan' => $p['jenis_pekerjaan'] ?? '-',
                'metode_kontrak' => $p['metode_kontrak'] ?? '-',
                'gps_koordinat' => $p['gps_kordinat'] ?? '-',
                'polygon_lokasi_geojson' => $p['polygon_lokasi'] ?? '-',
                '5_laporan_kendala_terakhir' => $laporanPenting,
                'rujukan_regulasi_dan_sop_penanganan_rag' => $pustakaKecerdasan // Expose RAG matches directly to AI context!
            ];
            
            if (count($results) >= 5) break; // Limit output size to prevent token limits
        }

        if (empty($results)) {
            return json_encode(['message' => 'Tidak ada proyek kritis atau data yang sesuai kriteria.']);
        }

        return json_encode([
            'catatan' => 'Data deviasi didapat dari perhitungan kumulatif aktual dikurangi rencana S-Curve. Jika deviasi minus, proyek terlambat.',
            'data' => $results
        ]);
    }

    /**
     * Analisis Kewajaran Harga (Price Reasonableness Analysis)
     * Membandingkan harga pengadaan dengan estimasi harga pasar/referensi
     */
    private function analyzePriceReasonableness($argsStr)
    {
        $args = json_decode($argsStr, true);
        $itemName = $args['nama_barang'] ?? $args['nama_paket'] ?? '';
        $hargaPengadaan = $args['harga_pengadaan'] ?? 0;
        $satuan = $args['satuan'] ?? 'unit';
        $volume = $args['volume'] ?? 1;
        $kategori = $args['kategori'] ?? ''; // konstruksi, barang, jasa, konsultansi
        $spesifikasi = $args['spesifikasi'] ?? '';
        $lokasi = $args['lokasi'] ?? '';
        
        if (!$itemName) {
            return json_encode(['error' => 'Nama barang/paket wajib diisi untuk analisis kewajaran harga.']);
        }

        $db = \Config\Database::connect();
        $year = date('Y');
        
        // 1. Cari data historis pengadaan serupa di database internal
        $historicalData = [];
        $similarItems = [];
        
        // Cari di RUP Penyedia
        try {
            $builder = $db->table('rup_penyedia')
                ->where('tahun', $year)
                ->groupStart()
                    ->like('nama_paket', $itemName)
                    ->orLike('uraian_pekerjaan', $itemName)
                    ->orLike('urarian_pekerjaan', $itemName)
                    ->orLike('spesifikasi_pekerjaan', $itemName)
                ->groupEnd();
            
            if ($kategori) {
                $builder->where('jenis_pengadaan', $kategori);
            }
            
            $rupData = $builder->select('nama_paket, pagu, volume, satuan, jenis_pengadaan, metode_pengadaan, nama_satker')
                ->orderBy('pagu', 'DESC')
                ->limit(10)
                ->get()->getResultArray();
            
            foreach ($rupData as $r) {
                $hargaSatuan = $r['volume'] > 0 ? ($r['pagu'] / $r['volume']) : 0;
                $similarItems[] = [
                    'sumber' => 'RUP Penyedia',
                    'nama_paket' => $r['nama_paket'],
                    'harga_satuan_referensi' => $hargaSatuan,
                    'volume' => $r['volume'],
                    'satuan' => $r['satuan'] ?? 'unit',
                    'metode' => $r['metode_pengadaan'] ?? '-',
                    'opd' => $r['nama_satker'] ?? '-'
                ];
            }
        } catch (\Exception $e) {}

        // Cari di Realisasi Tender
        try {
            $builder = $db->table('lpse_tender')
                ->where('tahun', $year)
                ->groupStart()
                    ->like('nama_paket', $itemName)
                    ->orLike('pemenang', $itemName)
                ->groupEnd();
            
            $tenderData = $builder->select('nama_paket, nilai_kontrak, nilai_penawaran, pagu, nama_satker, pemenang')
                ->orderBy('nilai_kontrak', 'DESC')
                ->limit(10)
                ->get()->getResultArray();
            
            foreach ($tenderData as $r) {
                // Estimasi volume dari pagu/nilai kontrak jika tidak ada volume eksplisit
                $similarItems[] = [
                    'sumber' => 'Realisasi Tender',
                    'nama_paket' => $r['nama_paket'],
                    'harga_kontrak' => (float)($r['nilai_kontrak'] ?? 0),
                    'harga_penawaran' => (float)($r['nilai_penawaran'] ?? 0),
                    'pagu' => (float)($r['pagu'] ?? 0),
                    'pemenang' => $r['pemenang'] ?? '-',
                    'opd' => $r['nama_satker'] ?? '-'
                ];
            }
        } catch (\Exception $e) {}

        // Cari di E-Purchasing
        try {
            $builder = $db->table('epurchasing')
                ->where('tahun', $year)
                ->groupStart()
                    ->like('nama_paket', $itemName)
                    ->orLike('nama_penyedia', $itemName)
                ->groupEnd();
            
            $epData = $builder->select('nama_paket, total_harga, nama_penyedia, nama_satker, spesifikasi')
                ->orderBy('total_harga', 'DESC')
                ->limit(10)
                ->get()->getResultArray();
            
            foreach ($epData as $r) {
                $similarItems[] = [
                    'sumber' => 'E-Purchasing',
                    'nama_paket' => $r['nama_paket'],
                    'harga_total' => (float)($r['total_harga'] ?? 0),
                    'penyedia' => $r['nama_penyedia'] ?? '-',
                    'opd' => $r['nama_satker'] ?? '-',
                    'spesifikasi' => $r['spesifikasi'] ?? '-'
                ];
            }
        } catch (\Exception $e) {}

        // Cari di Pencatatan Non-Tender
        try {
            $builder = $db->table('lpse_pencatatan_nontender')
                ->where('tahun', $year)
                ->like('nama_paket', $itemName);
            
            $pntData = $builder->select('nama_paket, realisasi, nama_penyedia, nama_satker')
                ->orderBy('realisasi', 'DESC')
                ->limit(10)
                ->get()->getResultArray();
            
            foreach ($pntData as $r) {
                $similarItems[] = [
                    'sumber' => 'Pencatatan Non-Tender',
                    'nama_paket' => $r['nama_paket'],
                    'realisasi' => (float)($r['realisasi'] ?? 0),
                    'penyedia' => $r['nama_penyedia'] ?? '-',
                    'opd' => $r['nama_satker'] ?? '-'
                ];
            }
        } catch (\Exception $e) {}

        // 2. Estimasi Harga Pasar (Market Price Estimation) - menggunakan general knowledge AI
        // Kita akan meminta AI untuk memberikan estimasi berdasarkan nama barang
        $marketEstimate = $this->estimateMarketPrice($itemName, $satuan, $kategori, $spesifikasi, $lokasi);

        // 3. Analisis Komparatif
        $analysis = $this->performPriceAnalysis($hargaPengadaan, $volume, $satuan, $similarItems, $marketEstimate, $itemName, $kategori);

        return json_encode([
            'item_analisis' => $itemName,
            'harga_pengadaan' => $hargaPengadaan,
            'volume' => $volume,
            'satuan' => $satuan,
            'total_nilai_pengadaan' => $hargaPengadaan * $volume,
            'kategori' => $kategori,
            'spesifikasi' => $spesifikasi,
            'lokasi' => $lokasi,
            'data_referensi_internal' => array_slice($similarItems, 0, 15),
            'estimasi_harga_pasar' => $marketEstimate,
            'analisis_kewajaran' => $analysis
        ]);
    }

    /**
     * Estimasi harga pasar menggunakan general knowledge (akan diisi oleh AI via prompt)
     * Method ini mengembalikan struktur yang akan diisi oleh AI di system prompt
     */
    private function estimateMarketPrice($itemName, $satuan, $kategori, $spesifikasi, $lokasi)
    {
        // Return struktur untuk diisi oleh AI berdasarkan general knowledge
        return [
            'catatan' => 'Estimasi harga pasar berdasarkan general knowledge AI untuk kategori: ' . ($kategori ?: 'umum') . ', satuan: ' . $satuan . ', lokasi: ' . ($lokasi ?: 'Indonesia umum'),
            'rentang_harga_satuan_min' => 0,
            'rentang_harga_satuan_max' => 0,
            'harga_median_pasar' => 0,
            'sumber_referensi' => ['E-katalog/LKPP', 'Harga pasar online (Tokopedia, Bukalapak, dll)', 'Harga referensi Kementerian terkait', 'Survei pasar lokal'],
            'faktor_pengaruh' => [
                'Lokasi geografis (biaya transport/logistik)',
                'Spesifikasi teknis/merk/kualitas',
                'Volume pembelian (economies of scale)',
                'Waktu pengadaan (inflasi, musim)',
                'Metode pengadaan (tender/non-tender/e-katalog)'
            ]
        ];
    }

    /**
     * Melakukan analisis komparatif harga
     */
    private function performPriceAnalysis($hargaPengadaan, $volume, $satuan, $similarItems, $marketEstimate, $itemName, $kategori)
    {
        $hargaSatuanPengadaan = $volume > 0 ? ($hargaPengadaan / $volume) : $hargaPengadaan;
        $totalNilai = $hargaPengadaan * $volume;
        
        // Kumpulkan harga satuan dari data internal
        $internalPrices = [];
        foreach ($similarItems as $item) {
            if (isset($item['harga_satuan_referensi']) && $item['harga_satuan_referensi'] > 0) {
                $internalPrices[] = $item['harga_satuan_referensi'];
            } elseif (isset($item['harga_kontrak']) && isset($item['volume']) && $item['volume'] > 0) {
                $internalPrices[] = $item['harga_kontrak'] / $item['volume'];
            } elseif (isset($item['harga_penawaran']) && isset($item['volume']) && $item['volume'] > 0) {
                $internalPrices[] = $item['harga_penawaran'] / $item['volume'];
            } elseif (isset($item['realisasi']) && isset($item['volume']) && $item['volume'] > 0) {
                $internalPrices[] = $item['realisasi'] / $item['volume'];
            } elseif (isset($item['harga_total']) && isset($item['volume']) && $item['volume'] > 0) {
                $internalPrices[] = $item['harga_total'] / $item['volume'];
            }
        }

        $stats = [];
        if (!empty($internalPrices)) {
            sort($internalPrices);
            $count = count($internalPrices);
            $stats['internal'] = [
                'jumlah_data' => $count,
                'min' => $internalPrices[0],
                'max' => $internalPrices[$count - 1],
                'median' => $internalPrices[floor($count / 2)],
                'avg' => array_sum($internalPrices) / $count,
                'q1' => $internalPrices[floor($count * 0.25)],
                'q3' => $internalPrices[floor($count * 0.75)]
            ];
        }

        // Analisis terhadap estimasi pasar (placeholder - akan diisi AI)
        $marketMin = $marketEstimate['rentang_harga_satuan_min'] ?? 0;
        $marketMax = $marketEstimate['rentang_harga_satuan_max'] ?? 0;
        $marketMedian = $marketEstimate['harga_median_pasar'] ?? 0;

        $kesimpulan = 'PERLU_ANALISIS_AI';
        $rasio = 0;
        $status = 'Tidak Dapat Dianalisis';
        $detail = '';

        if (!empty($stats['internal'])) {
            $medianInternal = $stats['internal']['median'];
            $rasio = $medianInternal > 0 ? ($hargaSatuanPengadaan / $medianInternal) : 0;
            
            if ($rasio <= 0.8) {
                $status = 'SANGAT MURAH (Di Bawah Pasar)';
                $kesimpulan = 'Harga pengadaan jauh di bawah median historis internal. Perlu verifikasi kualitas/spesifikasi.';
            } elseif ($rasio <= 0.95) {
                $status = 'MURAH (Di Bawah Rata-rata)';
                $kesimpulan = 'Harga pengadaan di bawah median historis internal. Cenderung menguntungkan APBN.';
            } elseif ($rasio <= 1.15) {
                $status = 'WAJAR (Sesuai Pasar Internal)';
                $kesimpulan = 'Harga pengadaan berada dalam rentang wajar (±15% dari median historis internal).';
            } elseif ($rasio <= 1.3) {
                $status = 'AGAK MAHAL (Di Atas Rata-rata)';
                $kesimpulan = 'Harga pengadaan melebihi median historis internal >15%. Perlu justifikasi teknis/komersial.';
            } else {
                $status = 'MAHAL (Signifikan Di Atas Pasar)';
                $kesimpulan = 'Harga pengadaan melebihi median historis internal >30%. Diperlukan analisis mendalam dan persetujuan atasan.';
            }
            
            $detail = "Harga satuan pengadaan: Rp " . number_format($hargaSatuanPengadaan, 0, ',', '.') . 
                      " | Median historis internal: Rp " . number_format($medianInternal, 0, ',', '.') . 
                      " | Rasio: " . number_format($rasio * 100, 1) . "%";
        } elseif ($marketMedian > 0) {
            $rasio = $marketMedian > 0 ? ($hargaSatuanPengadaan / $marketMedian) : 0;
            
            if ($rasio <= 0.85) {
                $status = 'MURAH (Di Bawah Estimasi Pasar)';
            } elseif ($rasio <= 1.2) {
                $status = 'WAJAR (Sesuai Estimasi Pasar)';
            } else {
                $status = 'MAHAL (Di Atas Estimasi Pasar)';
            }
            
            $detail = "Harga satuan pengadaan: Rp " . number_format($hargaSatuanPengadaan, 0, ',', '.') . 
                      " | Estimasi median pasar: Rp " . number_format($marketMedian, 0, ',', '.') . 
                      " | Rasio: " . number_format($rasio * 100, 1) . "%";
        } else {
            $detail = "Tidak ada data referensi internal yang cukup. Diperlukan estimasi harga pasar dari AI.";
        }

        return [
            'harga_satuan_pengadaan' => $hargaSatuanPengadaan,
            'total_nilai_pengadaan' => $totalNilai,
            'statistik_internal' => $stats['internal'] ?? null,
            'estimasi_pasar' => [
                'median' => $marketMedian,
                'min' => $marketMin,
                'max' => $marketMax
            ],
            'rasio_kewajaran' => $rasio > 0 ? round($rasio, 3) : null,
            'status_kewajaran' => $status,
            'kesimpulan' => $kesimpulan,
            'detail_perbandingan' => $detail,
            'rekomendasi' => $this->generatePriceRecommendation($status, $rasio, $kategori)
        ];
    }

    private function generatePriceRecommendation($status, $rasio, $kategori)
    {
        $rekomendasi = [];
        
        if (strpos($status, 'MAHAL') !== false) {
            $rekomendasi[] = 'Lakukan negosiasi ulang dengan penyedia berdasarkan data perbandingan.';
            $rekomendasi[] = 'Minta justifikasi teknis/komersial dari penyedia (BOM, analisis harga satuan, dll).';
            $rekomendasi[] = 'Pertimbangkan pembatalan dan pengadaan ulang jika negosiasi gagal.';
            $rekomendasi[] = 'Dokumentasikan alasan pemilihan jika tetap melanjutkan (sesuai PMK/Perpres pengadaan).';
        } elseif (strpos($status, 'AGAK MAHAL') !== false) {
            $rekomendasi[] = 'Minta klarifikasi harga dari penyedia.';
            $rekomendasi[] = 'Bandingkan dengan minimal 3 referensi harga (e-katalog, survei pasar, harga kontrak serupa).';
            $rekomendasi[] = 'Dokumentasikan analisis perbandingan untuk keperluan audit.';
        } elseif (strpos($status, 'WAJAR') !== false) {
            $rekomendasi[] = 'Harga dapat diterima. Lanjutkan proses pengadaan.';
            $rekomendasi[] = 'Simpan bukti analisis perbandingan harga sebagai dokumen pendukung.';
        } elseif (strpos($status, 'MURAH') !== false || strpos($status, 'SANGAT MURAH') !== false) {
            $rekomendasi[] = 'Verifikasi kesesuaian spesifikasi dan kualitas barang/jasa.';
            $rekomendasi[] = 'Pastikan tidak ada pengurangan kualitas/kuantitas tersembunyi.';
            $rekomendasi[] = 'Periksa kelengkapan dokumen jaminan (jaminan penawaran, jaminan pelaksanaan).';
        }
        
        // Rekomendasi spesifik per kategori
        if (stripos($kategori, 'konstruksi') !== false) {
            $rekomendasi[] = 'Untuk konstruksi: Periksa Analisis Harga Satuan (AHS) dan Volume Pekerjaan.';
            $rekomendasi[] = 'Perhatikan faktor lokasi (index harga daerah), kesulitan akses, dan kondisi tanah.';
        } elseif (stripos($kategori, 'konsultansi') !== false || stripos($kategori, 'jasa') !== false) {
            $rekomendasi[] = 'Untuk jasa/konsultansi: Bandingkan dengan standar honorarium KEPMEN/PERMEN terkait.';
            $rekomendasi[] = 'Periksa tingkat keahlian (junior/senior/principal) dan jam kerja yang diusulkan.';
        } elseif (stripos($kategori, 'barang') !== false || stripos($kategori, 'e-katalog') !== false) {
            $rekomendasi[] = 'Untuk barang: Cek harga e-katalog LKPP dan harga toko online resmi.';
            $rekomendasi[] = 'Perhatikan garansi, after-sales service, dan biaya pengiriman/asuransi.';
        }
        
        return $rekomendasi;
    }

    /**
     * Vendor Risk Scoring - Penilaian Risiko Penyedia
     * Menganalisis performa historis, keluhan, sanksi, dan keuangan vendor
     */
    private function analyzeVendorRisk($argsStr)
    {
        $args = json_decode($argsStr, true);
        $vendorName = $args['nama_penyedia'] ?? $args['vendor'] ?? '';
        $npwp = $args['npwp'] ?? '';
        $includeFinancial = $args['include_financial'] ?? false;
        
        if (!$vendorName) {
            return json_encode(['error' => 'Nama penyedia/vendor wajib diisi untuk analisis risiko.']);
        }

        $db = \Config\Database::connect();
        $year = date('Y');
        
        $riskFactors = [];
        $score = 100; // Base score 100, dikurangi per risiko
        $maxDeduction = 0;

        // 1. PERFORMA HISTORIS (LPSE & E-Purchasing)
        $performance = $this->getVendorPerformanceData($db, $vendorName, $year);
        
        // Analisis tingkat kemenangan vs partisipasi
        $totalPartisipasi = $performance['tender_partisipasi'] + $performance['nontender_partisipasi'] + $performance['epurchasing_transaksi'];
        $totalMenang = $performance['tender_menang'] + $performance['nontender_menang'] + $performance['epurchasing_transaksi'];
        
        if ($totalPartisipasi > 0) {
            $winRate = $totalMenang / $totalPartisipasi;
            if ($winRate < 0.1 && $totalPartisipasi >= 5) {
                $score -= 15;
                $winRatePct = round($winRate * 100, 1);
                $riskFactors[] = ['faktor' => 'Win Rate Rendah', 'detail' => "Win rate {$winRatePct}% dari {$totalPartisipasi} partisipasi", 'bobot' => 15, 'kategori' => 'Performa'];
                $maxDeduction += 15;
            } elseif ($winRate < 0.3 && $totalPartisipasi >= 3) {
                $score -= 8;
                $winRatePct = round($winRate * 100, 1);
                $riskFactors[] = ['faktor' => 'Win Rate Kurang Optimal', 'detail' => "Win rate {$winRatePct}% dari {$totalPartisipasi} partisipasi", 'bobot' => 8, 'kategori' => 'Performa'];
                $maxDeduction += 8;
            }
        }

        // 2. REALISASI vs KONTRAK (Ketepatan Waktu & Anggaran)
        $monevData = $this->getVendorMonevData($db, $vendorName);
        
        if ($monevData['total_proyek'] > 0) {
            $terlambatRate = $monevData['terlambat'] / $monevData['total_proyek'];
            $selesaiRate = $monevData['selesai'] / $monevData['total_proyek'];
            
            if ($terlambatRate > 0.5) {
                $score -= 25;
                $terlambatPct = round($terlambatRate * 100, 1);
                $riskFactors[] = ['faktor' => 'Tingkat Keterlambatan Tinggi', 'detail' => "{$monevData['terlambat']} dari {$monevData['total_proyek']} proyek terlambat ({$terlambatPct}%)", 'bobot' => 25, 'kategori' => 'Eksekusi'];
                $maxDeduction += 25;
            } elseif ($terlambatRate > 0.2) {
                $score -= 12;
                $terlambatPct = round($terlambatRate * 100, 1);
                $riskFactors[] = ['faktor' => 'Ada Keterlambatan', 'detail' => "{$monevData['terlambat']} dari {$monevData['total_proyek']} proyek terlambat ({$terlambatPct}%)", 'bobot' => 12, 'kategori' => 'Eksekusi'];
                $maxDeduction += 12;
            }
            
            if ($selesaiRate < 0.5 && $monevData['total_proyek'] >= 3) {
                $score -= 15;
                $selesaiPct = round($selesaiRate * 100, 1);
                $riskFactors[] = ['faktor' => 'Tingkat Penyelesaian Rendah', 'detail' => "Hanya {$monevData['selesai']} dari {$monevData['total_proyek']} proyek selesai ({$selesaiPct}%)", 'bobot' => 15, 'kategori' => 'Eksekusi'];
                $maxDeduction += 15;
            }
        }

        // 3. SANKSI & PELANGGARAN (Blacklist, SPHP, Denda)
        $sanctions = $this->getVendorSanctions($db, $vendorName);
        if ($sanctions['blacklist']) {
            $score -= 50;
            $riskFactors[] = ['faktor' => 'Terdaftar Blacklist', 'detail' => $sanctions['blacklist_detail'], 'bobot' => 50, 'kategori' => 'Kepatuhan'];
            $maxDeduction += 50;
        }
        if ($sanctions['sphp_issues'] > 0) {
            $deduction = min(20, $sanctions['sphp_issues'] * 5);
            $score -= $deduction;
            $riskFactors[] = ['faktor' => 'Masalah SPHP/BAST', 'detail' => "{$sanctions['sphp_issues']} kasus masalah serah terima/BAST", 'bobot' => $deduction, 'kategori' => 'Kepatuhan'];
            $maxDeduction += $deduction;
        }
        if ($sanctions['denda_count'] > 0) {
            $deduction = min(15, $sanctions['denda_count'] * 3);
            $score -= $deduction;
            $riskFactors[] = ['faktor' => 'Rekor Denda', 'detail' => "{$sanctions['denda_count']} kali terkena denda keterlambatan/ketidaksesuaian", 'bobot' => $deduction, 'kategori' => 'Kepatuhan'];
            $maxDeduction += $deduction;
        }

        // 4. KONSISTENSI HARGA (Price Consistency)
        $priceConsistency = $this->analyzeVendorPriceConsistency($db, $vendorName, $year);
        if ($priceConsistency['variance_coefficient'] > 0.5) {
            $score -= 10;
            $cvPct = round($priceConsistency['variance_coefficient'] * 100, 1);
            $riskFactors[] = ['faktor' => 'Konsistensi Harga Rendah', 'detail' => "Koefisien variasi harga: {$cvPct}% (indikasi harga tidak stabil/kurang transparan)", 'bobot' => 10, 'kategori' => 'Komersial'];
            $maxDeduction += 10;
        } elseif ($priceConsistency['variance_coefficient'] > 0.3) {
            $score -= 5;
            $cvPct = round($priceConsistency['variance_coefficient'] * 100, 1);
            $riskFactors[] = ['faktor' => 'Variasi Harga Sedang', 'detail' => "Koefisien variasi harga: {$cvPct}%", 'bobot' => 5, 'kategori' => 'Komersial'];
            $maxDeduction += 5;
        }

        // 5. KAPASITAS TEKNIS & KEUANGAN (jika diminta)
        $capacity = [];
        if ($includeFinancial) {
            $capacity = $this->assessVendorCapacity($db, $vendorName, $npwp);
            if ($capacity['financial_risk'] === 'Tinggi') {
                $score -= 20;
                $riskFactors[] = ['faktor' => 'Risiko Keuangan Tinggi', 'detail' => $capacity['financial_detail'], 'bobot' => 20, 'kategori' => 'Keuangan'];
                $maxDeduction += 20;
            } elseif ($capacity['financial_risk'] === 'Sedang') {
                $score -= 10;
                $riskFactors[] = ['faktor' => 'Risiko Keuangan Sedang', 'detail' => $capacity['financial_detail'], 'bobot' => 10, 'kategori' => 'Keuangan'];
                $maxDeduction += 10;
            }
        }

        // 6. KONSENTRASI RISIKO (Single Project Dependency)
        $concentration = $this->checkProjectConcentration($db, $vendorName, $year);
        if ($concentration['max_single_project_pct'] > 70) {
            $score -= 10;
            $riskFactors[] = ['faktor' => 'Konsentrasi Proyek Tinggi', 'detail' => "{$concentration['max_single_project_pct']}% nilai kontrak terkonsentrasi di 1 proyek", 'bobot' => 10, 'kategori' => 'Konsentrasi'];
            $maxDeduction += 10;
        }

        // Normalisasi score (min 0)
        $score = max(0, $score);
        
        // Kategori Risiko
        $riskCategory = 'Rendah';
        $riskColor = 'Hijau';
        if ($score < 40) { $riskCategory = 'Kritis'; $riskColor = 'Merah'; }
        elseif ($score < 60) { $riskCategory = 'Tinggi'; $riskColor = 'Merah'; }
        elseif ($score < 75) { $riskCategory = 'Sedang'; $riskColor = 'Kuning'; }
        elseif ($score < 90) { $riskCategory = 'Rendah'; $riskColor = 'Hijau Muda'; }
        else { $riskCategory = 'Sangat Rendah'; $riskColor = 'Hijau'; }

        // Rekomendasi Mitigasi
        $mitigasi = $this->generateVendorRiskMitigation($riskCategory, $riskFactors, $performance, $monevData);

        return json_encode([
            'vendor' => $vendorName,
            'npwp' => $npwp ?: 'Tidak disediakan',
            'tahun_analisis' => $year,
            'skor_risiko' => $score,
            'kategori_risiko' => $riskCategory,
            'warna_indikator' => $riskColor,
            'total_faktor_risiko' => count($riskFactors),
            'max_potensi_pengurangan' => $maxDeduction,
            'faktor_risiko_detail' => $riskFactors,
            'ringkasan_performa' => [
                'total_partisipasi_tender' => $performance['tender_partisipasi'],
                'menang_tender' => $performance['tender_menang'],
                'total_nontender' => $performance['nontender_partisipasi'],
                'menang_nontender' => $performance['nontender_menang'],
                'transaksi_epurchasing' => $performance['epurchasing_transaksi'],
                'total_nilai_kontrak' => $performance['total_nilai_kontrak'],
                'rata_rata_nilai_kontrak' => $performance['avg_nilai_kontrak']
            ],
            'ringkasan_eksekusi_monev' => [
                'total_proyek_dimonev' => $monevData['total_proyek'],
                'selesai_tepat_waktu' => $monevData['selesai'],
                'terlambat' => $monevData['terlambat'],
                'bermasalah' => $monevData['bermasalah'],
                'rata_rata_deviasi' => $monevData['avg_deviasi']
            ],
            'analisis_harga' => $priceConsistency,
            'kapasitas_vendor' => $capacity,
            'konsentrasi_risiko' => $concentration,
            'rekomendasi_mitigasi' => $mitigasi,
            'catatan' => 'Skor 0-100 (semakin tinggi semakin aman). Analisis berbasis data historis LPSE, E-Purchasing, Monev, dan Knowledge Base. Untuk keputusan resmi, lakukan due diligence lapangan.'
        ]);
    }

    private function getVendorPerformanceData($db, $vendorName, $year)
    {
        $result = [
            'tender_partisipasi' => 0,
            'tender_menang' => 0,
            'nontender_partisipasi' => 0,
            'nontender_menang' => 0,
            'epurchasing_transaksi' => 0,
            'total_nilai_kontrak' => 0,
            'avg_nilai_kontrak' => 0
        ];

        // Tender - asumsi: data lpse_tender berisi pemenang, untuk partisipasi butuh tabel terpisah
        // Kita gunakan pemenang sebagai proxy partisipasi yang menang
        try {
            $tenderMenang = $db->table('lpse_tender')
                ->where('tahun', $year)
                ->like('pemenang', $vendorName)
                ->select('nilai_kontrak, nilai_penawaran, nama_paket')
                ->get()->getResultArray();
            
            $result['tender_menang'] = count($tenderMenang);
            $result['tender_partisipasi'] = $result['tender_menang']; // Proxy
            
            foreach ($tenderMenang as $t) {
                $result['total_nilai_kontrak'] += (float)($t['nilai_kontrak'] ?? $t['nilai_penawaran'] ?? 0);
            }
        } catch (\Exception $e) {}

        // Non-Tender
        try {
            $ntMenang = $db->table('lpse_nontender')
                ->where('tahun', $year)
                ->like('pemenang', $vendorName)
                ->select('nilai_kontrak, nilai_penawaran, nama_paket')
                ->get()->getResultArray();
            
            $result['nontender_menang'] = count($ntMenang);
            $result['nontender_partisipasi'] = $result['nontender_menang'];
            
            foreach ($ntMenang as $t) {
                $result['total_nilai_kontrak'] += (float)($t['nilai_kontrak'] ?? $t['nilai_penawaran'] ?? 0);
            }
        } catch (\Exception $e) {}

        // E-Purchasing
        try {
            $ep = $db->table('epurchasing')
                ->where('tahun', $year)
                ->like('nama_penyedia', $vendorName)
                ->select('total_harga, nama_paket')
                ->get()->getResultArray();
            
            $result['epurchasing_transaksi'] = count($ep);
            foreach ($ep as $t) {
                $result['total_nilai_kontrak'] += (float)($t['total_harga'] ?? 0);
            }
        } catch (\Exception $e) {}

        // Pencatatan Non-Tender
        try {
            $pnt = $db->table('lpse_pencatatan_nontender')
                ->where('tahun', $year)
                ->like('nama_penyedia', $vendorName)
                ->select('realisasi, nama_paket')
                ->get()->getResultArray();
            
            foreach ($pnt as $t) {
                $result['total_nilai_kontrak'] += (float)($t['realisasi'] ?? 0);
            }
        } catch (\Exception $e) {}

        // Pencatatan Swakelola
        try {
            $psw = $db->table('lpse_pencatatan_swakelola')
                ->where('tahun', $year)
                ->like('nama_pelaksana', $vendorName)
                ->select('realisasi, nama_paket')
                ->get()->getResultArray();
            
            foreach ($psw as $t) {
                $result['total_nilai_kontrak'] += (float)($t['realisasi'] ?? 0);
            }
        } catch (\Exception $e) {}

        $totalWin = $result['tender_menang'] + $result['nontender_menang'] + $result['epurchasing_transaksi'];
        $result['avg_nilai_kontrak'] = $totalWin > 0 ? $result['total_nilai_kontrak'] / $totalWin : 0;

        return $result;
    }

    private function getVendorMonevData($db, $vendorName)
    {
        $result = [
            'total_proyek' => 0,
            'selesai' => 0,
            'terlambat' => 0,
            'bermasalah' => 0,
            'avg_deviasi' => 0
        ];

        try {
            $proyek = $db->table('monev_proyek')
                ->like('nama_penyedia', $vendorName)
                ->select('status, nama_proyek, nilai_kontrak')
                ->get()->getResultArray();
            
            $result['total_proyek'] = count($proyek);
            $totalDeviasi = 0;
            $deviasiCount = 0;

            foreach ($proyek as $p) {
                $status = strtolower($p['status'] ?? '');
                if (strpos($status, 'selesai') !== false) $result['selesai']++;
                elseif (strpos($status, 'terlambat') !== false) $result['terlambat']++;
                elseif (strpos($status, 'bermasalah') !== false || strpos($status, 'masalah') !== false) $result['bermasalah']++;
            }

            // Hitung deviasi rata-rata dari jadwal
            $proyekIds = array_column($proyek, 'id');
            if (!empty($proyekIds)) {
                // Butuh join dengan jadwal/harian untuk hitung deviasi - simplified
                // Gunakan data dari analyzeMonevProject logic jika perlu
            }
        } catch (\Exception $e) {}

        return $result;
    }

    private function getVendorSanctions($db, $vendorName)
    {
        $result = [
            'blacklist' => false,
            'blacklist_detail' => '',
            'sphp_issues' => 0,
            'denda_count' => 0
        ];

        // Cek blacklist (asumsi ada tabel blacklist atau kolom di vendor)
        try {
            // Cek di tabel vendor/penyedia jika ada kolom blacklist
            $bl = $db->table('penyedia')->orLike('nama', $vendorName)->where('blacklist', 1)->get()->getRowArray();
            if ($bl) {
                $result['blacklist'] = true;
                $result['blacklist_detail'] = $bl['blacklist_alasan'] ?? 'Terdaftar dalam daftar hitam';
            }
        } catch (\Exception $e) {}

        // Cek SPHP/BAST issues - dari monev harian kendala
        try {
            $sphpIssues = $db->table('monev_harian mh')
                ->join('monev_proyek mp', 'mp.id = mh.proyek_id')
                ->where('mp.nama_penyedia LIKE', "%{$vendorName}%")
                ->like('mh.kendala', 'SPHP')
                ->orLike('mh.kendala', 'BAST')
                ->orLike('mh.keterangan', 'SPHP')
                ->orLike('mh.keterangan', 'BAST')
                ->countAllResults();
            $result['sphp_issues'] = $sphpIssues;
        } catch (\Exception $e) {}

        // Cek denda - dari monev harian atau kolom denda di proyek
        try {
            $denda = $db->table('monev_proyek')
                ->like('nama_penyedia', $vendorName)
                ->where('denda >', 0)
                ->countAllResults();
            $result['denda_count'] = $denda;
        } catch (\Exception $e) {}

        return $result;
    }

    private function analyzeVendorPriceConsistency($db, $vendorName, $year)
    {
        $prices = [];
        
        // Kumpulkan harga satuan dari berbagai sumber
        try {
            // Tender
            $tender = $db->table('lpse_tender')
                ->where('tahun', $year)
                ->like('pemenang', $vendorName)
                ->select('nilai_kontrak, nama_paket')
                ->get()->getResultArray();
            foreach ($tender as $t) {
                // Butuh volume untuk hitung satuan - skip jika tidak ada
            }
        } catch (\Exception $e) {}

        try {
            // E-Purchasing - biasanya ada spesifikasi per unit
            $ep = $db->table('epurchasing')
                ->where('tahun', $year)
                ->like('nama_penyedia', $vendorName)
                ->select('total_harga, nama_paket, spesifikasi')
                ->get()->getResultArray();
            foreach ($ep as $t) {
                // Estimasi kasar: asumsikan 1 unit per transaksi e-purchasing
                $prices[] = (float)($t['total_harga'] ?? 0);
            }
        } catch (\Exception $e) {}

        if (count($prices) < 2) {
            return [
                'sample_count' => count($prices),
                'variance_coefficient' => 0,
                'status' => 'Data tidak cukup untuk analisis konsistensi harga'
            ];
        }

        $mean = array_sum($prices) / count($prices);
        $variance = 0;
        foreach ($prices as $p) {
            $variance += pow($p - $mean, 2);
        }
        $variance /= count($prices);
        $stdDev = sqrt($variance);
        $cv = $mean > 0 ? $stdDev / $mean : 0;

        return [
            'sample_count' => count($prices),
            'mean_price' => $mean,
            'std_deviation' => $stdDev,
            'variance_coefficient' => round($cv, 3),
            'min_price' => min($prices),
            'max_price' => max($prices),
            'status' => $cv > 0.5 ? 'Tidak Konsisten (Risiko Tinggi)' : ($cv > 0.3 ? 'Cukup Konsisten' : 'Konsisten')
        ];
    }

    private function assessVendorCapacity($db, $vendorName, $npwp)
    {
        // Placeholder untuk analisis kapasitas keuangan/teknis
        // Dalam implementasi nyata, ini bisa integrate dengan API DJP, SIUJK, dll.
        return [
            'financial_risk' => 'Tidak Dianalisis',
            'financial_detail' => 'Analisis keuangan memerlukan integrasi eksternal (DJP, BI Checking, SIUJK). Data NPWP: ' . ($npwp ?: 'Tidak disediakan'),
            'technical_capacity' => 'Tidak Dianalisis',
            'manpower' => 'Tidak Dianalisis',
            'equipment' => 'Tidak Dianalisis',
            'certifications' => []
        ];
    }

    private function checkProjectConcentration($db, $vendorName, $year)
    {
        $projectValues = [];
        
        try {
            $tender = $db->table('lpse_tender')
                ->where('tahun', $year)
                ->like('pemenang', $vendorName)
                ->select('nilai_kontrak, nama_paket')
                ->get()->getResultArray();
            foreach ($tender as $t) {
                $projectValues[$t['nama_paket']] = (float)($t['nilai_kontrak'] ?? 0);
            }
        } catch (\Exception $e) {}

        try {
            $nt = $db->table('lpse_nontender')
                ->where('tahun', $year)
                ->like('pemenang', $vendorName)
                ->select('nilai_kontrak, nama_paket')
                ->get()->getResultArray();
            foreach ($nt as $t) {
                $projectValues[$t['nama_paket']] = (float)($t['nilai_kontrak'] ?? 0);
            }
        } catch (\Exception $e) {}

        try {
            $ep = $db->table('epurchasing')
                ->where('tahun', $year)
                ->like('nama_penyedia', $vendorName)
                ->select('total_harga, nama_paket')
                ->get()->getResultArray();
            foreach ($ep as $t) {
                $projectValues[$t['nama_paket']] = (float)($t['total_harga'] ?? 0);
            }
        } catch (\Exception $e) {}

        $total = array_sum($projectValues);
        $maxSingle = 0;
        $maxProject = '';
        foreach ($projectValues as $proj => $val) {
            if ($val > $maxSingle) {
                $maxSingle = $val;
                $maxProject = $proj;
            }
        }

        $maxPct = $total > 0 ? round(($maxSingle / $total) * 100, 1) : 0;

        return [
            'total_nilai_semua_proyek' => $total,
            'jumlah_proyek' => count($projectValues),
            'proyek_terbesar' => $maxProject,
            'nilai_proyek_terbesar' => $maxSingle,
            'max_single_project_pct' => $maxPct,
            'status' => $maxPct > 70 ? 'Tinggi (Risiko Konsentrasi)' : ($maxPct > 40 ? 'Sedang' : 'Terdistribusi')
        ];
    }

    private function generateVendorRiskMitigation($riskCategory, $riskFactors, $performance, $monevData)
    {
        $mitigasi = [];
        
        // Berdasarkan kategori risiko
        switch ($riskCategory) {
            case 'Kritis':
                $mitigasi[] = 'LARANGAN KERJA SAMA: Vendor tidak direkomendasikan untuk pengadaan baru hingga perbaikan signifikan.';
                $mitigasi[] = 'Lakukan audit mendalam (due diligence) sebelum mempertimbangkan kontrak baru.';
                $mitigasi[] = 'Jika kontrak berjalan, aktifkan klausul pemutusan/penalti dan siapkan vendor cadangan.';
                break;
            case 'Tinggi':
                $mitigasi[] = 'PERHATIAN KHUSUS: Perlu persetujuan Pejabat Pembuat Komitmen (PPK) tingkat atas.';
                $mitigasi[] = 'Wajib menyertakan jaminan pelaksanaan minimal 10% nilai kontrak.';
                $mitigasi[] = 'Tetapkan milestone pembayaran ketat berbasis pencapaian fisik (bukan berbasis waktu).';
                $mitigasi[] = 'Assign PPK/PJ yang berpengalaman untuk pengawasan intensif (mingguan).';
                break;
            case 'Sedang':
                $mitigasi[] = 'Perlu evaluasi tambahan sebelum penunjukan penyedia.';
                $mitigasi[] = 'Minta referensi proyek serupa 2-3 tahun terakhir dan hubungi PPK proyek tersebut.';
                $mitigasi[] = 'Pertimbangkan klausul insentif/disinsentif kinerja dalam kontrak.';
                break;
            case 'Rendah':
                $mitigasi[] = 'Vendor dapat dipertimbangkan dengan pengawasan standar.';
                $mitigasi[] = 'Lakukan verifikasi dokumen kualifikasi standar (SIUJK, NPWP, Sertifikat, dll).';
                break;
            case 'Sangat Rendah':
                $mitigasi[] = 'Vendor direkomendasikan. Proses pengadaan standar.';
                break;
        }

        // Berdasarkan faktor risiko spesifik
        foreach ($riskFactors as $rf) {
            if ($rf['kategori'] === 'Eksekusi' && strpos($rf['faktor'], 'Keterlambatan') !== false) {
                $mitigasi[] = 'Khusus keterlambatan: Tetapkan jadwal milestone detail dengan penalty harian (0.1-0.5%/hari).';
                $mitigasi[] = 'Wajibkan laporan mingguan foto/fisik progress dengan tanda tangan PPK.';
            }
            if ($rf['kategori'] === 'Kepatuhan' && strpos($rf['faktor'], 'Blacklist') !== false) {
                $mitigasi[] = 'BLACKLIST: Sesuai Perpres Pengadaan, vendor dilarang mengikuti pengadaan selama masa sanksi.';
            }
            if ($rf['kategori'] === 'Kepatuhan' && strpos($rf['faktor'], 'Denda') !== false) {
                $mitigasi[] = 'Rekor denda: Pastikan kontrak baru memiliki klausul denda yang lebih ketat dan otomatis.';
            }
            if ($rf['kategori'] === 'Komersial' && strpos($rf['faktor'], 'Harga') !== false) {
                $mitigasi[] = 'Konsistensi harga: Lakukan analisis harga satuan (AHS) detail dan bandingkan dengan e-katalog/LPSE serupa.';
            }
            if ($rf['kategori'] === 'Konsentrasi') {
                $mitigasi[] = 'Konsentrasi proyek: Pastikan vendor memiliki kapasitas paralel (SDM, alat, modal) untuk menangani proyek baru.';
            }
        }

        // General best practices
        $mitigasi[] = 'Lakukan verifikasi keaslian dokumen kualifikasi (SIUJK, Sertifikat ISO, NPWP, SKT, dll) ke penerbit resmi.';
        $mitigasi[] = 'Cek reputasi di LPSE/LKPP dan minta surat keterangan tidak terlibat perselisihan hukum dari vendor.';
        $mitigasi[] = 'Dokumentasikan seluruh proses analisis risiko ini sebagai bukti pengelolaan risiko pengadaan (audit trail).';

        return array_unique($mitigasi);
    }
}
