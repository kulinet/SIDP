<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;
use App\Models\EpurchasingModel;
use App\Controllers\Chatbot;

class Api extends ResourceController
{
    // Placeholder login method
    public function login()
    {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Login endpoint (placeholder)']);
    }

    // Placeholder summary method
    public function getSummary()
    {
        // You can extend this to return actual summary data
        return $this->response->setJSON(['status' => 'success', 'data' => []]);
    }

    // Retrieve LPSE data for a given identifier
    public function getLpse($segment)
    {
        // Placeholder: implement actual LPSE retrieval logic as needed
        return $this->response->setJSON(['status' => 'success', 'lpse_id' => $segment]);
    }

    // Retrieve RUP OPD data
    public function getRupOpd()
    {
        // Placeholder implementation
        return $this->response->setJSON(['status' => 'success', 'rup_opd' => []]);
    }

    // Proxy chatbot ask endpoint via API group
    public function chatbotAsk()
    {
        // Reuse existing Chatbot::ask logic
        $chatbot = new Chatbot();
        // Forward the current request to Chatbot::ask
        return $chatbot->ask();
    }

    // Export Monev Summary for sidepe monitoring
    public function getMonevSummary()
    {
        $proyekModel = new \App\Models\MonevProyekModel();
        $jadwalModel = new \App\Models\MonevJadwalModel();
        $harianModel = new \App\Models\MonevHarianModel();
        
        // We use Dashboard controller to calculate scurve
        $dashboard = new \App\Controllers\Dashboard();
        $dashboard->initController($this->request, $this->response, \Config\Services::logger());

        $proyekList = $proyekModel->findAll();
        $summaryData = [];
        
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $dashboard->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            $realisasiTerakhir = 0;
            if (!empty($scurve['actual'])) {
                foreach (array_reverse($scurve['actual']) as $val) {
                    if ($val !== null) { $realisasiTerakhir = $val; break; }
                }
            }
            
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $val) {
                    if ($val !== null) { $lastWeekIndex = $idx; }
                }
                if ($lastWeekIndex >= 0) {
                    $currentActual = $scurve['actual'][$lastWeekIndex] ?? 0;
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    $currentPlan = $scurve['plan'][$lastWeekIndex] ?? 0;
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }
            
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah';
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning';
            } else {
                $statusIndikator = 'Hijau';
            }
            
            $tglSelesai = strtotime($p['tgl_selesai']);
            if ($tglSelesai < time() && $p['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah';
                } elseif ($statusIndikator !== 'Merah') {
                    $statusIndikator = 'Kuning';
                }
            }
            
            $p['realisasi'] = $realisasiTerakhir;
            $p['deviasi_kumulatif'] = $deviasiTerakhir;
            $p['deviasi_mingguan'] = $deviasiMingguan;
            $p['status_indikator'] = $statusIndikator;
            
            $summaryData[] = $p;
        }

        // Return as JSON with CORS allowed
        return $this->response
            ->setHeader('Access-Control-Allow-Origin', '*')
            ->setJSON(['status' => 'success', 'data' => $summaryData]);
    }
}
