<?php

namespace App\Commands;

use App\Services\InaprocApiService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class SyncVendorDetails extends BaseCommand
{
    protected $group = 'Sync';
    protected $name = 'sync:vendor-details';
    protected $description = 'Sinkronisasi detail vendor penyedia dari Inaproc ke tabel lokal';

    public function run(array $params)
    {
        $kode = $params[0] ?? null;
        $service = new InaprocApiService();

        if (!empty($kode)) {
            $result = $service->syncVendorDetail($kode, true);
            CLI::write($result['ok'] ? 'Sync OK: ' . $kode : 'Sync failed: ' . ($result['error'] ?? 'unknown'), $result['ok'] ? 'green' : 'red');
            return;
        }

        $db = \Config\Database::connect();
        $rows = $db->table('epurchasing')
            ->distinct()
            ->select('kode_penyedia')
            ->where('kode_penyedia IS NOT NULL')
            ->where('kode_penyedia !=', '')
            ->get()
            ->getResultArray();

        $count = 0;
        foreach ($rows as $row) {
            $kodePenyedia = trim($row['kode_penyedia']);
            if ($kodePenyedia === '') {
                continue;
            }

            $result = $service->syncVendorDetail($kodePenyedia, false);
            $count++;
            CLI::write(($count) . '. ' . $kodePenyedia . ' => ' . ($result['ok'] ? 'ok' : 'failed'), $result['ok'] ? 'green' : 'yellow');
        }

        CLI::write('Finished syncing ' . $count . ' vendor(s).', 'cyan');
    }
}
