<?php

namespace App\Models;

use CodeIgniter\Model;

class LpsePencatatanNontenderModel extends Model
{
    protected $table = 'lpse_pencatatan_nontender';
    protected $primaryKey = 'id';
    protected $allowedFields = ['kd_rup', 'tahun', 'kd_paket', 'nama_paket', 'nama_satker', 'kd_satker', 'pagu', 'realisasi', 'nama_penyedia', 'jenis_realisasi', 'no_pembayaran', 'status'];
    protected $useTimestamps = true;
}
