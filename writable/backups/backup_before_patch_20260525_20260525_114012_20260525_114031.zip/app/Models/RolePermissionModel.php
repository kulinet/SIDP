<?php

namespace App\Models;

use CodeIgniter\Model;

class RolePermissionModel extends Model
{
    protected $table            = 'role_permissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['role', 'menu_key', 'is_allowed'];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function checkPermission($role, $menuKey)
    {
        // Admin always has permission
        if ($role === 'admin') return true;

        $permission = $this->where('role', $role)
                           ->where('menu_key', $menuKey)
                           ->first();

        if ($permission) {
            return (bool)$permission['is_allowed'];
        }

        // Default permissions if not set in DB
        $defaults = [
            'operator' => [
                'report', 'dashboard', 'comparisons', 'penyedia', 'swakelola', 'rup-opd',
                'dashboard-lpse', 'lpse', 'epurchasing', 'development'
            ],
            'opd' => [
                'report', 'dashboard', 'comparisons', 'penyedia', 'swakelola', 'rup-opd'
            ],
            'satker' => [
                'report', 'dashboard', 'comparisons', 'penyedia', 'swakelola', 'rup-opd'
            ]
        ];

        return in_array($menuKey, $defaults[$role] ?? []);
    }
}
