<?php

namespace App\Controllers;

use App\Models\RolePermissionModel;
use App\Models\UserModel;

class RbacController extends BaseController
{
    public function index()
    {
        $roleModel = new RolePermissionModel();
        $userModel = new UserModel();
        
        // Get unique roles from users table
        $roles = $userModel->select('role')->distinct()->findAll();
        $roles = array_column($roles, 'role');
        
        // Ensure standard roles exist in list
        $standardRoles = ['admin', 'operator', 'opd', 'satker', 'user'];
        $roles = array_unique(array_merge($roles, $standardRoles));

        $menus = [
            ['key' => 'report', 'label' => 'Summary - Laporan Realisasi'],
            ['key' => 'dashboard', 'label' => 'Data RUP - Dashboard'],
            ['key' => 'comparisons', 'label' => 'Data RUP - Perbandingan Tahunan'],
            ['key' => 'penyedia', 'label' => 'Data RUP - Penyedia'],
            ['key' => 'swakelola', 'label' => 'Data RUP - Swakelola'],
            ['key' => 'rup-opd', 'label' => 'Data RUP - RUP OPD'],
            ['key' => 'dashboard-lpse', 'label' => 'Data Pengadaan - Dashboard LPSE'],
            ['key' => 'lpse_tender', 'label' => 'Data Pengadaan - Data LPSE - Tender'],
            ['key' => 'lpse_nontender', 'label' => 'Data Pengadaan - Data LPSE - Non Tender'],
            ['key' => 'lpse_pencatatan_nontender', 'label' => 'Data Pengadaan - Data LPSE - Pencatatan Non Tender'],
            ['key' => 'lpse_pencatatan_swakelola', 'label' => 'Data Pengadaan - Data LPSE - Pencatatan Swakelola'],
            ['key' => 'epurchasing', 'label' => 'Data Pengadaan - E-Purchasing'],
            ['key' => 'user_management', 'label' => 'Aplikasi - Manage User'],
            ['key' => 'chatbot_settings', 'label' => 'Aplikasi - Chatbot Settings'],
            ['key' => 'api_settings', 'label' => 'Aplikasi - API Security'],
            ['key' => 'sync_data', 'label' => 'Aplikasi - Sinkronisasi Data'],
            ['key' => 'master_menu', 'label' => 'Aplikasi - Master Menu'],
            ['key' => 'patch_app', 'label' => 'Aplikasi - System Patcher'],
            ['key' => 'user_logs', 'label' => 'Aplikasi - Activity Logs'],
        ];

        // Fetch current permissions
        $permissions = [];
        $dbPerms = $roleModel->findAll();
        foreach ($dbPerms as $p) {
            $permissions[$p['role']][$p['menu_key']] = $p['is_allowed'];
        }

        return view('user/rbac', [
            'title' => 'Manage RBAC',
            'user'  => session()->get(),
            'roles' => $roles,
            'menus' => $menus,
            'permissions' => $permissions
        ]);
    }

    public function save()
    {
        $roleModel = new RolePermissionModel();
        $perms = $this->request->getPost('perms'); // [role][menu_key] = 1

        // Clear existing permissions to sync
        $roleModel->truncate();

        if ($perms) {
            foreach ($perms as $role => $menus) {
                foreach ($menus as $menuKey => $allowed) {
                    $roleModel->insert([
                        'role' => $role,
                        'menu_key' => $menuKey,
                        'is_allowed' => 1
                    ]);
                }
            }
        }

        return redirect()->to(base_url('user/rbac'))->with('success', 'Hak akses berhasil diperbarui.');
    }
}
