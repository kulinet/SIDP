<?php

namespace App\Models;

use CodeIgniter\Model;

class LpseNontenderModel extends Model
{
    protected $table = 'lpse_nontender';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'kd_rup', 'tahun', 'kd_paket', 'nama_paket', 'nama_satker', 'kd_satker', 'pagu', 'hps', 
        'nilai_kontrak', 'nilai_negosiasi', 'nilai_pdn_kontrak', 'nilai_umk_kontrak',
        'nama_penyedia', 'metode', 'jenis_pengadaan', 
        'tgl_kontrak', 'no_kontrak', 'status', 'kualifikasi_paket', 'kontrak_pembayaran'
    ];
    protected $useTimestamps = true;
}
