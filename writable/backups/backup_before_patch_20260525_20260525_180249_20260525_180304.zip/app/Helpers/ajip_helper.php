<?php

if (!function_exists('encode_id')) {
    function encode_id($id) {
        $salt = 'AJIP_SECURE_';
        $str = base64_encode($salt . $id);
        return str_replace(['+', '/', '='], ['-', '_', ''], $str);
    }
}

if (!function_exists('decode_id')) {
    function decode_id($str) {
        $str = str_replace(['-', '_'], ['+', '/'], $str);
        // Pad to proper base64 length
        $pad = strlen($str) % 4;
        if ($pad > 0) {
            $str .= str_repeat('=', 4 - $pad);
        }
        $decoded = base64_decode($str);
        $salt = 'AJIP_SECURE_';
        if ($decoded && strpos($decoded, $salt) === 0) {
            return substr($decoded, strlen($salt));
        }
        return false;
    }
}
