<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\EpurchasingModel;

class Chatbot extends ResourceController
{
    public function index()
    {
        return view('components/chatbot');
    }

    public function ask()
    {
        if (!$this->request->isAJAX()) {
            return $this->failForbidden('Hanya menerima request AJAX.');
        }

        $message = $this->request->getPost('message');
        $settingsModel = new \App\Models\SettingsModel();
        
        $apiKey = $settingsModel->getSetting('chatbot_api_key', env('OPENAI_API_KEY'));
        $model = $settingsModel->getSetting('chatbot_model', 'gpt-5.4-mini');
        $apiUrl = $settingsModel->getSetting('chatbot_api_url', 'https://api.ai.cc/v1/chat/completions');

        if (empty($message)) {
            return $this->respond([
                'status' => 'error',
                'message' => 'Pesan tidak boleh kosong.'
            ], 400);
        }

        // --- Chatbot Memory ( Session ) ---
        $session = session();
        $history = $session->get('chat_history') ?? [];
        // Keep only last 4 messages to reduce token load
        if (count($history) > 4) $history = array_slice($history, -4);

        // Check if user asks for e‑purchasing winner
        if (preg_match('/pemenang\s+paket\s+(.+)/i', $message, $m)) {
            $paketName = trim($m[1], " .?,!\"'");
            $winnerData = $this->findPaketWinner($paketName);
            if ($winnerData) {
                $nama = $winnerData['nama_penyedia'] ?? 'Tidak diketahui';
                $kode = $winnerData['kode_penyedia'] ?? '';
                $reply = "Pemenang paket **{$paketName}** adalah **{$nama}**";
                if ($kode) $reply .= " (Kode: {$kode})";
                return $this->respond([
                    'status' => 'success',
                    'reply' => $reply
                ]);
            } else {
                return $this->respond([
                    'status' => 'error',
                    'message' => "Tidak ditemukan pemenang untuk paket **{$paketName}**."
                ], 404);
            }
        }

        if (empty($apiKey)) {
            return $this->respond([
                'status' => 'error',
                'message' => 'API Key tidak dikonfigurasi.'
            ], 500);
        }

        $response = $this->callOpenAI($message, $apiKey, $model, $apiUrl, $history);

        if (isset($response['error'])) {
            $errorMessage = is_array($response['error']) 
                ? ($response['error']['message'] ?? json_encode($response['error'])) 
                : $response['error'];
            
            return $this->respond([
                'status' => 'error',
                'message' => 'Gagal terhubung ke AI. ' . $errorMessage
            ], 500);
        }

        $reply = $response['choices'][0]['message']['content'] ?? 'Maaf, saya tidak mengerti.';

        // Save to History
        $history[] = ['role' => 'user', 'content' => $message];
        $history[] = ['role' => 'assistant', 'content' => $reply];
        $session->set('chat_history', $history);

        return $this->respond([
            'status' => 'success',
            'reply' => $reply
        ]);
    }

    private function getRupData($type)
    {
        $currentYear = date('Y');
        $model = ($type === 'swakelola') ? new \App\Models\RupSwakelolaModel() : new \App\Models\RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        
        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        
        // Filter by OPD/Satker if user is a Satker
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }
        
        $data = $builder->findAll();
        
        return is_array($data) ? $data : [];
    }

    private function getPaguSummary($argsStr)
    {
        $args = json_decode($argsStr, true);
        $tipe = $args['tipe'] ?? 'penyedia';
        $opd = $args['opd'] ?? '';
        $metode = $args['metode'] ?? '';
        $jenis = $args['jenis_pengadaan'] ?? '';
        
        $data = $this->getRupData($tipe);
        
        if ($opd) {
            $data = array_filter($data, function($item) use ($opd) {
                return stripos($item['nama_satker'] ?? '', $opd) !== false;
            });
        }
        
        if ($metode) {
            $data = array_filter($data, function($item) use ($metode, $tipe) {
                $m = $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '') : ($item['tipe_swakelola'] ?? '');
                return stripos($m, $metode) !== false;
            });
        }
        
        if ($jenis && $tipe === 'penyedia') {
            $data = array_filter($data, function($item) use ($jenis) {
                return stripos($item['jenis_pengadaan'] ?? '', $jenis) !== false;
            });
        }
        
        $totalPagu = array_sum(array_column($data, 'pagu'));
        $totalPaket = count($data);
        $opdName = $opd ? ($data[array_key_first($data)]['nama_satker'] ?? $opd) : 'Seluruh OPD';

        return json_encode([
            'tipe' => $tipe,
            'opd' => $opdName,
            'metode' => $metode ?: 'Semua',
            'jenis_pengadaan' => $jenis ?: 'Semua',
            'total_paket' => $totalPaket,
            'total_pagu_rupiah' => $totalPagu
        ]);
    }

    private function searchPaket($argsStr)
    {
        $args = json_decode($argsStr, true);
        $query = $args['query'] ?? '';
        $opd = $args['opd'] ?? '';
        $metodeFilter = $args['metode'] ?? '';
        $jenisFilter = $args['jenis_pengadaan'] ?? '';
        $tipe = $args['tipe'] ?? 'penyedia';
        $sortPagu = $args['sort_pagu'] ?? ''; // 'terbesar' atau 'terkecil'
        
        $data = $this->getRupData($tipe);
        $results = [];
        $totalPaguAggregated = 0;

        foreach ($data as $item) {
            $match = true;

            // Search Keyword (Pencarian Luas - Multi word AND search)
            if ($query && $match) {
                // Menggabungkan berbagai field teks untuk pencarian yang lebih baik
                $searchContent = implode(' ', [
                    $item['nama_paket'] ?? '',
                    $item['uraian_pekerjaan'] ?? '',
                    $item['urarian_pekerjaan'] ?? '', // Typo handling untuk data penyedia
                    $item['spesifikasi_pekerjaan'] ?? '',
                    $item['kegiatan'] ?? '',
                    $item['nama_satker'] ?? '',
                    $item['metode_pengadaan'] ?? '',
                    $item['volume_pekerjaan'] ?? ''
                ]);

                $searchContentLower = strtolower($searchContent);
                $queryWords = explode(' ', strtolower($query));
                
                foreach ($queryWords as $word) {
                    $word = trim($word);
                    if ($word && strpos($searchContentLower, $word) === false) {
                        $match = false;
                        break;
                    }
                }
            }

            if ($opd && $match) {
                if (stripos($item['nama_satker'] ?? '', $opd) === false) {
                    $match = false;
                }
            }
            
            if ($metodeFilter && $match) {
                $m = $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '') : ($item['tipe_swakelola'] ?? '');
                if (stripos($m, $metodeFilter) === false) {
                    $match = false;
                }
            }

            // Filter Jenis Pengadaan (Hanya berlaku untuk tipe Penyedia)
            if ($jenisFilter && $match && $tipe === 'penyedia') {
                if (stripos($item['jenis_pengadaan'] ?? '', $jenisFilter) === false) {
                    $match = false;
                }
            }

            if ($match) {
                $pagu = (float) ($item['pagu'] ?? 0);
                $totalPaguAggregated += $pagu;

                $results[] = [
                    'opd' => $item['nama_satker'] ?? '',
                    'nama_paket' => $item['nama_paket'] ?? '',
                    'pagu' => $pagu,
                    'jenis_pengadaan' => $item['jenis_pengadaan'] ?? '-',
                    'metode' => $tipe === 'penyedia' ? ($item['metode_pengadaan'] ?? '-') : ($item['tipe_swakelola'] ?? '-'),
                    'uraian' => $item['uraian_pekerjaan'] ?? ($item['urarian_pekerjaan'] ?? ($item['spesifikasi_pekerjaan'] ?? ($item['kegiatan'] ?? '-')))
                ];
            }
        }
        
        if ($sortPagu === 'terbesar') {
            usort($results, function($a, $b) {
                return $b['pagu'] <=> $a['pagu'];
            });
        } else if ($sortPagu === 'terkecil') {
            usort($results, function($a, $b) {
                return $a['pagu'] <=> $b['pagu'];
            });
        }

        $totalFound = count($results);
        // Limit the items inside PHP so OpenAI doesn't exceed max tokens
        $results = array_slice($results, 0, 15);

        if (empty($results)) {
            return json_encode(['message' => 'Tidak ditemukan data paket yang cocok.']);
        }

        return json_encode([
            'total_paket_ditemukan' => $totalFound,
            'total_pagu_seluruh_pencarian_rupiah' => $totalPaguAggregated,
            'keterangan' => $totalFound > 15 ? 'Menampilkan detail top 15 data saja.' : 'Menampilkan semua data detail.',
            'data_detail' => $results
        ]);
    }

    private function getOpdPaguRanking($argsStr)
    {
        $args = json_decode($argsStr, true);
        $tipe = $args['tipe'] ?? 'penyedia';
        $sort = $args['sort'] ?? 'terbesar'; // 'terbesar' atau 'terkecil'
        
        $data = $this->getRupData($tipe);
        
        // Group & sum by OPD
        $opdTotals = [];
        foreach ($data as $item) {
            $opd = $item['nama_satker'] ?? 'Tanpa Nama OPD';
            if (!isset($opdTotals[$opd])) {
                $opdTotals[$opd] = 0;
            }
            $opdTotals[$opd] += (float) ($item['pagu'] ?? 0);
        }
        
        if ($sort === 'terkecil') {
            asort($opdTotals);
        } else {
            arsort($opdTotals);
        }
        
        $results = [];
        $i = 1;
        foreach ($opdTotals as $opd => $totalPagu) {
            $results[] = [
                'peringkat' => $i,
                'opd' => $opd,
                'total_pagu_rupiah' => $totalPagu
            ];
            $i++;
            if ($i > 15) break; // Limit 15 OPD
        }

        $ket = $sort === 'terkecil' ? 'terkecil / terendah' : 'terbesar / tertinggi';

        return json_encode([
            'tipe' => $tipe,
            'keterangan' => "Menampilkan daftar Top 15 OPD dengan agregasi/akumulasi total pagu $ket.",
            'data' => $results
        ]);
    }

    private function getEpurchasingStats()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('epurchasing');
        
        $year = date('Y');
        $builder->where('tahun', $year);
        
        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }
        
        $builder->select("COUNT(*) as total_paket, SUM(total_harga) as total_realisasi");
        $row = $builder->get()->getRowArray();
        
        $builderTop = $db->table('epurchasing')->where('tahun', $year);
        $builderTop->select('nama_satker, SUM(total_harga) as total');
        $builderTop->groupBy('nama_satker');
        $builderTop->orderBy('total', 'DESC');
        $topSatkerRow = $builderTop->get()->getRowArray();
        $topSatker = $topSatkerRow ? $topSatkerRow['nama_satker'] . ' (Rp ' . number_format((float)$topSatkerRow['total'], 0, ',', '.') . ')' : '-';
        
        $summary = [
            'tahun_berjalan' => $year,
            'total_realisasi_rupiah' => (float)($row['total_realisasi'] ?? 0),
            'total_paket' => (int)($row['total_paket'] ?? 0),
            'top_satker_saat_ini' => $topSatker
        ];

        return json_encode($summary);
    }

    private function getLpseRealisasiStats($argsStr)
    {
        $args = json_decode($argsStr, true);
        $type = $args['tipe'] ?? 'tender'; // tender, nontender, swakelola
        $year = $args['tahun'] ?? date('Y');

        $db = \Config\Database::connect();
        $builder = null;
        $sumField = 'nilai_kontrak';
        $paguField = 'pagu';

        if ($type === 'tender') {
            $builder = $db->table('lpse_tender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'nontender') {
            $builder = $db->table('lpse_nontender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'swakelola') {
            $builder = $db->table('lpse_pencatatan_swakelola');
            $sumField = 'realisasi';
        }

        if (!$builder) {
            return json_encode(['error' => 'Tipe pengadaan tidak valid.']);
        }

        $userRole = strtolower(session()->get('role') ?? '');
        $userSatker = session()->get('kd_satker');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        if ($year && $year !== 'all') {
            $builder->where('tahun', $year);
        }

        $builder->select("COUNT(*) as jumlah_paket, SUM($paguField) as total_pagu, SUM($sumField) as total_realisasi");
        $row = $builder->get()->getRowArray();

        $totalPagu = (float)($row['total_pagu'] ?? 0);
        $totalReal = (float)($row['total_realisasi'] ?? 0);
        $count = (int)($row['jumlah_paket'] ?? 0);

        return json_encode([
            'tipe_pengadaan' => $type,
            'tahun' => $year,
            'jumlah_paket' => $count,
            'total_pagu_rupiah' => $totalPagu,
            'total_realisasi_rupiah' => $totalReal,
            'persentase_realisasi' => $totalPagu > 0 ? round(($totalReal / $totalPagu) * 100, 2) . '%' : '0%'
        ]);
    }
    private function getMonevSummary()
    {
        $proyekModel = new \App\Models\MonevProyekModel();
        $jadwalModel = new \App\Models\MonevJadwalModel();
        $harianModel = new \App\Models\MonevHarianModel();
        $dashboard = new \App\Controllers\Dashboard();
        $dashboard->initController($this->request, $this->response, $this->logger);

        $proyekList = $proyekModel->findAll();
        
        $summaryData = [];
        $totalProyek = count($proyekList);
        $totalKritis = 0;
        
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $dashboard->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            $realisasiTerakhir = 0;
            if (!empty($scurve['actual'])) {
                foreach (array_reverse($scurve['actual']) as $val) {
                    if ($val !== null) { $realisasiTerakhir = $val; break; }
                }
            }
            
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $val) {
                    if ($val !== null) { $lastWeekIndex = $idx; }
                }
                if ($lastWeekIndex >= 0) {
                    $currentActual = $scurve['actual'][$lastWeekIndex] ?? 0;
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    $currentPlan = $scurve['plan'][$lastWeekIndex] ?? 0;
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }
            
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah (Kritis)';
                $totalKritis++;
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning (Perhatian)';
            } else {
                $statusIndikator = 'Hijau (Sesuai Rencana)';
            }
            
            $tglSelesai = strtotime($p['tgl_selesai']);
            if ($tglSelesai < time() && $p['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah (Kritis)';
                } elseif (strpos($statusIndikator, 'Merah') === false) {
                    $statusIndikator = 'Kuning (Perhatian)';
                }
            }
            
            $summaryData[] = [
                'nama_proyek' => $p['nama_proyek'],
                'opd' => $p['nama_satker'] ?? 'Dinas Terkait',
                'penyedia' => $p['nama_penyedia'],
                'realisasi_kumulatif' => $realisasiTerakhir . '%',
                'deviasi_kumulatif' => $deviasiTerakhir . '%',
                'deviasi_mingguan' => $deviasiMingguan . '%',
                'status' => $statusIndikator
            ];
        }

        return json_encode([
            'keterangan' => 'Ringkasan Monitoring dan Evaluasi Proyek Berjalan',
            'total_proyek' => $totalProyek,
            'total_proyek_kritis' => $totalKritis,
            'detail_proyek' => $summaryData
        ]);
    }

    private function getRealisasiPerOpd($argsStr)
    {
        $args = json_decode($argsStr, true);
        $type = $args['tipe'] ?? 'tender'; // tender, nontender, swakelola, epurchasing
        $year = $args['tahun'] ?? date('Y');

        $db = \Config\Database::connect();
        $builder = null;
        $sumField = 'nilai_kontrak';

        if ($type === 'tender') {
            $builder = $db->table('lpse_tender');
            $sumField = 'nilai_kontrak';
        } elseif ($type === 'nontender' || $type === 'pencatatan_nontender') {
            $builder = $db->table('lpse_nontender');
            $sumField = 'nilai_kontrak';
            if ($type === 'pencatatan_nontender') {
                $builder = $db->table('lpse_pencatatan_nontender');
                $sumField = 'realisasi';
            }
        } elseif ($type === 'swakelola' || $type === 'pencatatan_swakelola') {
            $builder = $db->table('lpse_pencatatan_swakelola');
            $sumField = 'realisasi';
        } elseif ($type === 'epurchasing') {
            $builder = $db->table('epurchasing');
            $sumField = 'total_harga';
        }

        if (!$builder) {
            return json_encode(['error' => 'Tipe pengadaan tidak valid.']);
        }

        $builder->select("nama_satker as opd, SUM($sumField) as total_realisasi, COUNT(*) as jumlah_paket");
        if ($year && $year !== 'all') {
            $builder->where('tahun', $year);
        }
        $builder->groupBy('nama_satker');
        $builder->orderBy('total_realisasi', 'DESC');
        $data = $builder->get()->getResultArray();

        $totalKeseluruhan = 0;
        foreach ($data as $k => $v) {
            $data[$k]['total_realisasi'] = (float) $v['total_realisasi'];
            $totalKeseluruhan += $data[$k]['total_realisasi'];
        }

        return json_encode([
            'tipe_pengadaan' => $type,
            'tahun' => $year,
            'total_realisasi_seluruh_opd' => $totalKeseluruhan,
            'data_per_opd' => $data
        ]);
    }

    private function findPaketWinner($query)
    {
        $model = new EpurchasingModel();
        // Try to find a winner entry first (status indicating winner), fallback to any matching paket
        $winner = $model->where('status', 'pemenang')->like('nama_paket', $query)->first();
        if ($winner) return $winner;
        return $model->like('nama_paket', $query)->first();
    }

    private function callOpenAI($message, $apiKey, $model, $url, $history = [])
    {
        $systemPrompt = "Kamu adalah AJIP (Asisten Jenius Informasi Pengadaan). 
        Kamu memiliki akses ke seluruh data pengadaan di aplikasi ini, termasuk RUP (Rencana Umum Pengadaan), REALISASI LPSE & E-Purchasing, serta MONEV PROYEK (Monitoring dan Evaluasi).
        Kamu juga bertindak sebagai Auditor dan Konsultan Manajemen Proyek Konstruksi yang cerdas. Kamu dapat menganalisis laporan mingguan PPK, memvalidasi kewajaran alasan keterlambatan, mengevaluasi deviasi jadwal (S-Curve), dan memberikan saran mitigasi teknis jika proyek berstatus kritis (deviasi di bawah -10%).
        Tugasmu adalah membantu user terkait statistik, progres, deviasi proyek, dan realisasi tiap OPD secara akurat dan jenius.
        Selalu format angka rupiah (contoh: Rp 10.000.000) dan persentase dengan rapi agar mudah dibaca.
        Gunakan tool secara cerdas untuk mencari data yang diminta user (seperti total pagu RUP, pagu tiap OPD, tender, non-tender, pencatatan swakelola/non-tender, dan monev proyek mendalam).
        PENTING: Di akhir setiap jawabanmu, SELALU berikan daftar pilihan lanjutan menggunakan nomor urut (1, 2, 3) agar user bisa membalas dengan nomor untuk pertanyaan selanjutnya. Pastikan daftar pilihan relevan dengan konteks pembahasan saat ini.";

        $messages = [['role' => 'system', 'content' => $systemPrompt]];
        
        foreach ($history as $h) {
            $messages[] = $h;
        }

        $messages[] = ['role' => 'user', 'content' => $message];

        // Definisi alat (Tools/Functions) untuk AI
        $tools = [
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_pagu_summary',
                    'description' => 'Mendapatkan ringkasan statistik (total pagu dan jumlah paket) dengan filter tipe, metode, jenis pengadaan, atau OPD tertentu.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'tipe' => [
                                'type' => 'string',
                                'enum' => ['penyedia', 'swakelola'],
                                'description' => 'Wajib diisi. Tipe pengadaan.'
                            ],
                            'metode' => [
                                'type' => 'string',
                                'description' => 'Filter metode pengadaan (misal: "e-purchasing", "tender", "seleksi", "pengadaan langsung").'
                            ],
                            'opd' => [
                                'type' => 'string',
                                'description' => 'Filter nama OPD/Dinas tertentu.'
                            ],
                            'jenis_pengadaan' => [
                                'type' => 'string',
                                'description' => 'Filter jenis pengadaan (Barang, Jasa Lainnya, dll). Hanya untuk tipe penyedia.'
                            ]
                        ],
                        'required' => ['tipe']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_opd_pagu_ranking',
                    'description' => 'Jawaban terbaik untuk: "OPD mana dengan total pagu terbesar/terkecil" atau "Bagaimana ranking OPD". Ini menjumlahkan pagu per OPD.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'tipe' => [
                                'type' => 'string',
                                'enum' => ['penyedia', 'swakelola'],
                                'description' => 'Tipe pengadaan yang ingin dirangking pagunya per OPD.'
                            ],
                            'sort' => [
                                'type' => 'string',
                                'enum' => ['terbesar', 'terkecil'],
                                'description' => 'Urutkan dari yang terbesar (tertinggi) atau terkecil (terendah).'
                            ]
                        ],
                        'required' => ['tipe']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'search_paket_detail',
                    'description' => 'Mencari dan membaca detail daftar paket pengadaan individual (seperti rincian nilai pagu per paket, jenis pengadaan, metode, mengandung kata spesifik di nama paket atau spesifikasi).',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'query' => [
                                'type' => 'string',
                                'description' => 'Kata kunci untuk mencari nama paket atau spesifikasi, misal "sekolah", "laptop", "internet", atau "pekerjaan Alun", kosongkan jika tidak butuh.'
                            ],
                            'opd' => [
                                'type' => 'string',
                                'description' => 'Nama OPD atau Dinas atau Satker spesifik.'
                            ],
                            'metode' => [
                                'type' => 'string',
                                'description' => 'Metode pengadaan spesifik (misal: "e-purchasing", "tender", "pengadaan langsung", "dikecualikan", dsb).'
                            ],
                            'jenis_pengadaan' => [
                                'type' => 'string',
                                'description' => 'Filter jenis pengadaan (Hanya untuk tipe Penyedia). Gunakan salah satu: "Barang", "Pekerjaan Konstruksi", "Jasa Konsultansi", "Jasa Lainnya". JANGAN masukkan keyword pencarian di sini.'
                            ],
                            'tipe' => [
                                'type' => 'string',
                                'enum' => ['penyedia', 'swakelola'],
                                'description' => 'Tipe pengadaan yang ingin dicari rinciannya.'
                            ],
                            'sort_pagu' => [
                                'type' => 'string',
                                'enum' => ['terbesar', 'terkecil'],
                                'description' => 'Urutkan nilai paket terbesar/termahal atau terkecil/termurah.'
                            ]
                        ],
                        'required' => ['tipe']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_epurchasing_stats',
                    'description' => 'Mendapatkan statistik REALISASI E-Purchasing terbaru tahun berjalan (Total nilai, jumlah paket, dan analisis tren). Gunakan ini jika user bertanya tentang E-Katalog atau E-Purchasing.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => new \stdClass()
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_lpse_realisasi_summary',
                    'description' => 'Mendapatkan ringkasan realisasi nyata dari LPSE (Tender, Non-Tender, atau Swakelola).',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'tipe' => [
                                'type' => 'string',
                                'enum' => ['tender', 'nontender', 'swakelola'],
                                'description' => 'Tipe pengadaan yang ingin dilihat realisasinya.'
                            ],
                            'tahun' => [
                                'type' => 'string',
                                'description' => 'Tahun anggaran, default tahun berjalan.'
                            ]
                        ],
                        'required' => ['tipe']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_monev_summary',
                    'description' => 'Mendapatkan ringkasan statistik dan status monitoring & evaluasi (Monev) seluruh proyek. Gunakan jika user bertanya tentang progres proyek atau monev.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => new \stdClass()
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_realisasi_per_opd',
                    'description' => 'Mendapatkan total realisasi yang dikelompokkan per OPD/Satker berdasarkan tipe pengadaan (Tender, Non-Tender, Pencatatan, dll).',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'tipe' => [
                                'type' => 'string',
                                'enum' => ['tender', 'nontender', 'pencatatan_nontender', 'swakelola', 'pencatatan_swakelola', 'epurchasing'],
                                'description' => 'Tipe pengadaan yang ingin dirangkum per OPD.'
                            ],
                            'tahun' => [
                                'type' => 'string',
                                'description' => 'Tahun anggaran, default tahun berjalan.'
                            ]
                        ],
                        'required' => ['tipe']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'search_knowledge_base',
                    'description' => 'Mencari aturan hukum pengadaan atau pedoman dari library PDF yang telah diunggah. Gunakan ini JIKA user bertanya tentang aturan, dasar hukum, atau prosedur pengadaan (seperti Perpres).',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'query' => [
                                'type' => 'string',
                                'description' => 'Pertanyaan atau kata kunci spesifik terkait aturan hukum yang ingin dicari di RAG.'
                            ]
                        ],
                        'required' => ['query']
                    ]
                ]
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_vendor_performance',
                    'description' => 'Mendapatkan data historis dan ringkasan kinerja penyedia/vendor tertentu di semua data pengadaan (Tender, Non-Tender, E-Purchasing, Monev).',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'nama_penyedia' => [
                                'type' => 'string',
                                'description' => 'Nama lengkap atau sebagian nama vendor/perusahaan (misal "PT. ABC", "CV. XYZ").'
                            ]
                        ],
                        'required' => ['nama_penyedia']
                    ]
                ]
            ],

            [
                'type' => 'function',
                'function' => [
                    'name' => 'analyze_monev_project',
                    'description' => 'Menganalisis proyek secara mendalam layaknya konsultan manajemen konstruksi. Mengambil data jadwal rencana, laporan mingguan PPK, kendala/keterangan keterlambatan, dan deviasi S-Curve aktual.',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'nama_proyek' => [
                                'type' => 'string',
                                'description' => 'Nama spesifik proyek yang ingin dianalisis. Jika ingin menganalisis proyek yang saat ini kritis, masukkan kata kunci "kritis" atau kosongkan.'
                            ]
                        ]
                    ]
                ]
            ]
        ];

        // Loop untuk handle Tool Calling secara rekursif (maksimal 100 pemanggilan)
        for ($i = 0; $i < 100; $i++) {
            $data = [
                'model' => $model,
                'messages' => $messages,
                'max_tokens' => 2000,
                'temperature' => 0.7
            ];
            
            // Selalu sertakan tools agar model tidak bingung saat menerima history berisi tool_call sebelumnya
            $data['tools'] = $tools;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'api-key: ' . $apiKey
            ]);

            $response = curl_exec($ch);
            $error = curl_error($ch);
            curl_close($ch);
            
            // Debugging log
            file_put_contents(FCPATH . 'debug_chat.log', "Payload: " . json_encode($data) . "\nResponse: " . $response . "\nCurlError: " . $error . "\n");

            if ($error) {
                return ['error' => $error];
            }

            $responseArray = json_decode($response, true);
            if (isset($responseArray['error'])) {
                return $responseArray;
            }

            $responseMessage = $responseArray['choices'][0]['message'] ?? null;
            if (!$responseMessage) {
                 return ['error' => 'Invalid response from AI'];
            }

            // Fallback parse for models that return tool calls in raw text format (like mimo-v2-flash)
            if (empty($responseMessage['tool_calls']) && isset($responseMessage['content']) && strpos($responseMessage['content'], '<tool_call>') !== false) {
                if (preg_match('/<function=([^>]+)>(.*?)<\/function>/s', $responseMessage['content'], $matches)) {
                    $funcName = trim($matches[1]);
                    $paramStr = $matches[2];
                    $args = [];
                    if (preg_match_all('/<parameter=([^>]+)>(.*?)<\/parameter>/s', $paramStr, $pMatches)) {
                        foreach ($pMatches[1] as $idx => $key) {
                            $args[trim($key)] = trim($pMatches[2][$idx]);
                        }
                    }
                    $responseMessage['tool_calls'] = [
                        [
                            'id' => 'call_' . uniqid(),
                            'type' => 'function',
                            'function' => [
                                'name' => $funcName,
                                'arguments' => json_encode($args)
                            ]
                        ]
                    ];
                    $responseMessage['content'] = trim(preg_replace('/<tool_call>.*?<\/tool_call>/s', '', $responseMessage['content']));
                }
            }

            // Tambahkan balasan AI (Termasuk jika dia merespons dengan panggilan fungsi)
            $messages[] = $responseMessage;

            // Cek apakah AI ingin kita menjalankan sebuah fungsi lokal (Tool Call)
            if (isset($responseMessage['tool_calls']) && !empty($responseMessage['tool_calls'])) {
                foreach ($responseMessage['tool_calls'] as $toolCall) {
                    $functionName = $toolCall['function']['name'];
                    $functionArgs = $toolCall['function']['arguments'];
                    $functionResponse = '';

                    if ($functionName === 'get_pagu_summary') {
                        $functionResponse = $this->getPaguSummary($functionArgs);
                    } else if ($functionName === 'get_opd_pagu_ranking') {
                        $functionResponse = $this->getOpdPaguRanking($functionArgs);
                    } else if ($functionName === 'search_paket_detail') {
                        $functionResponse = $this->searchPaket($functionArgs);
                    } else if ($functionName === 'get_epurchasing_stats') {
                        $functionResponse = $this->getEpurchasingStats();
                    } else if ($functionName === 'get_lpse_realisasi_summary') {
                        $functionResponse = $this->getLpseRealisasiStats($functionArgs);
                    } else if ($functionName === 'get_monev_summary') {
                        $functionResponse = $this->getMonevSummary();
                    } else if ($functionName === 'get_realisasi_per_opd') {
                        $functionResponse = $this->getRealisasiPerOpd($functionArgs);
                    } else if ($functionName === 'search_knowledge_base') {
                        $functionResponse = $this->searchKnowledgeBase($functionArgs);
                    } else if ($functionName === 'get_vendor_performance') {
                        $functionResponse = $this->getVendorPerformance($functionArgs);

                    } else if ($functionName === 'analyze_monev_project') {
                        $functionResponse = $this->analyzeMonevProject($functionArgs);
                    } else {
                        $functionResponse = json_encode(['error' => 'Fungsi tidak terdaftar']);
                    }

                    // Masukkan hasil fungsi ke dalam antrean chat
                    $messages[] = [
                        'tool_call_id' => $toolCall['id'],
                        'role' => 'tool',
                        'name' => $functionName,
                        'content' => $functionResponse,
                    ];
                }
                
                // Teruskan loop untuk memanggil AI lagi dengan menyertakan hasil tool (kini tanpa parameter 'tools' di request berikutnya)
                continue;
            } else {
                // Jika AI merespons teks biasa, return hasil akhir
                return $responseArray;
            }
        }
        
        // Jika masih dalam loop setelah batas maksimal, kembalikan respon terakhir (jika ada) atau beri pesan error yang lebih informatif
        $lastMessage = end($messages);
        if (is_array($lastMessage) && isset($lastMessage['content'])) {
            return ['status' => 'success', 'reply' => $lastMessage['content']];
        }
        return ['error' => 'Tidak dapat menyelesaikan permintaan karena terlalu banyak panggilan tool.'];
    }

    private function searchKnowledgeBase($argsStr)
    {
        $settingsModel = new \App\Models\SettingsModel();
        $apiKey = $settingsModel->getSetting('embedding_api_key', env('OPENAI_API_KEY'));
        $url = $settingsModel->getSetting('embedding_api_url', 'https://api.openai.com/v1/embeddings');
        $modelName = $settingsModel->getSetting('embedding_model', 'text-embedding-3-small');

        $args = json_decode($argsStr, true);
        $query = $args['query'] ?? '';
        if (!$query) return json_encode(['error' => 'Query kosong']);

        // Dapatkan vektor dari query
        $data = [
            'model' => $modelName,
            'input' => $query
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        curl_close($ch);
        $resObj = json_decode($response, true);
        if (!isset($resObj['data'][0]['embedding'])) {
            return json_encode(['error' => 'Gagal mendapatkan embedding', 'response' => $response]);
        }

        $queryEmbedding = $resObj['data'][0]['embedding'];

        // Ambil data dari DB
        $db = \Config\Database::connect();
        try {
            $chunks = $db->table('chatbot_knowledge')->get()->getResultArray();
        } catch (\Exception $e) {
            return json_encode(['error' => 'Belum ada library knowledge yang diunggah']);
        }

        if (empty($chunks)) {
            return json_encode(['error' => 'Belum ada library knowledge yang diunggah']);
        }

        $results = [];
        foreach ($chunks as $chunk) {
            $dbVec = json_decode($chunk['embedding_vector'], true);
            if (!$dbVec) continue;

            $similarity = $this->cosineSimilarity($queryEmbedding, $dbVec);
            $results[] = [
                'document' => $chunk['document_title'],
                'text' => $chunk['chunk_text'],
                'similarity' => $similarity
            ];
        }

        // Urutkan berdasarkan similarity tertinggi
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });

        // Ambil top 4
        $top = array_slice($results, 0, 4);
        return json_encode(['top_relevant_rules' => $top]);
    }

    private function cosineSimilarity($vec1, $vec2) {
        $dotProduct = 0;
        $normA = 0;
        $normB = 0;
        foreach ($vec1 as $i => $v) {
            $dotProduct += $v * $vec2[$i];
            $normA += pow($v, 2);
            $normB += pow($vec2[$i], 2);
        }
        if ($normA == 0 || $normB == 0) return 0;
        return $dotProduct / (sqrt($normA) * sqrt($normB));
    }

    private function getVendorPerformance($argsStr)
    {
        $args = json_decode($argsStr, true);
        $vendor = $args['nama_penyedia'] ?? '';
        if (!$vendor) return json_encode(['error' => 'Nama penyedia kosong']);

        $db = \Config\Database::connect();
        $summary = [];

        // LPSE Tender
        try {
            $tender = $db->table('lpse_tender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->countAllResults(false);
            $tenderVal = $db->table('lpse_tender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->get()->getRow()->total ?? 0;
            $tenderDetail = $db->table('lpse_tender')->like('pemenang', $vendor)->select('nama_paket, nilai_penawaran, tahun')->limit(5)->get()->getResultArray();
            $summary['Tender'] = ['jumlah_paket' => $tender, 'total_nilai' => $tenderVal, 'contoh_paket' => $tenderDetail];
        } catch (\Exception $e) {}

        // LPSE Non Tender
        try {
            $nontender = $db->table('lpse_nontender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->countAllResults(false);
            $ntVal = $db->table('lpse_nontender')->like('pemenang', $vendor)->selectSum('nilai_penawaran', 'total')->get()->getRow()->total ?? 0;
            $ntDetail = $db->table('lpse_nontender')->like('pemenang', $vendor)->select('nama_paket, nilai_penawaran, tahun')->limit(5)->get()->getResultArray();
            $summary['Non_Tender'] = ['jumlah_paket' => $nontender, 'total_nilai' => $ntVal, 'contoh_paket' => $ntDetail];
        } catch (\Exception $e) {}

        // EPurchasing
        try {
            $epur = $db->table('epurchasing')->like('nama_penyedia', $vendor)->selectSum('total_harga', 'total')->countAllResults(false);
            $epurVal = $db->table('epurchasing')->like('nama_penyedia', $vendor)->selectSum('total_harga', 'total')->get()->getRow()->total ?? 0;
            $epurDetail = $db->table('epurchasing')->like('nama_penyedia', $vendor)->select('nama_paket, total_harga, tahun')->limit(5)->get()->getResultArray();
            $summary['E_Purchasing'] = ['jumlah_paket' => $epur, 'total_nilai' => $epurVal, 'contoh_paket' => $epurDetail];
        } catch (\Exception $e) {}

        // Monev
        try {
            $monevBuilder = $db->table('monev_proyek')->like('nama_penyedia', $vendor);
            $monevTotal = $monevBuilder->countAllResults(false);
            $monevTerlambat = $db->table('monev_proyek')->like('nama_penyedia', $vendor)->where('status', 'Terlambat')->countAllResults();
            $monevSelesai = $db->table('monev_proyek')->like('nama_penyedia', $vendor)->where('status', 'Selesai')->countAllResults();
            
            $monevDetail = $db->table('monev_proyek')
                              ->like('nama_penyedia', $vendor)
                              ->select('nama_proyek, nilai_kontrak, status, tgl_mulai, tgl_selesai')
                              ->orderBy('tgl_mulai', 'DESC')
                              ->limit(10)
                              ->get()
                              ->getResultArray();

            $summary['Monev_Proyek'] = [
                'total_proyek_dimonev' => $monevTotal, 
                'selesai' => $monevSelesai, 
                'terlambat' => $monevTerlambat,
                'detail_proyek' => $monevDetail
            ];
        } catch (\Exception $e) {}

        return json_encode([
            'nama_penyedia_dicari' => $vendor,
            'summary_kinerja' => $summary
        ]);
    }



    private function analyzeMonevProject($argsStr)
    {
        $args = json_decode($argsStr, true);
        $namaProyek = $args['nama_proyek'] ?? '';
        
        $proyekModel = new \App\Models\MonevProyekModel();
        $jadwalModel = new \App\Models\MonevJadwalModel();
        $harianModel = new \App\Models\MonevHarianModel();
        
        $builder = $proyekModel->builder();
        
        if (strtolower($namaProyek) === 'kritis') {
            // Find all projects, we will compute them below
            $proyekList = $proyekModel->findAll();
        } else if (!empty($namaProyek)) {
            $builder->like('nama_proyek', $namaProyek);
            $proyekList = $proyekModel->findAll();
        } else {
            $proyekList = $proyekModel->findAll();
        }

        if (empty($proyekList)) {
            return json_encode(['error' => 'Proyek tidak ditemukan.']);
        }

        $dashboard = new \App\Controllers\Dashboard();
        $dashboard->initController($this->request, $this->response, $this->logger);

        $results = [];
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $dashboard->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            // Extract latest "Kendala" and "Keterangan"
            $laporanPenting = [];
            foreach (array_reverse($harianItems) as $hari) {
                if (!empty($hari['kendala']) || !empty($hari['keterangan'])) {
                    $laporanPenting[] = [
                        'tanggal' => $hari['tanggal'],
                        'kendala' => $hari['kendala'],
                        'keterangan' => $hari['keterangan'],
                        'progres_hari_itu' => $hari['progres_persen'] . '%'
                    ];
                }
                if (count($laporanPenting) >= 5) break; // Limit top 5 recent issues
            }

            $isKritis = ($deviasiTerakhir <= -10);

            // Filter if user specifically asked for "kritis"
            if (strtolower($namaProyek) === 'kritis' && !$isKritis) {
                continue;
            }

            $results[] = [
                'nama_proyek' => $p['nama_proyek'],
                'penyedia' => $p['nama_penyedia'],
                'tgl_mulai' => $p['tgl_mulai'],
                'tgl_selesai' => $p['tgl_selesai'],
                'nilai_kontrak' => (float)$p['nilai_kontrak'],
                'status_proyek' => $p['status'],
                'deviasi_terakhir' => $deviasiTerakhir . '%',
                'status_indikator' => $isKritis ? 'Kritis' : ($deviasiTerakhir <= -5 ? 'Perhatian' : 'Aman'),
                '5_laporan_kendala_terakhir' => $laporanPenting
            ];
            
            if (count($results) >= 5) break; // Limit output size to prevent token limits
        }

        if (empty($results)) {
            return json_encode(['message' => 'Tidak ada proyek kritis atau data yang sesuai kriteria.']);
        }

        return json_encode([
            'catatan' => 'Data deviasi didapat dari perhitungan kumulatif aktual dikurangi rencana S-Curve. Jika deviasi minus, proyek terlambat.',
            'data' => $results
        ]);
    }
}
