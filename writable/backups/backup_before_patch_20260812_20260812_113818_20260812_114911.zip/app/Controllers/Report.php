<?php

namespace App\Controllers;

use App\Models\RupPenyediaModel;
use App\Models\RupSwakelolaModel;
use App\Models\LpseTenderModel;
use App\Models\LpseNontenderModel;
use App\Models\EpurchasingModel;
use App\Models\LpsePencatatanNontenderModel;
use App\Models\LpsePencatatanSwakelolaModel;
use App\Models\MasterAnggaranModel;

class Report extends BaseController
{
    public function index()
    {
        return view('report/index', [
            'title' => 'Summary Laporan Realisasi',
            'user'  => session()->get(),
        ]);
    }

    public function getSummaryData()
    {
        $year = $this->request->getGet('year') ?? date('Y');
        $cacheKey = "report_summary_v1_{$year}";

        if (!$result = cache($cacheKey)) {
            // Models
            $rupPenyediaModel = new RupPenyediaModel();
            $rupSwakelolaModel = new RupSwakelolaModel();
            $tenderModel = new LpseTenderModel();
            $nontenderModel = new LpseNontenderModel();
            $epurchasingModel = new EpurchasingModel();
            $pencatatanNontenderModel = new LpsePencatatanNontenderModel();
            $pencatatanSwakelolaModel = new LpsePencatatanSwakelolaModel();

            // 1. Get all RUPs for the year
            $rupP = $rupPenyediaModel->where('tahun', $year)->findAll();
            $rupS = $rupSwakelolaModel->where('tahun', $year)->findAll();

            // 2. Map Realization by kd_rup
            $realizationMap = [];

            // Tender
            $tenders = $tenderModel->where('tahun', $year)->findAll();
            foreach ($tenders as $t) {
                $kd = trim($t['kd_rup']);
                if ($kd) {
                    $realizationMap[$kd] = ($realizationMap[$kd] ?? 0) + (float)$t['nilai_kontrak'];
                }
            }

            // Non Tender
            $nontenders = $nontenderModel->where('tahun', $year)->findAll();
            foreach ($nontenders as $nt) {
                $kd = trim($nt['kd_rup']);
                if ($kd) {
                    $realizationMap[$kd] = ($realizationMap[$kd] ?? 0) + (float)$nt['nilai_kontrak'];
                }
            }

            // E-Purchasing
            $epurchasing = $epurchasingModel->where('tahun', $year)->findAll();
            foreach ($epurchasing as $ep) {
                $kd = trim($ep['rup_code']);
                if ($kd) {
                    $realizationMap[$kd] = ($realizationMap[$kd] ?? 0) + (float)$ep['total_harga'];
                }
            }

            // Pencatatan Non Tender
            $pnt = $pencatatanNontenderModel->where('tahun', $year)->findAll();
            foreach ($pnt as $p) {
                $kd = trim($p['kd_rup']);
                if ($kd) {
                    $realizationMap[$kd] = ($realizationMap[$kd] ?? 0) + (float)$p['realisasi'];
                }
            }

            // Pencatatan Swakelola
            $psw = $pencatatanSwakelolaModel->where('tahun', $year)->findAll();
            foreach ($psw as $p) {
                $kd = trim($p['kd_rup']);
                if ($kd) {
                    $realizationMap[$kd] = ($realizationMap[$kd] ?? 0) + (float)$p['realisasi'];
                }
            }

            // 3. Aggregate by Satker
            $satkerSummary = [];

            foreach ($rupP as $item) {
                $kdSatker = $item['kd_satker'] ?: '0';
                if (!isset($satkerSummary[$kdSatker])) {
                    $satkerSummary[$kdSatker] = [
                        'nama_satker' => $item['nama_satker'],
                        'kd_satker' => $kdSatker,
                        'pagu_penyedia' => 0,
                        'total_paket_p' => 0,
                        'realisasi_penyedia' => 0,
                        'paket_realisasi_p' => 0,
                        'pagu_swakelola' => 0,
                        'total_paket_s' => 0,
                        'realisasi_swakelola' => 0,
                        'paket_realisasi_s' => 0,
                    ];
                }
                $satkerSummary[$kdSatker]['pagu_penyedia'] += (float)$item['pagu'];
                $satkerSummary[$kdSatker]['total_paket_p'] += 1;
                
                $kdRup = trim($item['kd_rup']);
                if ($kdRup && isset($realizationMap[$kdRup])) {
                    $satkerSummary[$kdSatker]['realisasi_penyedia'] += $realizationMap[$kdRup];
                    $satkerSummary[$kdSatker]['paket_realisasi_p'] += 1;
                }
            }

            foreach ($rupS as $item) {
                $kdSatker = $item['kd_satker'] ?: '0';
                if (!isset($satkerSummary[$kdSatker])) {
                    $satkerSummary[$kdSatker] = [
                        'nama_satker' => $item['nama_satker'],
                        'kd_satker' => $kdSatker,
                        'pagu_penyedia' => 0,
                        'total_paket_p' => 0,
                        'realisasi_penyedia' => 0,
                        'paket_realisasi_p' => 0,
                        'pagu_swakelola' => 0,
                        'total_paket_s' => 0,
                        'realisasi_swakelola' => 0,
                        'paket_realisasi_s' => 0,
                    ];
                }
                $satkerSummary[$kdSatker]['pagu_swakelola'] += (float)$item['pagu'];
                $satkerSummary[$kdSatker]['total_paket_s'] += 1;

                $kdRup = trim($item['kd_rup']);
                if ($kdRup && isset($realizationMap[$kdRup])) {
                    $satkerSummary[$kdSatker]['realisasi_swakelola'] += $realizationMap[$kdRup];
                    $satkerSummary[$kdSatker]['paket_realisasi_s'] += 1;
                }
            }

            // 4. Sort by nama_satker
            usort($satkerSummary, function($a, $b) {
                return strcmp($a['nama_satker'] ?? '', $b['nama_satker'] ?? '');
            });
            
            $result = $satkerSummary;
            cache()->save($cacheKey, $result, 3600);
        }

        return $this->response->setJSON($result);
    }
}
