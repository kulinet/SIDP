<style>
/* Modern Chatbot UI Styles */
.chatbot-widget {
    position: fixed;
    bottom: 30px;
    right: 30px;
    z-index: 9999;
}

/* Hide on desktop as requested: hanya untuk view dari HP */
@media (min-width: 769px) {
    .chatbot-widget {
        display: none !important;
    }
}

.chatbot-widget {
    font-family: 'Public Sans', 'Inter', sans-serif;
}

.chatbot-btn {
    width: 65px;
    height: 65px;
    border-radius: 50%;
    background: linear-gradient(135deg, #00d2ff 0%, #3a7bd5 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 8px 20px rgba(58, 123, 213, 0.4);
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0.7); }
    70% { box-shadow: 0 0 0 15px rgba(58, 123, 213, 0); }
    100% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0); }
}

.chatbot-btn:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 25px rgba(58, 123, 213, 0.6);
}

.chatbot-btn i {
    font-size: 32px;
}

.chatbot-window {
    display: none;
    position: absolute;
    bottom: 85px;
    right: 0;
    width: 380px;
    height: 550px;
    background-color: #f8f9fa;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    flex-direction: column;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.4);
    transform-origin: bottom right;
    animation: scaleIn 0.3s cubic-bezier(0.25, 0.8, 0.25, 1) forwards;
}

@keyframes scaleIn {
    0% { opacity: 0; transform: scale(0.5); }
    100% { opacity: 1; transform: scale(1); }
}

.chatbot-window.active {
    display: flex;
}

.chatbot-header {
    padding: 20px;
    background: linear-gradient(135deg, #00d2ff 0%, #3a7bd5 100%);
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.chatbot-header-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.chatbot-avatar {
    width: 40px;
    height: 40px;
    background-color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #3a7bd5;
    font-size: 24px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}

.chatbot-header h5 {
    margin: 0;
    font-size: 17px;
    font-weight: 700;
    color: white;
    letter-spacing: 0.5px;
}

.chatbot-header p {
    margin: 0;
    font-size: 12px;
    color: rgba(255,255,255,0.8);
}

.chatbot-header .close-btn {
    cursor: pointer;
    font-size: 24px;
    opacity: 0.8;
    transition: opacity 0.2s;
}

.chatbot-header .close-btn:hover {
    opacity: 1;
}

.chatbot-messages {
    flex-grow: 1;
    padding: 20px;
    overflow-y: auto;
    background-color: #f4f7f6;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

/* Custom Scrollbar for messages */
.chatbot-messages::-webkit-scrollbar {
    width: 6px;
}
.chatbot-messages::-webkit-scrollbar-track {
    background: transparent;
}
.chatbot-messages::-webkit-scrollbar-thumb {
    background: #cdd5df;
    border-radius: 10px;
}

.chat-message-wrapper {
    display: flex;
    gap: 10px;
    max-width: 90%;
}

.chat-message-wrapper.bot {
    align-self: flex-start;
}

.chat-message-wrapper.user {
    align-self: flex-end;
    flex-direction: row-reverse;
}

.message-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    flex-shrink: 0;
}

.message-avatar.bot {
    background: linear-gradient(135deg, #00d2ff 0%, #3a7bd5 100%);
    color: white;
}

.message-avatar.user {
    background-color: #dbe0e6;
    color: #555;
}

.chat-message {
    padding: 12px 16px;
    font-size: 14px;
    line-height: 1.5;
    word-wrap: break-word;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.chat-message.bot {
    background-color: #fff;
    color: #333;
    border-radius: 0 16px 16px 16px;
}

.chat-message.user {
    background: linear-gradient(135deg, #3a7bd5 0%, #3a6073 100%);
    color: white;
    border-radius: 16px 0 16px 16px;
}

.chatbot-input-area {
    padding: 15px;
    background-color: #fff;
    border-top: 1px solid #eaeaea;
    display: flex;
    gap: 10px;
    align-items: center;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}

.chatbot-input-area input {
    flex-grow: 1;
    padding: 12px 20px;
    background-color: #f0f2f5;
    border: none;
    border-radius: 25px;
    outline: none;
    font-size: 14px;
    transition: box-shadow 0.2s;
}

.chatbot-input-area input:focus {
    box-shadow: 0 0 0 2px rgba(58, 123, 213, 0.3);
}

.chatbot-input-area button {
    background: linear-gradient(135deg, #00d2ff 0%, #3a7bd5 100%);
    color: white;
    border: none;
    border-radius: 50%;
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 4px 10px rgba(58, 123, 213, 0.3);
}

.chatbot-input-area button:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(58, 123, 213, 0.4);
}

.chatbot-input-area button:disabled {
    background: #ccc;
    cursor: not-allowed;
    box-shadow: none;
}

/* Typing Indicator */
.typing-indicator-wrapper {
    display: none;
    align-self: flex-start;
    gap: 10px;
    margin-bottom: 10px;
}

.typing-indicator {
    background-color: #fff;
    padding: 15px 18px;
    border-radius: 0 16px 16px 16px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
}

.typing-indicator span {
    display: inline-block;
    width: 8px;
    height: 8px;
    background-color: #3a7bd5;
    border-radius: 50%;
    margin-right: 5px;
    animation: wave 1.3s linear infinite;
}

.typing-indicator span:nth-child(2) { animation-delay: -1.1s; }
.typing-indicator span:nth-child(3) { animation-delay: -0.9s; margin-right: 0; }

@keyframes wave {
    0%, 60%, 100% { transform: initial; }
    30% { transform: translateY(-7px); }
}

.chatbot-suggestions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    padding: 5px 0;
    align-self: center;
    justify-content: center;
    width: 100%;
}

.suggestion-btn {
    background: rgba(58, 123, 213, 0.1);
    border: 1px solid rgba(58, 123, 213, 0.3);
    color: #3a7bd5;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
}

.suggestion-btn:hover {
    background: linear-gradient(135deg, #00d2ff 0%, #3a7bd5 100%);
    color: #fff;
    border-color: transparent;
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(58, 123, 213, 0.3);
}

/* Copy Button Styling */
.copy-btn-modern {
    background: rgba(58, 123, 213, 0.08) !important;
    border: 1px solid rgba(58, 123, 213, 0.2) !important;
    color: #3a7bd5 !important;
    border-radius: 12px !important;
    padding: 4px 10px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer;
    transition: all 0.2s !important;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.copy-btn-modern:hover {
    background: rgba(58, 123, 213, 0.15) !important;
}
</style>

<div class="chatbot-widget">
    <div class="chatbot-window" id="chatbotWindow">
        <div class="chatbot-header">
            <div class="chatbot-header-info">
                <div class="chatbot-avatar" style="background-color: transparent; box-shadow: none;">
                    <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="AJIP Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: contain; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
                </div>
                <div>
                    <h5>AJIP Assistant</h5>
                    <p>Siap Membantu Anda ⚡</p>
                </div>
            </div>
            <i class='bx bx-x close-btn' id="closeChat"></i>
        </div>
        <div class="chatbot-messages" id="chatbotMessages">
            
            <?php 
            $history = session()->get('chat_history') ?? [];
            if (empty($history)): 
            ?>
            <div class="chat-message-wrapper bot">
                <div class="message-avatar bot" style="background: transparent;">
                    <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="Bot" style="width: 100%; height: 100%; border-radius: 50%; object-fit: contain; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
                </div>
                <div class="chat-message bot">Halo! Saya adalah <b>AJIP</b> (Asisten Jenius Informasi Pengadaan). Saya telah diperbarui untuk bisa memantau jadwal proyek, deviasi kurva-S, laporan kendala mingguan, maupun statistik realisasi pengadaan. Ada yang bisa saya bantu?</div>
            </div>
            
            <div class="chatbot-suggestions" id="initialSuggestions">
                <button class="suggestion-btn" data-msg="Tampilkan Ringkasan Pagu RUP">Ringkasan RUP</button>
                <button class="suggestion-btn" data-msg="Realisasi LPSE & E-Purchasing">Realisasi LPSE</button>
                <button class="suggestion-btn" data-msg="Cari proyek yang saat ini statusnya kritis">Proyek Kritis</button>
            </div>
            <?php else: ?>
                <?php foreach ($history as $msg): ?>
                    <?php if ($msg['role'] === 'system' || $msg['role'] === 'tool') continue; ?>
                    <?php 
                        $isUser = $msg['role'] === 'user';
                        $senderClass = $isUser ? 'user' : 'bot';
                        $formattedText = str_replace("\n", "<br>", htmlspecialchars($msg['content']));
                        $formattedText = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $formattedText);
                    ?>
                    <div class="chat-message-wrapper <?= $senderClass ?>">
                        <div class="message-avatar <?= $senderClass ?>" <?= !$isUser ? 'style="background: transparent;"' : '' ?>>
                            <?php if (!$isUser): ?>
                                <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="Bot" style="width: 100%; height: 100%; border-radius: 50%; object-fit: contain; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
                            <?php else: ?>
                                <i class='bx bx-user'></i>
                            <?php endif; ?>
                        </div>
                        <div class="chat-message <?= $senderClass ?>"><?= $formattedText ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="typing-indicator-wrapper" id="typingIndicator">
                <div class="message-avatar bot" style="background: transparent;">
                    <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="Bot" style="width: 100%; height: 100%; border-radius: 50%; object-fit: contain; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
                </div>
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            </div>
            
        </div>
        <div class="chatbot-input-area">
            <input type="text" id="chatInput" placeholder="Tanya AJIP di sini..." autocomplete="off">
            <button id="sendMessageBtn"><i class='bx bxs-send'></i></button>
        </div>
    </div>
    <div class="chatbot-btn" id="openChat" style="padding: 0; background: transparent; overflow: hidden;">
        <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="Chat AJIP" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%; box-shadow: 0 4px 15px rgba(58,123,213,0.5);">
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const openBtn = document.getElementById('openChat');
    const closeBtn = document.getElementById('closeChat');
    const chatWindow = document.getElementById('chatbotWindow');
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendMessageBtn');
    const messagesContainer = document.getElementById('chatbotMessages');
    const typingIndicator = document.getElementById('typingIndicator');

    // Restore chat window state if it was open before navigating
    if (sessionStorage.getItem('chatbot_open') === 'true') {
        chatWindow.classList.add('active');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Toggle window
    openBtn.addEventListener('click', () => {
        chatWindow.classList.toggle('active');
        const isOpen = chatWindow.classList.contains('active');
        sessionStorage.setItem('chatbot_open', isOpen);
        if (isOpen) {
            chatInput.focus();
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    });

    closeBtn.addEventListener('click', () => {
        chatWindow.classList.remove('active');
        sessionStorage.setItem('chatbot_open', 'false');
    });

    // Send Message
    function sendMessage() {
        const message = chatInput.value.trim();
        if(!message) return;

        // Append User Message
        appendMessage(message, 'user');
        chatInput.value = '';
        
        // Show typing
        typingIndicator.style.display = 'flex';
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Disable input
        chatInput.disabled = true;
        sendBtn.disabled = true;

        // POST Request
        const formData = new FormData();
        formData.append('message', message);
        formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>');

        fetch('<?= base_url('chatbot/ask') ?>', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            typingIndicator.style.display = 'none';
            chatInput.disabled = false;
            sendBtn.disabled = false;
            chatInput.focus();

            if(data.status === 'success') {
                appendMessage(data.reply, 'bot', () => {
                    appendMenu(); // Tampilkan pilihan menu setelah bot selesai mengetik
                });
            } else {
                appendMessage('Error: ' + (data.message || 'Terjadi kesalahan sistem.'), 'bot', () => {
                    appendMenu();
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            typingIndicator.style.display = 'none';
            chatInput.disabled = false;
            sendBtn.disabled = false;
            appendMessage('Gagal terhubung ke server.', 'bot');
        });
    }

    // Append message helper with Avatar & Typewriter
    function appendMessage(text, sender, onComplete) {
        const wrapperDiv = document.createElement('div');
        wrapperDiv.className = `chat-message-wrapper ${sender}`;

        const avatarDiv = document.createElement('div');
        avatarDiv.className = `message-avatar ${sender}`;
        if (sender === 'bot') {
            avatarDiv.style.background = 'transparent';
            avatarDiv.innerHTML = `<img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="Bot" style="width: 100%; height: 100%; border-radius: 50%; object-fit: contain; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">`;
        } else {
            avatarDiv.innerHTML = "<i class='bx bx-user'></i>";
        }
        
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-message ${sender}`;
        
        let formattedText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, "<br>");
        
        let btnContainer = null;
        if (sender === 'bot') {
            btnContainer = document.createElement('div');
            btnContainer.style.marginTop = '10px';
            btnContainer.style.textAlign = 'right';
            
            const copyBtn = document.createElement('button');
            copyBtn.className = 'copy-btn-modern';
            copyBtn.innerHTML = '<i class="bx bx-copy"></i> Salin';
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(text).then(() => {
                    const originalHTML = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="bx bx-check"></i> Tersalin!';
                    setTimeout(() => copyBtn.innerHTML = originalHTML, 2000);
                });
            });
            btnContainer.appendChild(copyBtn);
        }
        
        wrapperDiv.appendChild(avatarDiv);
        wrapperDiv.appendChild(msgDiv);
        messagesContainer.insertBefore(wrapperDiv, typingIndicator);

        if (sender === 'bot') {
            let tempDiv = document.createElement('div');
            tempDiv.innerHTML = formattedText;
            
            function typeWriterHTML(sourceNode, targetNode, callback) {
                if (!sourceNode) return callback && callback();
                
                let childNodes = Array.from(sourceNode.childNodes);
                
                function processNextNode(index) {
                    if (index >= childNodes.length) return callback && callback();
                    
                    let child = childNodes[index];
                    if (child.nodeType === Node.TEXT_NODE) {
                        let textContent = child.textContent;
                        let textIndex = 0;
                        let textNode = document.createTextNode('');
                        targetNode.appendChild(textNode);
                        
                        function typeText() {
                            if (textIndex < textContent.length) {
                                textNode.textContent += textContent.charAt(textIndex);
                                textIndex++;
                                messagesContainer.scrollTop = messagesContainer.scrollHeight;
                                setTimeout(typeText, 15); // typing speed
                            } else {
                                processNextNode(index + 1);
                            }
                        }
                        typeText();
                    } else if (child.nodeType === Node.ELEMENT_NODE) {
                        let newElement = document.createElement(child.tagName);
                        Array.from(child.attributes).forEach(attr => newElement.setAttribute(attr.name, attr.value));
                        targetNode.appendChild(newElement);
                        typeWriterHTML(child, newElement, () => {
                            processNextNode(index + 1);
                        });
                    } else {
                        processNextNode(index + 1);
                    }
                }
                processNextNode(0);
            }
            
            typeWriterHTML(tempDiv, msgDiv, () => {
                if (btnContainer) msgDiv.appendChild(btnContainer);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
                if (onComplete) onComplete();
            });
        } else {
            msgDiv.innerHTML = formattedText;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            if (onComplete) onComplete();
        }
    }

    // Fungsi untuk menampilkan menu kembali setelah bot menjawab
    function appendMenu() {
        const suggDiv = document.createElement('div');
        suggDiv.className = 'chatbot-suggestions';
        
        const menus = [
            { text: "Ringkasan RUP", msg: "Tampilkan Ringkasan Pagu RUP" },
            { text: "Realisasi LPSE", msg: "Tampilkan Realisasi LPSE dan E-Purchasing" },
            { text: "Monev Proyek", msg: "Bagaimana status Monev Proyek saat ini?" },
            { text: "Proyek Kritis", msg: "Tampilkan proyek yang kritis" }
        ];

        menus.forEach(menu => {
            const btn = document.createElement('button');
            btn.className = 'suggestion-btn';
            btn.setAttribute('data-msg', menu.msg);
            btn.textContent = menu.text;
            suggDiv.appendChild(btn);
        });

        messagesContainer.insertBefore(suggDiv, typingIndicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', function(e) {
        if(e.key === 'Enter') {
            sendMessage();
        }
    });

    // Handle suggestion clicks
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('suggestion-btn')) {
            const msg = e.target.getAttribute('data-msg');
            chatInput.value = msg;
            sendMessage();
            
            // Hide suggestions after clicked to clear space
            const suggestions = e.target.closest('.chatbot-suggestions');
            if (suggestions) {
                suggestions.style.display = 'none';
            }
        }
    });
});
</script>
