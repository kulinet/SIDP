<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title><?= $title ?? 'SIDP Mobile' ?></title>
    
    <!-- CSRF Token -->
    <meta name="<?= csrf_token() ?>" content="<?= csrf_hash() ?>">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/vendor/fonts/boxicons.css" />

    <!-- Core CSS (Sneat) -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/vendor/css/core.css" />
    <link rel="stylesheet" href="<?= base_url('assets') ?>/vendor/css/theme-default.css" />
    
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
            margin: 0;
            padding: 0;
            color: #1f2937;
            padding-bottom: 90px; /* Space for bottom nav */
        }
        
        /* Mobile Container */
        .mobile-container {
            max-width: 480px;
            margin: 0 auto;
            position: relative;
            min-height: 100vh;
            background-color: #ffffff;
            overflow-x: hidden;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
        }

        /* Bottom Navigation Bar */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100%;
            max-width: 480px;
            background: #ffffff;
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: 70px;
            padding-bottom: env(safe-area-inset-bottom, 0);
            z-index: 1000;
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.04);
            border-top: 1px solid #f8fafc;
        }

        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 600;
            flex: 1;
            height: 100%;
            transition: color 0.2s;
        }

        .bottom-nav-item i {
            font-size: 24px;
            margin-bottom: 4px;
        }

        .bottom-nav-item.active {
            color: #0ea5e9;
        }

        .bottom-nav-item:hover {
            color: #0ea5e9;
        }
        
        /* Floating Avatar Button in Center */
        .bottom-nav-item.center-btn {
            flex: 0 0 70px;
            position: relative;
            height: 100%;
        }
        
        .floating-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: #ffffff;
            box-shadow: 0 -5px 15px rgba(0,0,0,0.05);
            position: absolute;
            top: -25px; /* Float exactly half above the bar */
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            justify-content: center;
            align-items: center;
            /* Create a fake transparent cutout border effect against the page body */
            border: 5px solid #f8fafc; 
        }
        
        .ai-avatar-inner {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background-color: #ffffff;
            border: 2px solid #3a7bd5; /* The blue AJIP ring */
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .ai-avatar-inner img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Hide Default Chatbot Button in Mobile */
        .top-app-bar {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            background: #ffffff;
            color: #1e293b;
            padding-top: max(15px, env(safe-area-inset-top));
            border-bottom: 1px solid #f1f5f9;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .top-app-bar a.back-btn {
            color: #0ea5e9;
            font-size: 24px;
            text-decoration: none;
            margin-right: 15px;
        }
        .top-app-bar .page-title {
            font-size: 16px;
            font-weight: 600;
            margin: 0;
        }
        
        .white-bg-wrapper {
            background: #f8fafc;
            min-height: calc(100vh - 60px);
            padding: 15px 10px;
        }

        /* Universal Table Fixes for Mobile */
        .mobile-container .card {
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            margin: 5px;
            border: 1px solid #f1f5f9;
            padding: 0;
            overflow: hidden;
            background: #ffffff;
        }
        .mobile-container .card-body {
            padding: 15px;
        }
        .mobile-container .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        /* Hide Default Chatbot Button in Mobile */
        #openChat {
            display: none !important;
        }
        /* Adjust chatbot window for mobile */
        .chatbot-window {
            width: 100% !important;
            bottom: 85px !important;
            right: 0 !important;
            border-radius: 20px 20px 0 0 !important;
        }
    </style>
    <?= $this->renderSection('styles') ?>
</head>
<body>

    <div class="mobile-container">
        <?php 
            $currentPath = uri_string();
            $isHome = ($currentPath === '' || $currentPath === 'dashboard' || $currentPath === 'dashboard/index');
            
            if (!$isHome): 
        ?>
        <!-- Top App Bar for Subpages -->
        <div class="top-app-bar">
            <a href="<?= base_url('dashboard') ?>" class="back-btn"><i class='bx bx-arrow-back'></i></a>
            <h1 class="page-title"><?= esc($title ?? 'Aplikasi SIDP') ?></h1>
        </div>
        
        <!-- Background Wrapper for Subpages content -->
        <div class="white-bg-wrapper">
            <?= $this->renderSection('content') ?>
        </div>
        
        <?php else: ?>
        
        <!-- Main Content (Home Page uses its own structure) -->
        <?= $this->renderSection('content') ?>
        
        <?php endif; ?>
    </div>

    <!-- Bottom Navigation Bar -->
    <nav class="bottom-nav">
        <a href="<?= base_url('dashboard') ?>" class="bottom-nav-item <?= $isHome ? 'active' : '' ?>">
            <i class='bx bx-category-alt'></i>
            <span>Dashboard</span>
        </a>
        <a href="<?= base_url('dashboard/monev-proyek') ?>" class="bottom-nav-item <?= strpos($currentPath, 'monev') !== false ? 'active' : '' ?>">
            <i class='bx bx-briefcase'></i>
            <span>Monev</span>
        </a>
        
        <a href="javascript:void(0);" onclick="const cw = document.getElementById('chatbotWindow'); if(cw) { cw.classList.toggle('active'); if(cw.classList.contains('active')) { setTimeout(()=>document.getElementById('chatInput').focus(),100); } }" class="bottom-nav-item center-btn">
            <div class="floating-avatar">
                <div class="ai-avatar-inner">
                    <img src="<?= base_url('assets/img/bot-avatar.png') ?>" alt="AJIP">
                </div>
            </div>
        </a>
        
        <a href="<?= base_url('dashboard/layanan') ?>" class="bottom-nav-item <?= current_url(true)->getSegment(2) == 'layanan' ? 'active' : '' ?>">
            <i class='bx bx-grid-alt'></i>
            <span>Lainnya</span>
        </a>
        <a href="<?= base_url('auth/logout') ?>" class="bottom-nav-item text-danger">
            <i class='bx bx-log-out'></i>
            <span>Keluar</span>
        </a>
    </nav>

    <!-- Core JS -->
    <script src="<?= base_url('assets') ?>/vendor/libs/jquery/jquery.js"></script>
    <script src="<?= base_url('assets') ?>/vendor/libs/popper/popper.js"></script>
    <script src="<?= base_url('assets') ?>/vendor/js/bootstrap.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?= $this->renderSection('scripts') ?>
    <?= $this->include('components/chatbot') ?>
</body>
</html>
