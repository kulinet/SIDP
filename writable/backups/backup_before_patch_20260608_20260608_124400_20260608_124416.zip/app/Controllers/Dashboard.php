<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\MasterAnggaranModel;
use App\Models\RupPenyediaModel;
use App\Models\RupSwakelolaModel;
use App\Models\LpseTenderModel;
use App\Models\LpseNontenderModel;
use App\Models\EpurchasingModel;
use App\Models\LpsePencatatanNontenderModel;
use App\Models\LpsePencatatanSwakelolaModel;
use App\Models\MonevProyekModel;
use App\Models\MonevJadwalModel;
use App\Models\MonevHarianModel;
use App\Models\MonevDokumenModel;

class Dashboard extends BaseController
{
    use ResponseTrait;

    public function getFilterOptions($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userRole = session()->get('role');
        
        if ($type === 'epurchasing') {
            $model = new \App\Models\EpurchasingModel();
            $builder = $model->where('tahun', $currentYear);
            if ($userRole === 'ppk') {
                $builder->whereIn('rup_code', $this->_getPpkRupCodes());
            }
            $data = $builder->select('nama_satker')->distinct()->findAll();
            $opds = array_values(array_unique(array_filter(array_column($data, 'nama_satker'))));
            
            $userSatker = session()->get('nama_satker');
            if (($userRole === 'satker' || $userRole === 'opd') && $userSatker) {
                $opds = [$userSatker];
            } else {
                sort($opds);
            }
            return $this->response->setJSON($opds);
        }

        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        if ($userRole === 'ppk') {
            $builder->whereIn('kd_rup', $this->_getPpkRupCodes());
        }
        $data = $builder->findAll();
        
        $opds = array_values(array_unique(array_filter(array_column($data, 'nama_satker'))));
        $jenis = array_values(array_unique(array_filter(array_column($data, 'jenis_pengadaan'))));
        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
        $metodes = array_values(array_unique(array_filter(array_column($data, $metodeField))));

        $userSatker = session()->get('nama_satker');

        if (($userRole === 'satker' || $userRole === 'opd') && $userSatker) {
            $opds = [$userSatker];
        } else {
            sort($opds);
        }
        sort($jenis);
        sort($metodes);

        return $this->response->setJSON([
            'opds' => $opds,
            'jenis' => $jenis,
            'metodes' => $metodes
        ]);
    }

    private $apiPenyedia;
    private $apiSwakelola;
    private $apiMasterSatker;
    private $apiKegiatanMaster;
    
    // Specific for RUP OPD Monitoring
    private $apiRupAnggaranPenyedia;
    private $apiRupAnggaranSwakelola;

    // Data Pengadaan APIs
    private $apiEpurchasing;
    private $apiTender;
    private $apiTenderEkontrak;
    private $apiNonTender;
    private $apiPencatatanNonTender;
    private $apiPencatatanSwakelola;
    private $apiPencatatanSwakelolaRealisasi;
    private $apiNonTenderEkontrak;
    private $apiPengumumanTender;
    private $apiNonTenderSelesai;
    private $apiListPencatatanSwakelola;

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $baseUrl = env('AJIP_API_BASE_URL', 'https://ajip-api.cloud');
        $this->apiPenyedia = $baseUrl . '/api/data/perbandingan-rup-penyedia';
        $this->apiSwakelola = $baseUrl . '/api/data/perbandingan-swakelola';
        $this->apiMasterSatker = $baseUrl . '/api/data/master-satker';
        $this->apiKegiatanMaster = $baseUrl . '/api/data/kegiatan-master';
        $this->apiRupAnggaranPenyedia = $baseUrl . '/api/data/rup-paket-anggaran';
        $this->apiRupAnggaranSwakelola = $baseUrl . '/api/data/rup-paket-swakelola';
        $this->apiEpurchasing = $baseUrl . '/api/data/paket-epurchasing';
        $this->apiTender = $baseUrl . '/api/data/tender-selesai';
        $this->apiTenderEkontrak = $baseUrl . '/api/data/list-tender-kontrak';
        $this->apiNonTender = $baseUrl . '/api/data/nontender-selesai';
        $this->apiPencatatanNonTender = $baseUrl . '/api/data/pencatatan-nontender-realisasi';
        $this->apiPencatatanSwakelola = $baseUrl . '/api/data/list-pencatatan-swakelola';
        $this->apiPencatatanSwakelolaRealisasi = $baseUrl . '/api/data/encatatan-swakelola-realisasi';
        $this->apiNonTenderEkontrak = $baseUrl . '/api/data/list-nontender-ekontrak';
        $this->apiPengumumanTender = $baseUrl . '/api/data/pengumuman-tender';
        $this->apiNonTenderSelesai = $baseUrl . '/api/data/nontender-selesai';
        $this->apiListPencatatanSwakelola = $baseUrl . '/api/data/list-pencatatan-swakelola';
    }

    public function index()
    {
        $agent = $this->request->getUserAgent();
        if ($agent->isMobile() && $this->request->getGet('force_desktop') !== '1') {
            return view('dashboard/mobile_index', [
                'title'  => 'SIDP Mobile Portal',
                'user'   => session()->get(),
            ]);
        }

        // Redirect desktop users to statistik
        return redirect()->to(base_url('dashboard/statistik'));
    }

    public function statistik()
    {
        try {
            $chartModel = new \App\Models\DashboardChartModel();
            $charts = $chartModel->getWithMenu();
        } catch (\Throwable $e) {
            $charts = [];
        }

        return view('dashboard/statistik', [
            'title'  => 'Statistik Dasbor',
            'user'   => session()->get(),
            'charts' => $charts
        ]);
    }

    public function layanan()
    {
        return view('dashboard/mobile_layanan', [
            'title' => 'Semua Layanan SIDP',
            'user'  => session()->get()
        ]);
    }

    public function debugGap() {
        $db = \Config\Database::connect();
        $res = $db->query("SELECT SUM(realisasi) as sum_real, COUNT(*) as cnt FROM lpse_pencatatan_nontender WHERE realisasi > 0")->getRow();
        return $this->response->setJSON(['sum' => $res->sum_real, 'count' => $res->cnt]);
    }

    public function getDashboardSummary($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = trim(session()->get('kd_satker') ?? '');
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        
        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        if ($userRole === 'ppk') {
            $builder->whereIn('kd_rup', $this->_getPpkRupCodes());
        } elseif (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        $data = $builder->findAll();
        
        $matrix = [];
        $jenisList = [];
        $metodeList = [];
        $opdList = [];

        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';

        foreach ($data as $item) {
            $opd = $item['nama_satker'] ?: 'N/A';
            $jenis = ($type === 'penyedia') ? ($item['jenis_pengadaan'] ?: 'N/A') : 'Swakelola';
            $metode = $item[$metodeField] ?: 'N/A';

            if (!isset($matrix[$opd])) $matrix[$opd] = [];
            if (!isset($matrix[$opd][$jenis])) $matrix[$opd][$jenis] = [];
            if (!isset($matrix[$opd][$jenis][$metode])) $matrix[$opd][$jenis][$metode] = ['pagu' => 0, 'paket' => 0];
            
            $matrix[$opd][$jenis][$metode]['pagu'] += (float)$item['pagu'];
            $matrix[$opd][$jenis][$metode]['paket'] += 1;

            $opdList[$opd] = true;
            $jenisList[$jenis] = true;
            $metodeList[$metode] = true;
        }

        return $this->respond([
            'matrix' => $matrix,
            'opds' => array_keys($opdList),
            'jenis' => array_keys($jenisList),
            'metodes' => array_keys($metodeList),
            'type' => $type
        ]);
    }


    public function penyedia()
    {
        $data = [
            'title' => 'Data RUP Penyedia',
            'user'  => session()->get(),
            'type'  => 'penyedia'
        ];
        return view('dashboard/table', $data);
    }

    public function swakelola()
    {
        $data = [
            'title' => 'Data RUP Swakelola',
            'user'  => session()->get(),
            'type'  => 'swakelola'
        ];
        return view('dashboard/table', $data);
    }

    public function rupOpd()
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $cacheKey = "rup_opd_v15_full_db_{$currentYear}";
        
        if (!$summary = cache($cacheKey)) {
            $masterModel = new MasterAnggaranModel();
            $penyediaModel = new RupPenyediaModel();
            $swakelolaModel = new RupSwakelolaModel();

            $kegiatanMaster = $masterModel->where('tahun', $currentYear)->findAll();
            $rupPenyedia = $penyediaModel->where('tahun', $currentYear)->findAll();
            $rupSwakelola = $swakelolaModel->where('tahun', $currentYear)->findAll();
            
            foreach ($rupPenyedia as &$p) $p['_tipe'] = 'Penyedia';
            foreach ($rupSwakelola as &$s) $s['_tipe'] = 'Swakelola';
            $allRup = array_merge($rupPenyedia, $rupSwakelola);

            $satkerPrograms = [];
            $kegiatanStats = [];
            foreach ($kegiatanMaster as $k) {
                $kd = $k['kd_satker'] ?: '0';
                $progKey = trim($k['kd_program_str'] ?: 'UNKNOWN');
                if (!isset($satkerPrograms[$kd])) $satkerPrograms[$kd] = [];
                if ($progKey !== 'UNKNOWN') $satkerPrograms[$kd][] = $progKey;

                if (!isset($kegiatanStats[$kd])) {
                    $kegiatanStats[$kd] = ['total_pagu' => 0, 'program_list' => [], 'nama_satker' => $k['nama_satker']];
                }
                $kegiatanStats[$kd]['total_pagu'] += (float)$k['pagu_program'];
                if (!isset($kegiatanStats[$kd]['program_list'][$progKey])) {
                    $kegiatanStats[$kd]['program_list'][$progKey] = ['name' => $k['nama_program'], 'pagu' => 0];
                }
                $kegiatanStats[$kd]['program_list'][$progKey]['pagu'] += (float)$k['pagu_program'];
            }

            // --- PROCESS RUP DATA ---
            $rupStats = [];
            $seenRup = [];
            foreach ($allRup as $item) {
                $kd = $item['kd_satker'] ?: '0';
                $kdRup = $item['kd_rup'];
                $isNewRup = false;
                if ($kdRup) {
                    if (!isset($seenRup[$kdRup])) { $seenRup[$kdRup] = true; $isNewRup = true; }
                } else { $isNewRup = true; }

                $paguItem = (float)$item['pagu'];
                $mak = trim($item['mak'] ?? '');
                $progKey = 'UNKNOWN';

                if ($mak && isset($satkerPrograms[$kd])) {
                    $cleanMak = str_replace(['.', '-'], '', $mak);
                    foreach ($satkerPrograms[$kd] as $validCode) {
                        $cleanCode = str_replace(['.', '-'], '', $validCode);
                        if ($cleanCode === '') continue;
                        if (str_starts_with($cleanMak, $cleanCode) || str_contains($mak, $validCode)) {
                            $progKey = $validCode;
                            break;
                        }
                    }
                }

                if (!isset($rupStats[$kd])) {
                    $rupStats[$kd] = [
                        'pagu' => 0, 
                        'paket' => 0, 
                        'programs' => [], 
                        'package_list' => [],
                        'nama_satker_fallback' => $item['nama_satker']
                    ];
                }

                if ($isNewRup) {
                    $rupStats[$kd]['pagu'] += $paguItem;
                    $rupStats[$kd]['paket'] += 1;
                    
                    $rupStats[$kd]['programs'][$progKey] = ($rupStats[$kd]['programs'][$progKey] ?? 0) + $paguItem;
                    $rupStats[$kd]['package_list'][$progKey][] = [
                        'kd_rup' => $kdRup ?: '-',
                        'nama_paket' => $item['nama_paket'],
                        'pagu' => $paguItem,
                        'tipe' => $item['_tipe'],
                        'mak' => $mak
                    ];
                }
            }

            foreach ($satkerPrograms as $kd => &$codes) {
                usort($codes, function($a, $b) { return strlen($b) - strlen($a); });
            }

            // --- COLLECT ALL UNIQUE SATKERS FROM ALL SOURCES ---
            $allSatkerKeys = array_unique(array_merge(
                array_keys($kegiatanStats),
                array_keys($rupStats)
            ));

            $summary = [];
            foreach ($allSatkerKeys as $kd) {
                $ks = $kegiatanStats[$kd] ?? [
                    'total_pagu' => 0, 
                    'program_list' => [], 
                    'nama_satker' => ($rupStats[$kd]['nama_satker_fallback'] ?? 'Satker Tidak Terdaftar di Master')
                ];
                $rs = $rupStats[$kd] ?? ['pagu' => 0, 'paket' => 0, 'programs' => [], 'package_list' => []];
                
                $progDetails = [];
                // Process programs from Master
                foreach ($ks['program_list'] as $pk => $pData) {
                    $paguRup = $rs['programs'][$pk] ?? 0;
                    $progDetails[] = [
                        'code' => $pk,
                        'name' => $pData['name'],
                        'pagu_master' => $pData['pagu'],
                        'pagu_rup' => $paguRup,
                        'percent' => $pData['pagu'] > 0 ? round(($paguRup / $pData['pagu']) * 100, 2) : 0,
                        'packages' => $rs['package_list'][$pk] ?? []
                    ];
                }

                // Add "UNKNOWN" packages if any (those not matched to a Master program)
                if (!empty($rs['package_list']['UNKNOWN'])) {
                    $paguUnknown = $rs['programs']['UNKNOWN'] ?? 0;
                    $progDetails[] = [
                        'code' => 'UNKNOWN',
                        'name' => 'Paket Lainnya (Tidak Terpetakan ke Program)',
                        'pagu_master' => 0,
                        'pagu_rup' => $paguUnknown,
                        'percent' => 0,
                        'packages' => $rs['package_list']['UNKNOWN']
                    ];
                }

                $summary[] = [
                    'kd_satker' => $kd,
                    'kd_satker_str' => (string)$kd,
                    'nama_satker' => $ks['nama_satker'],
                    'rup_pagu' => $rs['pagu'],
                    'rup_paket' => $rs['paket'],
                    'master_pagu' => $ks['total_pagu'],
                    'percent' => $ks['total_pagu'] > 0 ? round(($rs['pagu'] / $ks['total_pagu']) * 100, 2) : 0,
                    'details' => $progDetails
                ];
            }

            usort($summary, function($a, $b) { return $a['percent'] <=> $b['percent']; });
            cache()->save($cacheKey, $summary, 3600);
        }

        $userRole = trim(strtolower(session()->get('role') ?? ''));
        $userSatker = trim(session()->get('kd_satker') ?? '');
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $summary = array_values(array_filter($summary, function($s) use ($userSatker) {
                return $s['kd_satker'] == $userSatker;
            }));
        }

        return view('dashboard/rup_opd', [
            'title' => 'Monitoring Keterumuman RUP',
            'user'  => session()->get(),
            'summary' => $summary
        ]);
    }

    public function getData($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');
        
        $model = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        
        $builder = $model->where('tahun', $currentYear);
        if ($userRole === 'satker' && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        $data = $builder->findAll();
        
        $metodeField = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
        $formatted = [];
        foreach ($data as $item) {
            $formatted[] = [
                'pagu' => (float)$item['pagu'],
                'kd_satker' => $item['kd_satker'],
                'nama_satker' => $item['nama_satker'],
                'jenis_pengadaan' => ($type === 'penyedia' ? $item['jenis_pengadaan'] : 'Swakelola'),
                $metodeField => $item[$metodeField],
                'volume_pekerjaan' => $item['volume_pekerjaan'],
                'urarian_pekerjaan' => $item['uraian_pekerjaan'],
                'tgl_awal_pemilihan' => ($type === 'penyedia' ? $item['tgl_awal_pemilihan'] : $item['tgl_awal_pelaksanaan']),
                'tgl_akhir_pemilihan' => ($type === 'penyedia' ? $item['tgl_akhir_pemilihan'] : $item['tgl_akhir_pelaksanaan']),
                'kd_rup' => $item['kd_rup'],
                'nama_paket' => $item['nama_paket'],
                'status_umumkan_rup' => $item['status_umumkan_rup']
            ];
        }

        return $this->respond($formatted);
    }

    public function getDatatables($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker  = session()->get('kd_satker');
        $userRole    = strtolower(session()->get('role') ?? '');
        
        $model   = ($type === 'swakelola') ? new RupSwakelolaModel() : new RupPenyediaModel();
        $builder = $model->where('tahun', $currentYear);

        // RBAC: paksa filter ke RUP jika role ppk, atau ke satker jika role satker/opd
        if ($userRole === 'ppk') {
            $builder->whereIn('kd_rup', $this->_getPpkRupCodes());
        } elseif (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        } else {
            // Terapkan filter OPD dari dropdown jika user admin/operator
            $opdFilter = $this->request->getGet('opd') ?? '';
            if ($opdFilter && $opdFilter !== 'all') {
                $builder->where('nama_satker', $opdFilter);
            }
        }

        $jenisFilter = $this->request->getGet('jenis') ?? '';
        if ($jenisFilter && $jenisFilter !== 'all') {
            $builder->where('jenis_pengadaan', $jenisFilter);
        }

        $metodeFilter = $this->request->getGet('metode') ?? '';
        if ($metodeFilter && $metodeFilter !== 'all') {
            if ($type === 'penyedia') {
                $builder->where('metode_pengadaan', $metodeFilter);
            } else {
                $builder->where('tipe_swakelola', $metodeFilter);
            }
        }

        $draw   = $this->request->getGet('draw');
        $start  = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        
        if ($search) {
            $builder->groupStart()->like('nama_paket', $search)->orLike('nama_satker', $search)->orLike('kd_rup', $search)->groupEnd();
        }

        $totalRecords    = $builder->countAllResults(false);
        $recordsFiltered = $totalRecords;
        
        if ($length != -1) $builder->limit($length, $start);
        $data = $builder->get()->getResultArray();

        $mapped = array_map(function($item) use ($type) {
            $item['urarian_pekerjaan'] = $item['uraian_pekerjaan'] ?? ($item['nama_paket'] ?? '-');
            if ($type === 'swakelola') {
                $item['tgl_awal_pemilihan']  = $item['tgl_awal_pelaksanaan']  ?? ($item['tgl_awal_pemilihan']  ?? '-');
                $item['tgl_akhir_pemilihan'] = $item['tgl_akhir_pelaksanaan'] ?? ($item['tgl_akhir_pemilihan'] ?? '-');
            } else {
                $item['tgl_awal_pemilihan']  = $item['tgl_awal_pemilihan']  ?? '-';
                $item['tgl_akhir_pemilihan'] = $item['tgl_akhir_pemilihan'] ?? '-';
            }
            return $item;
        }, $data);

        return $this->response->setJSON([
            'draw'            => intval($draw),
            'recordsTotal'    => $totalRecords,
            'recordsFiltered' => $recordsFiltered,
            'data'            => $mapped
        ]);
    }

    public function comparisons()
    {
        ini_set('memory_limit', '512M');
        $userSatker = trim(session()->get('kd_satker') ?? '');
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        
        $penyediaModel = new \App\Models\RupPenyediaModel();
        $swakelolaModel = new \App\Models\RupSwakelolaModel();

        // Ambil data langsung dari database untuk efisiensi
        $rawPenyedia = $penyediaModel->select('kd_satker, tahun as tahun_anggaran, pagu, metode_pengadaan, jenis_pengadaan')->findAll();
        $rawSwakelola = $swakelolaModel->select('kd_satker, tahun as tahun_anggaran, pagu, tipe_swakelola')->findAll();

        $aggregate = function($rawData, $type) use ($userSatker, $userRole) {
            $yearly = [];
            $dist1 = [];
            $dist2 = [];
            $field1 = ($type === 'penyedia') ? 'metode_pengadaan' : 'tipe_swakelola';
            $field2 = 'jenis_pengadaan';

            foreach ($rawData as $item) {
                // Strict Satker Filtering
                if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
                    $kd = trim($item['kd_satker'] ?? ($item['kode_satker'] ?? ($item['kd_organisasi'] ?? '')));
                    if ($kd != $userSatker) continue;
                }

                // Try all common year fields
                $yr = $item['tahun_anggaran'] ?? ($item['tahun_anggaran_dana'] ?? ($item['tahun'] ?? 'Unknown'));
                if ($yr === 'Unknown' || !$yr) continue;

                if (!isset($yearly[$yr])) $yearly[$yr] = ['pagu' => 0, 'paket' => 0];
                $yearly[$yr]['pagu'] += (float)($item['pagu'] ?? 0);
                $yearly[$yr]['paket'] += 1;

                $cat1 = $item[$field1] ?? 'Lainnya';
                $cat2 = $item[$field2] ?? 'Lainnya';
                if (!$cat1) $cat1 = 'Lainnya';
                if (!$cat2) $cat2 = 'Lainnya';

                if (!isset($dist1[$cat1][$yr])) $dist1[$cat1][$yr] = 0;
                $dist1[$cat1][$yr] += 1;

                if (!isset($dist2[$cat2][$yr])) $dist2[$cat2][$yr] = 0;
                $dist2[$cat2][$yr] += 1;
            }
            ksort($yearly);
            return ['yearly' => $yearly, 'dist1' => $dist1, 'dist2' => $dist2];
        };

        $data = [
            'title' => 'Dashboard Perbandingan Tahunan',
            'user'  => session()->get(),
            'statsPenyedia'  => $aggregate($rawPenyedia, 'penyedia'),
            'statsSwakelola' => $aggregate($rawSwakelola, 'swakelola')
        ];

        return view('dashboard/comparisons', $data);
    }

    public function getChartData($id)
    {
        $chartModel = new \App\Models\DashboardChartModel();
        $menuModel = new \App\Models\DynamicMenuModel();
        
        $chart = $chartModel->find($id);
        if (!$chart) return $this->failNotFound('Chart not found');
        
        $menu = $menuModel->find($chart['menu_id']);
        if (!$menu) return $this->failNotFound('Source menu not found');

        // Fetch API data
        $client = \Config\Services::curlrequest();
        try {
            $response = $client->get($menu['api_url']);
            $data = json_decode($response->getBody(), true);
            if (!is_array($data)) return $this->respond([]);

            $results = [];
            if ($chart['aggregation'] === 'count') {
                foreach ($data as $item) {
                    $label = $item[$chart['label_field']] ?? 'N/A';
                    $results[$label] = ($results[$label] ?? 0) + 1;
                }
            } else if ($chart['aggregation'] === 'sum') {
                foreach ($data as $item) {
                    $label = $item[$chart['label_field']] ?? 'N/A';
                    $val = floatval($item[$chart['value_field']] ?? 0);
                    $results[$label] = ($results[$label] ?? 0) + $val;
                }
            }

            // Format for Chart.js
            $output = [
                'labels' => array_keys($results),
                'values' => array_values($results)
            ];

            return $this->respond($output);
        } catch (\Exception $e) {
            return $this->fail($e->getMessage());
        }
    }

    public function export($type, $year)
    {
        $userSatker = session()->get('kd_satker');
        $userRole = trim(strtolower(session()->get('role') ?? ''));

        $model = ($type === 'swakelola') ? new \App\Models\RupSwakelolaModel() : new \App\Models\RupPenyediaModel();

        $builder = $model->where('tahun', $year);
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        $filtered = $builder->findAll();

        if (empty($filtered)) return redirect()->back()->with('error', 'Data tahun '.$year.' tidak ditemukan.');

        // Generate CSV
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="RUP_'.$type.'_'.$year.'.csv"');
        
        $output = fopen('php://output', 'w');
        // Add UTF-8 BOM for Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Use keys of the first item as headers
        fputcsv($output, array_keys(reset($filtered)));
        
        foreach ($filtered as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }

    public function exportRupOpd()
    {
        $currentYear = date('Y');
        $cacheKey = "rup_opd_v15_full_db_{$currentYear}"; // Must match rupOpd() cache key
        
        $summary = cache($cacheKey);
        if (!$summary) {
            $this->rupOpd(); // Regenerate cache if missing
            $summary = cache($cacheKey);
        }

        if (!$summary) return redirect()->back()->with('error', 'Gagal memproses data laporan.');

        // Apply strict satker filtering
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        $userSatker = trim(session()->get('kd_satker') ?? '');
        
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $summary = array_values(array_filter($summary, function($s) use ($userSatker) {
                return trim($s['kd_satker'] ?? '') == $userSatker;
            }));
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="Laporan_Keterumuman_RUP_OPD_'.$currentYear.'.csv"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM
        
        fputcsv($output, ['Nama OPD', 'Kode Satker', 'Pagu Master (Kegiatan)', 'Pagu Terumumkan (SIRUP)', 'Jumlah Paket', 'Persentase (%)']);
        
        foreach ($summary as $s) {
            fputcsv($output, [
                $s['nama_satker'],
                $s['kd_satker_str'],
                $s['master_pagu'],
                $s['rup_pagu'],
                $s['rup_paket'],
                $s['percent'] . '%'
            ]);
        }
        
        fclose($output);
        exit;
    }

    public function lpse($type)
    {
        $titles = [
            'tender' => 'Data Tender LPSE',
            'nontender' => 'Data Non Tender LPSE',
            'pencatatan-nontender' => 'Pencatatan Non Tender',
            'pencatatan-swakelola' => 'Pencatatan Swakelola'
        ];

        $db = \Config\Database::connect();
        $years = [];
        if ($type === 'tender') {
            $years = $db->table('lpse_tender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'nontender') {
            $years = $db->table('lpse_nontender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'pencatatan-nontender') {
            $years = $db->table('lpse_pencatatan_nontender')->select('tahun')->distinct()->get()->getResultArray();
        } elseif ($type === 'pencatatan-swakelola') {
            $years = $db->table('lpse_pencatatan_swakelola')->select('tahun')->distinct()->get()->getResultArray();
        }
        $availableYears = array_filter(array_column($years, 'tahun'));
        rsort($availableYears);
        if (empty($availableYears)) {
            $availableYears = [date('Y')];
        }

        return view('dashboard/table_lpse', [
            'title' => $titles[$type] ?? 'Data LPSE',
            'user'  => session()->get(),
            'type'  => $type,
            'availableYears' => $availableYears
        ]);
    }

    public function epurchasing()
    {
        return view('dashboard/dashboard_epurchasing', [
            'title' => 'Dashboard E-Purchasing',
            'user'  => session()->get(),
            'type'  => 'epurchasing'
        ]);
    }

    public function tableEpurchasing()
    {
        return view('dashboard/table_epurchasing', [
            'title' => 'Data Detail E-Purchasing',
            'user'  => session()->get(),
            'type'  => 'epurchasing'
        ]);
    }

    public function getEpurchasingDashboardData()
    {
        $cacheKey = "epurchasing_dashboard_v10";

        if (!$result = cache($cacheKey)) {
            $model = new \App\Models\EpurchasingModel();
            $rows = $model->findAll();
            
            if (!is_array($rows)) $rows = [];

            $history = []; // [year] => [realisasi, count]
            $topSatker = []; // [kd_satker] => [nama, realisasi, count]
            $topVendor = []; // [nama_penyedia] => [realisasi, count]
            $statusSummary = []; // [status] => [realisasi, count]
            $totalRealisasi = 0;
            $totalPackages = 0;
            $otherStatusPackagesCount = 0;

            $currentYearNum = (int)date('Y');
            $monthly = array_fill(1, 12, ['realisasi' => 0, 'count' => 0]); // [month] => [realisasi, count]

            foreach ($rows as $row) {
                $status = strtoupper(str_replace('_', ' ', (string)($row['status'] ?? '')));
                $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
                if (!in_array($status, $allowed)) continue;

                $yr = (int)$row['tahun'];
                if ($yr <= 0) continue;

                $real = (float)($row['total_harga'] ?? 0);
                
                // Status summary aggregation for current active year (includes all 5 statuses)
                if ($yr === $currentYearNum) {
                    if (!isset($statusSummary[$status])) {
                        $statusSummary[$status] = ['count' => 0, 'realisasi' => 0];
                    }
                    $statusSummary[$status]['count'] += 1;
                    $statusSummary[$status]['realisasi'] += $real;

                    if (!in_array($status, ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM'])) {
                        $otherStatusPackagesCount += 1;
                    }
                }

                // Filter out statuses other than ON PROCESS and PAYMENT OUTSIDE SYSTEM for all other dashboard metrics
                if (!in_array($status, ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM'])) {
                    continue;
                }

                // History aggregation (All years for chart - restricted statuses only)
                if (!isset($history[$yr])) $history[$yr] = ['realisasi' => 0, 'count' => 0];
                $history[$yr]['realisasi'] += $real;
                $history[$yr]['count'] += 1;

                // Current Year ONLY for Stats, Top Satker, and Top Vendor
                if ($yr === $currentYearNum) {
                    $totalRealisasi += $real;
                    $totalPackages += 1;

                    // Enrichment from local JSON
                    $kdVendor = trim($row['kode_penyedia'] ?? '');
                    $namaPenyedia = 'Penyedia ID: ' . $kdVendor;
                    
                    if ($kdVendor !== '') {
                        $vFile = WRITEPATH . 'inaproc/vendors/' . $kdVendor . '.json';
                        if (file_exists($vFile)) {
                            $vData = json_decode(file_get_contents($vFile), true);
                            $namaPenyedia = $vData['nama_penyedia'] ?? $namaPenyedia;
                        }
                    }

                    // Satker aggregation
                    $kdSatker = $row['kd_satker'] ?? 'UNKNOWN';
                    if (!isset($topSatker[$kdSatker])) {
                        $topSatker[$kdSatker] = [
                            'nama' => $row['nama_satker'] ?? 'Satker Tidak Diketahui',
                            'realisasi' => 0,
                            'count' => 0
                        ];
                    }
                    $topSatker[$kdSatker]['realisasi'] += $real;
                    $topSatker[$kdSatker]['count'] += 1;

                    // Vendor aggregation
                    if (!isset($topVendor[$namaPenyedia])) {
                        $topVendor[$namaPenyedia] = [
                            'realisasi' => 0,
                            'count' => 0,
                            'packages' => []
                        ];
                    }
                    $topVendor[$namaPenyedia]['realisasi'] += $real;
                    $topVendor[$namaPenyedia]['count'] += 1;
                    
                    $rawDate = $row['order_date'] ?? '';
                    $fmtDate = ($rawDate && strtotime($rawDate)) ? date('d-m-Y', strtotime($rawDate)) : '-';

                    $topVendor[$namaPenyedia]['packages'][] = [
                        'kd_paket' => $row['kd_paket'] ?? '-',
                        'rup_code' => $row['rup_code'] ?? '-',
                        'nama_paket' => $row['nama_paket'] ?? '-',
                        'nama_program' => $row['rup_desc'] ?? '-',
                        'nama_produk' => '-', 
                        'realisasi' => $real,
                        'tgl_order' => $fmtDate,
                        'satker' => $row['nama_satker'] ?? '-',
                        '_kdVendor' => $kdVendor,
                        '_productIds' => trim($row['product_id'] ?? '')
                    ];

                    // Monthly aggregation for current year
                    if ($rawDate) {
                        $month = (int)date('n', strtotime($rawDate));
                        if ($month >= 1 && $month <= 12) {
                            $monthly[$month]['realisasi'] += $real;
                            $monthly[$month]['count'] += 1;
                        }
                    }
                }
            }

            ksort($history);
            uasort($topSatker, function($a, $b) {
                return $b['realisasi'] <=> $a['realisasi'];
            });
            uasort($topVendor, function($a, $b) {
                return $b['count'] <=> $a['count'];
            });

            // Late Enrichment: Only fetch product names from JSON for the Top 10 Vendors to ensure high performance
            $topVendorSlice = array_slice($topVendor, 0, 10, true);
            foreach ($topVendorSlice as $vName => &$vData) {
                foreach ($vData['packages'] as &$pkg) {
                    $kdV = $pkg['_kdVendor'];
                    $pIds = $pkg['_productIds'];
                    if ($kdV !== '' && $pIds !== '') {
                        $actualProduct = $this->_getInaprocProductNames($kdV, $pIds, $pkg['nama_paket']);
                        if ($actualProduct && $actualProduct !== '-') {
                            $pkg['nama_produk'] = $actualProduct;
                        }
                    }
                    unset($pkg['_kdVendor'], $pkg['_productIds']); // Cleanup
                }
            }

            // Generate Leadership Narrative
            $currentYear = date('Y');
            $currStats = $history[$currentYear] ?? ['realisasi' => 0, 'count' => 0];
            $prevYear = (string)($currentYear - 1);
            $prevStats = $history[$prevYear] ?? ['realisasi' => 0, 'count' => 0];
            
            $growth = $prevStats['realisasi'] > 0 ? (($currStats['realisasi'] - $prevStats['realisasi']) / $prevStats['realisasi']) * 100 : 0;
            $topS = !empty($topSatker) ? reset($topSatker) : ['nama' => '-', 'realisasi' => 0];
            $topV = !empty($topVendor) ? reset($topVendor) : ['realisasi' => 0, 'count' => 0];
            
            reset($topVendor);
            $topVName = !empty($topVendor) ? key($topVendor) : '-';

            $narrative = "Analisis Tahun Berjalan (" . $currentYearNum . "): Total realisasi mencapai Rp " . number_format($totalRealisasi, 0, ',', '.') . " dari " . number_format($totalPackages, 0, ',', '.') . " paket. ";
            if ($topVName !== '-') {
                $narrative .= "Satker paling aktif saat ini adalah " . ($topS['nama'] ?? '-') . " dengan realisasi Rp " . number_format($topS['realisasi'] ?? 0, 0, ',', '.') . ". ";
                $narrative .= "Penyedia utama tahun ini adalah " . $topVName . " dengan perolehan " . ($topV['count'] ?? 0) . " paket.";
            }

            $result = [
                'summary' => [
                    'total_realisasi' => $totalRealisasi,
                    'total_packages' => $totalPackages,
                    'other_status_packages' => $otherStatusPackagesCount,
                    'years_count' => count($history),
                    'year_active' => $currentYearNum
                ],
                'history' => $history,
                'monthly' => $monthly,
                'top_satker' => array_slice($topSatker, 0, 10, true),
                'top_vendor' => $topVendorSlice,
                'status_summary' => $statusSummary,
                'report' => [
                    'narrative' => $narrative,
                    'growth' => round($growth, 2),
                    'top_performer' => $topS['nama'] ?? '-',
                    'top_vendor_name' => $topVName
                ]
            ];

            cache()->save($cacheKey, $result, 3600);
        }

        return $this->response->setJSON($result);
    }

    public function dashboardLpse()
    {
        return view('dashboard/dashboard_lpse', [
            'title' => 'Dashboard LPSE',
            'user'  => session()->get(),
        ]);
    }

    public function getDashboardLpseData()
    {
        $yearFilter = $this->request->getGet('year') ?? 'all';
        $cacheKey = 'dashboard_lpse_v3_' . $yearFilter;

        if (!$result = cache($cacheKey)) {
            $allYears  = [];
            $byYear    = []; // [type][year] => [pagu, count]
            $totalPagu = []; // [type] => pagu
            $totalRealisasi = []; // [type] => realisasi
            $byJenis   = []; // [jenis_pengadaan][year] => [pagu, count]
            $totalJenis = []; // [jenis_pengadaan] => pagu
            $seenPackages = []; // [label][year][id] => true
            
            $tenderModel = new \App\Models\LpseTenderModel();
            $nontenderModel = new \App\Models\LpseNontenderModel();
            $pctNontenderModel = new \App\Models\LpsePencatatanNontenderModel();
            $pctSwakelolaModel = new \App\Models\LpsePencatatanSwakelolaModel();

            // Ambil seluruh data dari DB lokal
            $sources = [
                'Tender' => $tenderModel->findAll(),
                'Non Tender' => $nontenderModel->findAll(),
                'Pencatatan Non Tender' => $pctNontenderModel->findAll(),
                'Pencatatan Swakelola' => $pctSwakelolaModel->findAll()
            ];

            foreach ($sources as $label => $rows) {
                if (!is_array($rows)) $rows = [];
                
                foreach ($rows as $row) {
                    $yr = (string)($row['tahun'] ?? date('Y'));
                    if ($yearFilter !== 'all' && $yr !== (string)$yearFilter) continue;
                    
                    $pkgId = trim((string)($row['kd_paket'] ?? ''));
                    $status = strtolower(trim((string)($row['status'] ?? '')));
                    
                    $pagu = (float)($row['pagu'] ?? 0);
                    
                    // Deteksi Realisasi
                    $realisasi = 0;
                    if ($label === 'Non Tender') {
                        $realisasi = (float)($row['nilai_kontrak'] ?? 0);
                        if ($realisasi <= 0) $realisasi = (float)($row['nilai_negosiasi'] ?? 0);
                    } else if ($label === 'Tender') {
                        $realisasi = (float)($row['nilai_kontrak'] ?? 0);
                    } else {
                        $realisasi = (float)($row['realisasi'] ?? 0);
                    }
                    
                    // Filter: Hanya tampilkan yang sudah selesai (sudah ada nilai kontrak / realisasi)
                    if ($realisasi <= 0) {
                        continue;
                    }
                    
                    $allYears[$yr] = true;
                    
                    $jenis = $row['jenis_pengadaan'] ?? ($row['kgr_nama'] ?? 'Lainnya');
                    if (trim($jenis) === '') $jenis = 'Lainnya';

                    // Deduplikasi Paket berdasarkan ID
                    $isDuplicate = false;
                    if ($pkgId !== '') {
                        if (isset($seenPackages[$label][$yr][$pkgId])) {
                            $isDuplicate = true;
                        } else {
                            $seenPackages[$label][$yr][$pkgId] = true;
                        }
                    }

                    if (!isset($byYear[$label][$yr])) $byYear[$label][$yr] = ['pagu' => 0, 'realisasi' => 0, 'count' => 0];
                    if (!isset($byJenis[$jenis][$yr])) $byJenis[$jenis][$yr] = ['pagu' => 0, 'realisasi' => 0, 'count' => 0];
                    if (!isset($totalPagu[$label])) $totalPagu[$label] = 0;
                    if (!isset($totalRealisasi[$label])) $totalRealisasi[$label] = 0;
                    if (!isset($totalJenis[$jenis])) $totalJenis[$jenis] = ['pagu' => 0, 'realisasi' => 0];

                    if ($isDuplicate) {
                        if ($label === 'Pencatatan Non Tender') {
                            $byYear[$label][$yr]['realisasi'] += $realisasi;
                            $totalRealisasi[$label] += $realisasi;
                            $byJenis[$jenis][$yr]['realisasi'] += $realisasi;
                            $totalJenis[$jenis]['realisasi'] += $realisasi;
                        }
                        continue;
                    }
                    
                    $byYear[$label][$yr]['pagu'] += $pagu;
                    $byYear[$label][$yr]['count'] += 1;
                    $totalPagu[$label] += $pagu;
                    
                    $byYear[$label][$yr]['realisasi'] += $realisasi;
                    $totalRealisasi[$label] += $realisasi;
                    
                    $byJenis[$jenis][$yr]['pagu'] += $pagu;
                    $byJenis[$jenis][$yr]['count'] += 1;
                    $totalJenis[$jenis]['pagu'] += $pagu;
                    
                    $byJenis[$jenis][$yr]['realisasi'] += $realisasi;
                    $totalJenis[$jenis]['realisasi'] += $realisasi;
                }
            }
            
            // Urutkan jenis pengadaan berdasarkan total pagu menurun
            uasort($totalJenis, function($a, $b) {
                return $b['pagu'] <=> $a['pagu'];
            });

            ksort($allYears);
            $years = array_keys($allYears);

            $result = [
                'years'           => $years,
                'labels'          => array_keys($sources),
                'by_year'         => $byYear,
                'total_pagu'      => $totalPagu,
                'total_realisasi' => $totalRealisasi,
                'jenis_labels'    => array_keys($totalJenis),
                'by_jenis'        => $byJenis,
                'total_jenis'     => $totalJenis,
            ];

            cache()->save($cacheKey, $result, 1800);
        }

        return $this->response->setJSON($result);
    }

    public function getEpurchasingDatatables()
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');

        $cacheKey = "epurchasing_data_v100_{$currentYear}";

        if (!$allData = cache($cacheKey)) {
            $model = new \App\Models\EpurchasingModel();
            
            if ($currentYear !== 'all') {
                $raw = $model->where('tahun', $currentYear)->findAll();
            } else {
                $raw = $model->findAll();
            }

            if (!is_array($raw) || empty($raw)) {
                $allData = [];
            } else {
                $allData = [];
                foreach ($raw as $item) {
                    // Restricted Statuses for E-Purchasing (Flexible Check)
                    $status = strtoupper(str_replace('_', ' ', (string)($item['status'] ?? '')));
                    $allowed = ['ON PROCESS', 'PAYMENT OUTSIDE SYSTEM', 'WAITING PPK REVIEW', 'ON NEGOTIATION', 'WAITING SELLER CONFIRMATION'];
                    if (!in_array($status, $allowed)) continue;

                    $allData[] = [
                        'no_referensi'   => $item['kd_paket'] ?? '-',
                        'nama_paket'     => $item['nama_paket'] ?? '-',
                        'nama_program'   => $item['rup_desc'] ?? '-',
                        'nama_produk'    => $item['rup_desc'] ?? '-', // Default, enriched later
                        'nama_penyedia'  => $item['nama_penyedia'] ?? null, // Use stored DB value (null means "enrich later")
                        'kode_penyedia'  => trim($item['kode_penyedia'] ?? ''),
                        'product_id'     => trim($item['product_id'] ?? ''),
                        'nama_satker'    => $item['nama_satker'] ?? '-',
                        'kd_satker'      => $item['kd_satker'] ?? '',
                        'pagu'           => (float)($item['total_harga'] ?? 0),
                        'sumber_dana'    => $item['sumber_dana'] ?? '-',
                        'jumlah'         => (int)($item['total_qty'] ?? 0),
                        'satuan'         => 'Unit',
                        'tanggal'        => $item['order_date'] ?? '-',
                        'fiscal_year'    => $item['tahun'] ?? '-',
                        'status'         => $status,
                        'shipment_status'=> $item['shipment_status'] ?? '-',
                        'rup_code'       => $item['rup_code'] ?? '-',
                    ];

                }

                if (!empty($allData)) {
                    cache()->save($cacheKey, $allData, 3600);
                }
            }
        }

        // RBAC filter
        if ($userRole === 'satker' && $userSatker) {
            $allData = array_values(array_filter($allData, function($item) use ($userSatker) {
                return ($item['kd_satker'] ?? '') == $userSatker;
            }));
        }

                // Jika user role satker, paksa filter ke satker miliknya
        if ($userRole === 'satker' && $userSatker) {
            $satkerFilter = $userSatker;
        }
        $satkerFilter = $this->request->getGet('satker_filter') ?? '';
        if ($satkerFilter) {
            $allData = array_values(array_filter($allData, function($item) use ($satkerFilter) {
                return ($item['nama_satker'] ?? '') == $satkerFilter;
            }));
        }

        // DataTables parameters
        $draw = $this->request->getGet('draw');
        $start = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        $statusFilter = $this->request->getGet('status_filter') ?? '';
        $order = $this->request->getGet('order');

        $totalRecords = count($allData);

        // Filter by status
        if ($statusFilter) {
            $allData = array_values(array_filter($allData, function($item) use ($statusFilter) {
                return strcasecmp($item['status'] ?? '', $statusFilter) === 0;
            }));
        }

        // Search
        if ($search) {
            $allData = array_values(array_filter($allData, function($item) use ($search) {
                return stripos($item['nama_paket'] ?? '', $search) !== false ||
                       stripos($item['nama_satker'] ?? '', $search) !== false ||
                       stripos($item['no_referensi'] ?? '', $search) !== false ||
                       stripos($item['kode_penyedia'] ?? '', $search) !== false ||
                       stripos($item['product_id'] ?? '', $search) !== false;
            }));
        }

        $filteredRecords = count($allData);

        // Sorting
        if (!empty($order)) {
            $colIdx = $order[0]['column'];
            $dir = $order[0]['dir'];
            $cols = $this->request->getGet('columns');
            $colName = $cols[$colIdx]['data'] ?? null;

            if ($colName) {
                usort($allData, function($a, $b) use ($colName, $dir) {
                    $valA = $a[$colName] ?? '';
                    $valB = $b[$colName] ?? '';
                    if (is_numeric($valA) && is_numeric($valB)) return ($dir === 'asc') ? ($valA <=> $valB) : ($valB <=> $valA);
                    return ($dir === 'asc') ? strnatcasecmp((string)$valA, (string)$valB) : strnatcasecmp((string)$valB, (string)$valA);
                });
            }
        }

        // Pagination
        $data = ($length == -1) ? $allData : array_slice($allData, $start, $length);

        // ENRICH visible rows only (Fast)
        // Priority: 1) DB stored nama_penyedia  2) Local JSON cache  3) Inaproc API (live)
        foreach ($data as &$item) {
            // 1. Use stored value from DB if available
            if (!empty($item['nama_penyedia'])) {
                // Already set from DB — also enrich product name if needed
                $kdVendor   = $item['kode_penyedia'];
                $prodIdsStr = $item['product_id'];
                if ($kdVendor !== '' && $prodIdsStr !== '') {
                    $item['nama_produk'] = $this->_getInaprocProductNames($kdVendor, $prodIdsStr, $item['nama_paket']);
                }
                continue;
            }

            // 2. Fallback: lookup from JSON cache / Inaproc API
            $kdVendor   = $item['kode_penyedia'];
            $prodIdsStr = $item['product_id'];
            if ($kdVendor !== '') {
                $item['nama_penyedia'] = $this->_getInaprocVendorName($kdVendor);
                if ($prodIdsStr !== '') {
                    $item['nama_produk'] = $this->_getInaprocProductNames($kdVendor, $prodIdsStr, $item['nama_paket']);
                }
            }
        }


        // Final result with unique statuses metadata
        $uniqueStatuses = array_values(array_unique(array_column($allData, 'status')));

        return $this->response->setJSON([
            'draw' => intval($draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredRecords,
            'unique_statuses' => $uniqueStatuses,
            'data' => array_values($data)
        ]);
    }

    public function getLpseDatatables($type)
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $userSatker = session()->get('kd_satker');
        $userRole = session()->get('role');
        
        $models = [
            'tender' => new \App\Models\LpseTenderModel(),
            'nontender' => new \App\Models\LpseNontenderModel(),
            'pencatatan-nontender' => new \App\Models\LpsePencatatanNontenderModel(),
            'pencatatan-swakelola' => new \App\Models\LpsePencatatanSwakelolaModel()
        ];

        $model = $models[$type] ?? null;
        if (!$model) return $this->response->setJSON(['data' => []]);

        // Build base query — only filter by year if not 'all'
        $builder = $model->builder();
        if ($currentYear && $currentYear !== 'all') {
            $builder->where('tahun', (int)$currentYear);
        }

        // RBAC: satker/opd filter
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $builder->where('kd_satker', $userSatker);
        }

        // Apply status filter from frontend
        $statusFilter = $this->request->getGet('status') ?? '';
        if ($statusFilter && $statusFilter !== 'all') {
            $builder->where('status', $statusFilter);
        }

        // Apply opd filter from frontend (for swakelola mostly)
        $opdFilter = $this->request->getGet('opd') ?? '';
        if ($opdFilter && $opdFilter !== 'all') {
            $builder->where('nama_satker', $opdFilter);
        }

        // Apply jenis_pengadaan filter (for tender/nontender)
        $jenisPengadaanFilter = $this->request->getGet('jenis_pengadaan') ?? '';
        if ($jenisPengadaanFilter && $jenisPengadaanFilter !== 'all') {
            $builder->where('jenis_pengadaan', $jenisPengadaanFilter);
        }

        // Apply jenis filter (for pencatatan types)
        $jenisFilter = $this->request->getGet('jenis') ?? '';
        if ($jenisFilter && $jenisFilter !== 'all') {
            if ($type === 'pencatatan-nontender') {
                $builder->where('jenis_realisasi', $jenisFilter);
            } elseif ($type === 'pencatatan-swakelola') {
                $builder->where('jenis_realisasi', $jenisFilter);
            }
        }

        $draw   = $this->request->getGet('draw');
        $start  = (int)($this->request->getGet('start') ?? 0);
        $length = (int)($this->request->getGet('length') ?? 10);
        $search = $this->request->getGet('search')['value'] ?? '';
        
        if ($search) {
            $builder->groupStart()
                    ->like('nama_paket', $search)
                    ->orLike('nama_satker', $search)
                    ->orLike('kd_rup', $search)
                    ->orLike('kd_paket', $search)
                    ->orLike('tahun', $search);
            
            if ($type === 'pencatatan-swakelola') {
                $builder->orLike('nama_pelaksana', $search)
                        ->orLike('jenis_realisasi', $search)
                        ->orLike('status', $search);
            } elseif ($type === 'pencatatan-nontender') {
                $builder->orLike('nama_penyedia', $search)
                        ->orLike('jenis_realisasi', $search)
                        ->orLike('status', $search);
            } elseif ($type === 'tender' || $type === 'nontender') {
                $builder->orLike('nama_penyedia', $search)
                        ->orLike('jenis_pengadaan', $search)
                        ->orLike('status', $search);
            }
            $builder->orLike('pagu', $search);
            $builder->groupEnd();
        }

        // Total records (unfiltered except year + satker)
        $totalBuilder = $model->builder();
        if ($currentYear && $currentYear !== 'all') {
            $totalBuilder->where('tahun', (int)$currentYear);
        }
        if (in_array($userRole, ['satker', 'opd']) && $userSatker) {
            $totalBuilder->where('kd_satker', $userSatker);
        }
        $totalRecords = $totalBuilder->countAllResults(false);

        $recordsFiltered = $builder->countAllResults(false);
        
        if ($length != -1) $builder->limit($length, $start);
        $data = $builder->get()->getResultArray();

        return $this->response->setJSON([
            'draw' => intval($draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data
        ]);
    }

    public function clearCache()
    {
        cache()->clean();
        return redirect()->back()->with('success', 'Berhasil membersihkan cache. Seluruh data akan ditarik ulang dari API.');
    }

    private function _getInaprocVendorName($kode)
    {
        $dir = WRITEPATH . 'inaproc/vendors/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file = $dir . $kode . '.json';

        if (file_exists($file)) {
            $saved = json_decode(file_get_contents($file), true);

            // Return cached name (even if null/not-found)
            if (array_key_exists('nama_penyedia', $saved)) {
                // If marked as not-found, only retry after 24 hours
                if (!empty($saved['_not_found'])) {
                    $lastAttempt = strtotime($saved['_last_attempt'] ?? '2000-01-01');
                    if ((time() - $lastAttempt) < 86400) {
                        // Still within 24h cooldown — return full kode as fallback
                        return $kode;
                    }
                    // Retry after 24h — fall through to API call below
                } else {
                    return $saved['nama_penyedia'] ?? '-';
                }
            }
        }

        $client = \Config\Services::curlrequest();
        $token = getenv('INAPROC_BEARER_TOKEN') ?: 'inprc73221b186ad14d568b02f22b214c9574';
        try {
            $url = "https://data.inaproc.id/api/legacy/ekatalog/penyedia-detail?kode_penyedia={$kode}";
            $res = $client->get($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                ],
                'timeout' => 10
            ]);
            $body = json_decode($res->getBody(), true);
            // Legacy endpoint returns direct array [{...}]; v1 returns {"data":[{...}]}
            $vendor = $body[0] ?? ($body['data'][0] ?? null);
            if (is_array($vendor) && isset($vendor['nama_penyedia'])) {
                $name = $vendor['nama_penyedia'];
                file_put_contents($file, json_encode(['nama_penyedia' => $name, '_synced_at' => date('Y-m-d H:i:s')]));
                return $name;
            }
        } catch (\Exception $e) {}

        // API call failed or returned no data — save a not-found marker
        // This prevents hammering the API on every page load
        file_put_contents($file, json_encode([
            'nama_penyedia' => null,
            '_not_found'    => true,
            '_last_attempt' => date('Y-m-d H:i:s'),
        ]));
        return $kode;
    }

    private function _getInaprocProductNames($kodePenyedia, $prodIdsStr, $namaPaket = '')
    {
        $dir = WRITEPATH . 'inaproc/products/';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $file = $dir . $kodePenyedia . '.json';

        $prodMap = [];
        if (file_exists($file)) {
            $prodMap = json_decode(file_get_contents($file), true) ?: [];
        }

        $searchIds = array_map('trim', explode(',', $prodIdsStr));
        $missingIds = [];
        foreach ($searchIds as $sid) {
            if (!isset($prodMap[$sid])) $missingIds[] = $sid;
        }

        // If we have missing IDs and the file is old or non-existent, fetch from API
        if (!empty($missingIds)) {
            $client = \Config\Services::curlrequest();
            $token = getenv('INAPROC_BEARER_TOKEN') ?: 'inprc73221b186ad14d568b02f22b214c9574';
            try {
                $url = "https://data.inaproc.id/api/v1/ekatalog/list-produk-penyedia?kode_penyedia={$kodePenyedia}&limit=1000";
                $res = $client->get($url, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token,
                        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    ],
                    'timeout' => 15
                ]);
                $body = json_decode($res->getBody(), true);
                if (isset($body['data']) && is_array($body['data'])) {
                    foreach ($body['data'] as $p) {
                        $pid = $p['kd_produk'] ?? null;
                        $pname = $p['nama_produk'] ?? null;
                        if ($pid) $prodMap[$pid] = $pname;
                    }
                    file_put_contents($file, json_encode($prodMap, JSON_UNESCAPED_UNICODE));
                }
            } catch (\Exception $e) {}
        }

        $found = [];
        $hasNewFallback = false;
        foreach ($searchIds as $sid) {
            if (isset($prodMap[$sid])) {
                $found[] = $prodMap[$sid];
            } else {
                $fallback = $sid;
                if (!empty($namaPaket)) {
                    if (preg_match('/\(([^)]+)\)/', $namaPaket, $matches)) {
                        $fallback = trim($matches[1]);
                    } else {
                        $fallback = $namaPaket;
                    }
                }
                $prodMap[$sid] = $fallback;
                $hasNewFallback = true;
                $found[] = $fallback;
            }
        }

        if ($hasNewFallback) {
            file_put_contents($file, json_encode($prodMap, JSON_UNESCAPED_UNICODE));
        }

        return count($found) > 0 ? implode(', ', $found) : '-';
    }

    private function _parseDate($dateStr, $defaultYear)
    {
        if (empty($dateStr) || $dateStr === '-') return null;
        
        // If format is like YYYY-MM-DD
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStr)) {
            return strtotime($dateStr);
        }
        
        // Handle Indonesian month names (e.g. "Mei 2026" or "Mei")
        $months = [
            'januari' => 1, 'februari' => 2, 'maret' => 3, 'april' => 4,
            'mei' => 5, 'juni' => 6, 'juli' => 7, 'agustus' => 8,
            'september' => 9, 'oktober' => 10, 'november' => 11, 'desember' => 12,
            'jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4,
            'jun' => 6, 'jul' => 7, 'agu' => 8, 'sep' => 9, 'okt' => 10, 'nov' => 11, 'des' => 12
        ];
        
        $clean = strtolower(trim($dateStr));
        
        // Extract month and year
        $foundMonth = null;
        foreach ($months as $name => $num) {
            if (str_contains($clean, $name)) {
                $foundMonth = $num;
                break;
            }
        }
        
        $year = $defaultYear;
        if (preg_match('/\b(20\d{2})\b/', $clean, $matches)) {
            $year = $matches[1];
        }
        
        if ($foundMonth) {
            return strtotime("{$year}-{$foundMonth}-01");
        }
        
        $parsed = strtotime($dateStr);
        return $parsed !== false ? $parsed : null;
    }

    public function monevProyek()
    {
        $currentYear = $this->request->getGet('year') ?? date('Y');
        $activeProyekId = $this->request->getGet('proyek_id');
        $userId = session()->get('id');
        $userRole = trim(strtolower(session()->get('role') ?? ''));

        $proyekModel = new MonevProyekModel();
        
        // PPK only sees their own projects, other roles see all projects for monitoring
        if ($userRole === 'ppk') {
            $proyekList = $proyekModel->where('user_id', $userId)->findAll();
        } else {
            $proyekList = $proyekModel->findAll();
        }

        // Get active project
        $activeProyek = null;
        if (!empty($proyekList)) {
            if ($activeProyekId) {
                foreach ($proyekList as $p) {
                    if ($p['id'] == $activeProyekId) {
                        $activeProyek = $p;
                        break;
                    }
                }
            }
            if (!$activeProyek) {
                $activeProyek = $proyekList[0];
            }
        }

        // Load details if active project exists
        $jadwalItems = [];
        $harianItems = [];
        $dokumenItems = [];
        $scurve = ['labels' => [], 'plan' => [], 'actual' => [], 'deviasi' => []];
        $deviasiKumulatif = 0;
        $deviasiMingguan  = 0;
        $statusIndikator  = 'Hijau';
        $warningKpa       = false;

        if ($activeProyek) {
            $jadwalModel = new MonevJadwalModel();
            $jadwalItems = $jadwalModel->where('proyek_id', $activeProyek['id'])->findAll();

            $harianModel = new MonevHarianModel();
            // Join with jadwal to get item name
            $harianItems = $harianModel->select('monev_harian.*, monev_jadwal.item_pekerjaan, monev_jadwal.bobot')
                                      ->join('monev_jadwal', 'monev_jadwal.id = monev_harian.item_id')
                                      ->where('monev_harian.proyek_id', $activeProyek['id'])
                                      ->orderBy('monev_harian.tanggal', 'DESC')
                                      ->findAll();

            $dokumenModel = new MonevDokumenModel();
            $dokumenItems = $dokumenModel->where('proyek_id', $activeProyek['id'])->findAll();

            // Calculate S-curve
            $scurve = $this->calculateMonevScurve($activeProyek, $jadwalItems, $harianItems);
            
            // 1. Calculate Deviasi Kumulatif Terakhir (untuk tampilan kartu)
            $deviasiKumulatif = 0;
            if (!empty($scurve['deviasi'])) {
                $lastDev = null;
                foreach (array_reverse($scurve['deviasi']) as $d) {
                    if ($d !== null) {
                        $lastDev = $d;
                        break;
                    }
                }
                $deviasiKumulatif = $lastDev ?? 0;
            }

            // 2. Calculate Deviasi Mingguan Terakhir (untuk deteksi dini status indikator)
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $act) {
                    if ($act !== null) {
                        $lastWeekIndex = $idx;
                    }
                }
                
                if ($lastWeekIndex >= 0) {
                    // Aktual minggu ini
                    $currentActual = $scurve['actual'][$lastWeekIndex];
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    // Rencana minggu ini
                    $currentPlan = $scurve['plan'][$lastWeekIndex];
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }

            // Indikator Status & Alert Warning didasarkan pada Deviasi MINGGUAN (Deteksi dini)
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah';
                $warningKpa = true;
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning';
            } else {
                $statusIndikator = 'Hijau';
            }

            // Also check if contract expired but not completed yet
            $tglSelesai = strtotime($activeProyek['tgl_selesai']);
            if ($tglSelesai < time() && $activeProyek['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah';
                    $warningKpa = true;
                } elseif ($statusIndikator !== 'Merah') {
                    $statusIndikator = 'Kuning';
                }
            }
        }

        // Get claimed SPSE packages for pre-filling
        $mappingModel = new \App\Models\PpkRupMappingModel();
        $mappings = $mappingModel->where('user_id', $userId)->findAll();
        
        $rupPackages = [];
        if (!empty($mappings)) {
            $db = \Config\Database::connect();
            foreach ($mappings as $m) {
                $kdPaket = $m['kd_paket'];
                $type = $m['type']; // 'Tender', 'Non-Tender', 'E-Purchasing'
                
                $pkg = null;
                if ($type === 'Tender') {
                    $pkg = $db->table('lpse_tender')->where('kd_paket', $kdPaket)->get()->getRowArray();
                    if ($pkg) {
                        $rupPackages[] = [
                            'kd_paket'      => $pkg['kd_paket'],
                            'kd_rup'        => $pkg['kd_rup'],
                            'nama_paket'    => $pkg['nama_paket'],
                            'pagu'          => $pkg['pagu'],
                            'nilai_kontrak' => $pkg['nilai_kontrak'],
                            'nama_penyedia' => $pkg['nama_penyedia'],
                            'no_kontrak'    => $pkg['no_kontrak'],
                            'type'          => 'Tender'
                        ];
                    }
                } elseif ($type === 'Non-Tender') {
                    $pkg = $db->table('lpse_nontender')->where('kd_paket', $kdPaket)->get()->getRowArray();
                    if ($pkg) {
                        $rupPackages[] = [
                            'kd_paket'      => $pkg['kd_paket'],
                            'kd_rup'        => $pkg['kd_rup'],
                            'nama_paket'    => $pkg['nama_paket'],
                            'pagu'          => $pkg['pagu'],
                            'nilai_kontrak' => $pkg['nilai_kontrak'],
                            'nama_penyedia' => $pkg['nama_penyedia'],
                            'no_kontrak'    => $pkg['no_kontrak'],
                            'type'          => 'Non-Tender'
                        ];
                    }
                } elseif ($type === 'E-Purchasing') {
                    $pkg = $db->table('epurchasing')->where('kd_paket', $kdPaket)->get()->getRowArray();
                    if ($pkg) {
                        $rupPackages[] = [
                            'kd_paket'      => $pkg['kd_paket'],
                            'kd_rup'        => $pkg['rup_code'],
                            'nama_paket'    => $pkg['nama_paket'],
                            'pagu'          => $pkg['pagu'],
                            'nilai_kontrak' => $pkg['total_harga'],
                            'nama_penyedia' => $pkg['nama_penyedia'],
                            'no_kontrak'    => $pkg['kd_paket'], // fallback
                            'type'          => 'E-Purchasing'
                        ];
                    }
                }
            }
        }

        return view('dashboard/monev_proyek', [
            'title'           => 'Monitoring & Evaluasi Proyek',
            'user'            => session()->get(),
            'selectedYear'    => $currentYear,
            'proyekList'      => $proyekList,
            'activeProyek'    => $activeProyek,
            'jadwalItems'     => $jadwalItems,
            'harianItems'     => $harianItems,
            'dokumenItems'    => $dokumenItems,
            'scurve'          => $scurve,
            'deviasiTerakhir' => $deviasiKumulatif, // Untuk Ringkasan Bobot Realisasi
            'deviasiMingguan' => $deviasiMingguan,  // Untuk Indikator Status & Early Warning
            'statusIndikator' => $statusIndikator,
            'warningKpa'      => $warningKpa,
            'rupPackages'     => $rupPackages
        ]);
    }

    public function monevSummary()
    {
        $proyekModel = new MonevProyekModel();
        $jadwalModel = new MonevJadwalModel();
        $harianModel = new MonevHarianModel();

        $proyekList = $proyekModel->findAll();
        
        $summaryData = [];
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $this->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            $realisasiTerakhir = 0;
            if (!empty($scurve['actual'])) {
                foreach (array_reverse($scurve['actual']) as $val) {
                    if ($val !== null) { $realisasiTerakhir = $val; break; }
                }
            }
            
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $val) {
                    if ($val !== null) { $lastWeekIndex = $idx; }
                }
                
                if ($lastWeekIndex >= 0) {
                    $currentActual = $scurve['actual'][$lastWeekIndex] ?? 0;
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    $currentPlan = $scurve['plan'][$lastWeekIndex] ?? 0;
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }
            
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah';
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning';
            } else {
                $statusIndikator = 'Hijau';
            }
            
            $tglSelesai = strtotime($p['tgl_selesai']);
            if ($tglSelesai < time() && $p['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah';
                } elseif ($statusIndikator !== 'Merah') {
                    $statusIndikator = 'Kuning';
                }
            }
            
            $p['realisasi'] = $realisasiTerakhir;
            $p['deviasi_kumulatif'] = $deviasiTerakhir;
            $p['deviasi_mingguan'] = $deviasiMingguan;
            $p['status_indikator'] = $statusIndikator;
            
            $summaryData[] = $p;
        }

        return view('dashboard/monev_summary', [
            'title' => 'Summary Progres Proyek',
            'user' => session()->get(),
            'summaryData' => $summaryData
        ]);
    }

    public function exportMonevSummary()
    {
        $proyekModel = new MonevProyekModel();
        $jadwalModel = new MonevJadwalModel();
        $harianModel = new MonevHarianModel();

        $proyekList = $proyekModel->findAll();
        
        $summaryData = [];
        foreach ($proyekList as $p) {
            $jadwalItems = $jadwalModel->where('proyek_id', $p['id'])->findAll();
            $harianItems = $harianModel->where('proyek_id', $p['id'])->orderBy('tanggal', 'ASC')->findAll();
            
            $scurve = $this->calculateMonevScurve($p, $jadwalItems, $harianItems);
            
            $deviasiTerakhir = 0;
            if (!empty($scurve['deviasi'])) {
                foreach (array_reverse($scurve['deviasi']) as $val) {
                    if ($val !== null) { $deviasiTerakhir = $val; break; }
                }
            }
            
            $realisasiTerakhir = 0;
            if (!empty($scurve['actual'])) {
                foreach (array_reverse($scurve['actual']) as $val) {
                    if ($val !== null) { $realisasiTerakhir = $val; break; }
                }
            }
            
            $deviasiMingguan = 0;
            if (!empty($scurve['actual']) && !empty($scurve['plan'])) {
                $lastWeekIndex = -1;
                foreach ($scurve['actual'] as $idx => $val) {
                    if ($val !== null) { $lastWeekIndex = $idx; }
                }
                
                if ($lastWeekIndex >= 0) {
                    $currentActual = $scurve['actual'][$lastWeekIndex] ?? 0;
                    $prevActual = $lastWeekIndex > 0 ? ($scurve['actual'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyActual = $currentActual - $prevActual;
                    
                    $currentPlan = $scurve['plan'][$lastWeekIndex] ?? 0;
                    $prevPlan = $lastWeekIndex > 0 ? ($scurve['plan'][$lastWeekIndex - 1] ?? 0) : 0;
                    $weeklyPlan = $currentPlan - $prevPlan;
                    
                    $deviasiMingguan = round($weeklyActual - $weeklyPlan, 2);
                }
            }
            
            if ($deviasiMingguan <= -10.0) {
                $statusIndikator = 'Merah (Kritis)';
            } elseif ($deviasiMingguan <= -5.0) {
                $statusIndikator = 'Kuning (Perhatian)';
            } else {
                $statusIndikator = 'Hijau (Sesuai Rencana)';
            }
            
            $tglSelesai = strtotime($p['tgl_selesai']);
            if ($tglSelesai < time() && $p['status'] !== 'Selesai') {
                $daysOver = floor((time() - $tglSelesai) / 86400);
                if ($daysOver > 14) {
                    $statusIndikator = 'Merah (Kritis)';
                } elseif (strpos($statusIndikator, 'Merah') === false) {
                    $statusIndikator = 'Kuning (Perhatian)';
                }
            }
            
            $summaryData[] = [
                'Nama Proyek' => $p['nama_proyek'],
                'No Kontrak' => $p['no_kontrak'],
                'Nilai Kontrak' => $p['nilai_kontrak'],
                'Penyedia' => $p['nama_penyedia'],
                'Mulai' => $p['tgl_mulai'],
                'Selesai' => $p['tgl_selesai'],
                'Realisasi Kumulatif (%)' => number_format($realisasiTerakhir, 2),
                'Deviasi Kumulatif (%)' => number_format($deviasiTerakhir, 2),
                'Deviasi Mingguan (%)' => number_format($deviasiMingguan, 2),
                'Status' => $statusIndikator
            ];
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="Summary_Progres_Proyek_'.date('Ymd').'.csv"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM
        
        if (!empty($summaryData)) {
            fputcsv($output, array_keys($summaryData[0]));
            foreach ($summaryData as $row) {
                fputcsv($output, $row);
            }
        } else {
            fputcsv($output, ['Tidak ada data proyek']);
        }
        fclose($output);
        exit;
    }

    public function calculateMonevScurve($proyek, $jadwalItems, $harianItems)
    {
        $tglMulai = strtotime($proyek['tgl_mulai']);
        $tglSelesai = strtotime($proyek['tgl_selesai']);
        
        $durationDays = ($tglSelesai - $tglMulai) / 86400 + 1;
        $totalWeeks = max(1, ceil($durationDays / 7));
        
        $harianByItem = [];
        foreach ($harianItems as $h) {
            // Only count verified logs for the official actual curve to ensure validation flow
            if ($h['is_verified'] == 1) {
                $harianByItem[$h['item_id']][] = $h;
            }
        }
        
        $labels = [];
        $planWeights = [];
        $actualWeights = [];
        $deviasinya = [];
        
        $currentDate = date('Y-m-d');
        
        for ($w = 1; $w <= $totalWeeks; $w++) {
            $weekEndTimestamp = $tglMulai + ($w * 7 - 1) * 86400;
            if ($weekEndTimestamp > $tglSelesai || $w == $totalWeeks) {
                $weekEndTimestamp = $tglSelesai;
            }
            $weekEndDate = date('Y-m-d', $weekEndTimestamp);
            
            // Label for week
            $labels[] = "M" . $w . " (" . date('d/m', $weekEndTimestamp) . ")";
            
            // 1. Calculate Plan
            $weekPlanSum = 0;
            foreach ($jadwalItems as $item) {
                $bobot = (float)$item['bobot'];
                $targets = json_decode($item['target_mingguan'] ?? '[]', true);
                if (!is_array($targets)) $targets = [];
                
                $targetIndex = $w - 1;
                if ($targetIndex < count($targets)) {
                    $targetVal = (float)$targets[$targetIndex];
                } else {
                    $targetVal = !empty($targets) ? (float)end($targets) : 100.0;
                }
                
                $weekPlanSum += $bobot * ($targetVal / 100);
            }
            $planWeights[] = round($weekPlanSum, 2);
            
            // 2. Calculate Actual
            $weekActualSum = 0;
            foreach ($jadwalItems as $item) {
                $bobot = (float)$item['bobot'];
                $itemId = $item['id'];
                
                $latestProgress = 0;
                if (isset($harianByItem[$itemId])) {
                    foreach ($harianByItem[$itemId] as $h) {
                        if ($h['tanggal'] <= $weekEndDate) {
                            if ((float)$h['progres_persen'] > $latestProgress) {
                                $latestProgress = (float)$h['progres_persen'];
                            }
                        }
                    }
                }
                $weekActualSum += $bobot * ($latestProgress / 100);
            }
            
            $weekStartDate = date('Y-m-d', $tglMulai + (($w - 1) * 7) * 86400);
            
            // Tampilkan data aktual jika minggu ini sudah lewat kalender berjalan, 
            // ATAU minggu ini memiliki data harian yang sudah diinput (untuk kasus input lebih awal dari tgl mulai).
            $maxHarianDate = null;
            foreach ($harianItems as $h) {
                if ($h['is_verified'] == 1) {
                    if ($maxHarianDate === null || $h['tanggal'] > $maxHarianDate) {
                        $maxHarianDate = $h['tanggal'];
                    }
                }
            }
            
            $weekHasHappened = ($weekStartDate <= $currentDate);
            $weekHasData = ($maxHarianDate !== null && $weekStartDate <= $maxHarianDate);
            
            if ($weekHasHappened || $weekHasData) {
                $actualWeights[] = round($weekActualSum, 2);
                $deviasinya[] = round($weekActualSum - $weekPlanSum, 2);
            } else {
                $actualWeights[] = null;
                $deviasinya[] = null;
            }
        }
        
        return [
            'labels' => $labels,
            'plan' => $planWeights,
            'actual' => $actualWeights,
            'deviasi' => $deviasinya
        ];
    }

    public function saveMonevProyek()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Hanya PPK yang dapat mengelola proyek.']);
        }
        
        $proyekModel = new MonevProyekModel();
        
        $id = $this->request->getPost('id');
        $data = [
            'user_id'            => session()->get('id'),
            'kd_rup'             => trim($this->request->getPost('kd_rup') ?? ''),
            'nama_proyek'        => trim($this->request->getPost('nama_proyek') ?? ''),
            'lokasi'             => trim($this->request->getPost('lokasi') ?? ''),
            'no_kontrak'         => trim($this->request->getPost('no_kontrak') ?? ''),
            'nilai_kontrak'      => (float)$this->request->getPost('nilai_kontrak'),
            'tgl_mulai'          => $this->request->getPost('tgl_mulai'),
            'tgl_selesai'        => $this->request->getPost('tgl_selesai'),
            'nama_penyedia'      => trim($this->request->getPost('nama_penyedia') ?? ''),
            'konsultan_pengawas' => trim($this->request->getPost('konsultan_pengawas') ?? ''),
            'ppk'                => trim($this->request->getPost('ppk') ?? ''),
            'sumber_dana'        => trim($this->request->getPost('sumber_dana') ?? ''),
            'jenis_pekerjaan'    => trim($this->request->getPost('jenis_pekerjaan') ?? ''),
            'metode_kontrak'     => trim($this->request->getPost('metode_kontrak') ?? ''),
            'gps_kordinat'       => trim($this->request->getPost('gps_kordinat') ?? ''),
            'polygon_lokasi'     => trim($this->request->getPost('polygon_lokasi') ?? ''),
            'target_progres_mingguan' => trim($this->request->getPost('target_progres_mingguan') ?? ''),
            'pphp'               => trim($this->request->getPost('pphp') ?? ''),
            'direksi_teknis'     => trim($this->request->getPost('direksi_teknis') ?? ''),
            'status'             => $this->request->getPost('status') ?: 'Draft'
        ];

        // Handle file uploads
        $fileKontrak = $this->request->getFile('file_kontrak');
        if ($fileKontrak && $fileKontrak->isValid() && !$fileKontrak->hasMoved()) {
            $newName = $fileKontrak->getRandomName();
            $fileKontrak->move(FCPATH . 'uploads/monev', $newName);
            $data['file_kontrak'] = 'uploads/monev/' . $newName;
        }

        $fileMc = $this->request->getFile('dokumen_mc');
        if ($fileMc && $fileMc->isValid() && !$fileMc->hasMoved()) {
            $newName = $fileMc->getRandomName();
            $fileMc->move(FCPATH . 'uploads/monev', $newName);
            $data['dokumen_mc'] = 'uploads/monev/' . $newName;
        }
        
        if (strtotime($data['tgl_selesai']) <= strtotime($data['tgl_mulai'])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Tanggal selesai harus setelah tanggal mulai kontrak.']);
        }
        
        if ($id) {
            if ($proyekModel->update($id, $data) === false) {
                return $this->response->setJSON(['status' => 'error', 'message' => implode(' ', $proyekModel->errors())]);
            }
            $msg = 'Berhasil memperbarui data proyek.';
        } else {
            $insertedId = $proyekModel->insert($data);
            if ($insertedId === false) {
                return $this->response->setJSON(['status' => 'error', 'message' => implode(' ', $proyekModel->errors())]);
            }
            $id = $insertedId;
            $msg = 'Berhasil menambahkan data proyek baru.';
        }
        
        return $this->response->setJSON(['status' => 'success', 'message' => $msg, 'proyek_id' => $id]);
    }

    public function deleteMonevProyek($id)
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return redirect()->back()->with('error', 'Aksi ini hanya diperbolehkan untuk role PPK.');
        }
        
        $proyekModel = new MonevProyekModel();
        $proyek = $proyekModel->where('id', $id)->where('user_id', session()->get('id'))->first();
        if (!$proyek) {
            return redirect()->back()->with('error', 'Proyek tidak ditemukan.');
        }
        
        $proyekModel->delete($id);
        return redirect()->to('/dashboard/monev-proyek')->with('success', 'Berhasil menghapus proyek.');
    }

    public function saveMonevJadwal()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Hanya PPK yang dapat mengubah jadwal.']);
        }
        
        $proyekId = $this->request->getPost('proyek_id');
        $proyekModel = new MonevProyekModel();
        $proyek = $proyekModel->where('id', $proyekId)->where('user_id', session()->get('id'))->first();
        if (!$proyek) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Proyek tidak ditemukan.']);
        }
        
        $items = $this->request->getPost('item_pekerjaan') ?: [];
        $bobots = $this->request->getPost('bobot') ?: [];
        $targetsWeekly = $this->request->getPost('target_weekly') ?: [];
        
        $totalBobot = 0;
        foreach ($bobots as $b) {
            $totalBobot += (float)$b;
        }
        
        if (abs($totalBobot - 100.0) > 0.01) {
            return $this->response->setJSON(['status' => 'error', 'message' => "Total bobot harus sama dengan 100%. Total saat ini: " . number_format($totalBobot, 2) . "%"]);
        }
        
        $jadwalModel = new MonevJadwalModel();
        
        $db = \Config\Database::connect();
        $db->table('monev_jadwal')->where('proyek_id', $proyekId)->delete();
        
        for ($i = 0; $i < count($items); $i++) {
            if (empty(trim($items[$i]))) continue;
            
            $targs = isset($targetsWeekly[$i]) ? $targetsWeekly[$i] : [];
            if (is_string($targs)) {
                $targs = array_map('floatval', array_map('trim', explode(',', $targs)));
            } else {
                $targs = array_map('floatval', $targs);
            }
            
            $jadwalModel->insert([
                'proyek_id' => $proyekId,
                'item_pekerjaan' => trim($items[$i]),
                'bobot' => (float)$bobots[$i],
                'target_mingguan' => json_encode($targs)
            ]);
        }
        
        return $this->response->setJSON(['status' => 'success', 'message' => 'Jadwal baseline (Kurva S) berhasil disimpan!']);
    }

    public function saveMonevHarian()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Hanya PPK yang dapat menginput laporan progress proyek.']);
        }

        $proyekId = $this->request->getPost('proyek_id');
        $proyekModel = new MonevProyekModel();
        $proyek = $proyekModel->find($proyekId);
        if (!$proyek) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Proyek tidak ditemukan.']);
        }
        
        $tanggal = $this->request->getPost('tanggal');
        if ($tanggal < $proyek['tgl_mulai'] || $tanggal > $proyek['tgl_selesai']) {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => "Tanggal pekerjaan ({$tanggal}) di luar batas masa kontrak proyek (" . date('d-m-Y', strtotime($proyek['tgl_mulai'])) . " s/d " . date('d-m-Y', strtotime($proyek['tgl_selesai'])) . ")."
            ]);
        }
        
        $itemId = $this->request->getPost('item_id');
        $progresPersen = (float)$this->request->getPost('progres_persen');
        $keterangan = trim($this->request->getPost('keterangan') ?? '');
        
        // Calculate the project week of the reported date
        $tglMulai = strtotime($proyek['tgl_mulai']);
        $tanggalTime = strtotime($tanggal);
        $daysDiff = ($tanggalTime - $tglMulai) / 86400;
        $w = max(1, floor($daysDiff / 7) + 1);
        
        // Fetch baseline plan target for this item at this week
        $jadwalModel = new MonevJadwalModel();
        $jadwalItem = $jadwalModel->find($itemId);
        $plannedProgress = 0.0;
        if ($jadwalItem) {
            $targets = json_decode($jadwalItem['target_mingguan'] ?? '[]', true);
            if (is_array($targets) && !empty($targets)) {
                $targetIndex = $w - 1;
                if ($targetIndex < count($targets)) {
                    $plannedProgress = (float)$targets[$targetIndex];
                } else {
                    $plannedProgress = (float)end($targets);
                }
            }
        }
        
        // Enforce validation: if progress exceeds plan, require 'keterangan' (justification of spike)
        if ($progresPersen > $plannedProgress && empty($keterangan)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => "Progres yang dilaporkan ({$progresPersen}%) melebihi target rencana minggu ke-{$w} ({$plannedProgress}%) untuk item ini (terdeteksi lonjakan tidak wajar). Harap lengkapi kolom 'Justifikasi / Keterangan Lonjakan' terlebih dahulu."
            ]);
        }
        
        $harianModel = new MonevHarianModel();
        $prevLogs = $harianModel->where('proyek_id', $proyekId)->where('item_id', $itemId)->orderBy('tanggal', 'DESC')->findAll();
        $prevProgress = 0;
        foreach ($prevLogs as $pl) {
            if ($pl['tanggal'] < $tanggal) {
                $prevProgress = (float)$pl['progres_persen'];
                break;
            }
        }
        
        $warning = null;
        if ($progresPersen > 100.0) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Progres fisik pekerjaan tidak boleh melebihi 100%.']);
        }
        
        if ($progresPersen < $prevProgress) {
            $warning = "Peringatan: Progres yang dilaporkan ({$progresPersen}%) lebih kecil dari progres sebelumnya ({$prevProgress}%).";
        } elseif (($progresPersen - $prevProgress) > 50.0) {
            $warning = "Peringatan: Lonjakan progres tidak wajar terdeteksi (+ " . ($progresPersen - $prevProgress) . "% dalam satu laporan). Butuh verifikasi ketat.";
        }
        
        // Upload Photos
        $fotoPaths = ['foto_awal' => '', 'foto_proses' => '', 'foto_hasil' => ''];
        $fields = ['foto_awal', 'foto_proses', 'foto_hasil'];
        
        $uploadPath = ROOTPATH . 'public/uploads/monev';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }
        
        foreach ($fields as $field) {
            $file = $this->request->getFile($field);
            if ($file && $file->isValid() && !$file->hasMoved()) {
                $newName = $file->getRandomName();
                $file->move($uploadPath, $newName);
                $fotoPaths[$field] = '/uploads/monev/' . $newName;
            } else {
                if (!$this->request->getPost('id')) {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => "Ketiga foto lapangan (kondisi awal, proses, hasil) wajib diunggah."
                    ]);
                }
            }
        }
        
        $id = $this->request->getPost('id');
        $data = [
            'proyek_id'      => $proyekId,
            'item_id'        => $itemId,
            'tanggal'        => $tanggal,
            'volume_selesai' => (float)$this->request->getPost('volume_selesai'),
            'satuan'         => trim($this->request->getPost('satuan') ?? ''),
            'lokasi'         => trim($this->request->getPost('lokasi') ?? ''),
            'tenaga_kerja'   => trim($this->request->getPost('tenaga_kerja') ?? ''),
            'peralatan'      => trim($this->request->getPost('peralatan') ?? ''),
            'kendala'        => trim($this->request->getPost('kendala') ?? ''),
            'keterangan'     => $keterangan,
            'progres_persen' => $progresPersen
        ];
        
        if ($id) {
            $existing = $harianModel->find($id);
            foreach ($fields as $field) {
                if (empty($fotoPaths[$field]) && isset($existing[$field])) {
                    $fotoPaths[$field] = $existing[$field];
                }
            }
        }
        
        $data = array_merge($data, $fotoPaths);
        
        if ($id) {
            $harianModel->update($id, $data);
            $msg = 'Berhasil memperbarui laporan harian.';
        } else {
            $data['is_verified'] = 0;
            $id = $harianModel->insert($data);
            $msg = 'Berhasil menambahkan laporan harian baru.';
        }
        
        return $this->response->setJSON([
            'status' => 'success', 
            'message' => $msg, 
            'warning' => $warning,
            'harian_id' => $id
        ]);
    }

    public function verifyMonevHarian($id)
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'operator') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Hanya akun Operator yang berwenang melakukan validasi laporan.']);
        }

        $db = \Config\Database::connect();
        
        // Ambil data langsung via raw SQL
        $log = $db->query("SELECT * FROM monev_harian WHERE id = ?", [$id])->getRowArray();
        if (!$log) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Laporan harian tidak ditemukan.']);
        }
        
        $currentVerified = (int)$log['is_verified'];
        $newStatus = $currentVerified == 1 ? 0 : 1;
        $verifiedAt = $newStatus == 1 ? date('Y-m-d H:i:s') : null;
        
        // Eksekusi langsung via raw SQL agar tidak terblokir oleh framework apapun
        if ($verifiedAt !== null) {
            $db->query("UPDATE monev_harian SET is_verified = ?, verified_at = ? WHERE id = ?", [$newStatus, $verifiedAt, $id]);
        } else {
            $db->query("UPDATE monev_harian SET is_verified = ?, verified_at = NULL WHERE id = ?", [$newStatus, $id]);
        }
        
        // Verifikasi bahwa update benar-benar berhasil
        $check = $db->query("SELECT is_verified, verified_at FROM monev_harian WHERE id = ?", [$id])->getRowArray();
        
        $msg = $newStatus == 1 ? 'Laporan harian berhasil diverifikasi dan disetujui!' : 'Verifikasi laporan harian dibatalkan.';
        return $this->response->setJSON([
            'status' => 'success', 
            'message' => $msg, 
            'is_verified' => $newStatus,
            'debug_before' => $currentVerified,
            'debug_after' => $check['is_verified'] ?? 'N/A',
            'debug_id' => $id
        ]);
    }

    public function saveMonevDokumen()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return redirect()->back()->with('error', 'Hanya PPK yang dapat mengupload dokumen proyek.');
        }

        $proyekId = $this->request->getPost('proyek_id');
        $proyekModel = new MonevProyekModel();
        $proyek = $proyekModel->find($proyekId);
        if (!$proyek) {
            return redirect()->back()->with('error', 'Proyek tidak ditemukan.');
        }
        
        $file = $this->request->getFile('file_dokumen');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $uploadPath = ROOTPATH . 'public/uploads/monev/docs';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            $newName = $file->getRandomName();
            $file->move($uploadPath, $newName);
            
            $dokumenModel = new MonevDokumenModel();
            $dokumenModel->insert([
                'proyek_id' => $proyekId,
                'nama_dokumen' => trim($this->request->getPost('nama_dokumen') ?? $file->getClientName()),
                'kategori' => $this->request->getPost('kategori') ?: 'Lainnya',
                'file_path' => '/uploads/monev/docs/' . $newName
            ]);
            
            return redirect()->to('/dashboard/monev-proyek?proyek_id=' . $proyekId)->with('success', 'Berhasil mengunggah dokumen pendukung.');
        }
        
        return redirect()->back()->with('error', 'Gagal mengunggah file. Pastikan format file sesuai.');
    }

    public function getMonevChartData($proyekId)
    {
        $proyekModel = new MonevProyekModel();
        $proyek = $proyekModel->find($proyekId);
        if (!$proyek) {
            return $this->response->setJSON([]);
        }
        
        $jadwalModel = new MonevJadwalModel();
        $jadwalItems = $jadwalModel->where('proyek_id', $proyekId)->findAll();
        
        $harianModel = new MonevHarianModel();
        $harianItems = $harianModel->select('monev_harian.*, monev_jadwal.item_pekerjaan, monev_jadwal.bobot')
                                  ->join('monev_jadwal', 'monev_jadwal.id = monev_harian.item_id')
                                  ->where('monev_harian.proyek_id', $proyekId)
                                  ->orderBy('monev_harian.tanggal', 'DESC')
                                  ->findAll();
        
        $scurve = $this->calculateMonevScurve($proyek, $jadwalItems, $harianItems);
        
        return $this->response->setJSON($scurve);
    }

    private function _getPpkRupCodes()
    {
        $mappingModel = new \App\Models\PpkRupMappingModel();
        $mappings = $mappingModel->where('user_id', session()->get('id'))->findAll();
        if (empty($mappings)) {
            return ['0'];
        }

        $kdPakets = array_column($mappings, 'kd_paket');
        
        $db = \Config\Database::connect();
        $rupCodes = [];
        
        // Tender
        $tenderRups = $db->table('lpse_tender')
                         ->select('kd_rup')
                         ->whereIn('kd_paket', $kdPakets)
                         ->get()
                         ->getResultArray();
        foreach ($tenderRups as $r) {
            if (!empty($r['kd_rup'])) {
                $rupCodes[] = $r['kd_rup'];
            }
        }
        
        // Non-Tender
        $nonTenderRups = $db->table('lpse_nontender')
                            ->select('kd_rup')
                            ->whereIn('kd_paket', $kdPakets)
                            ->get()
                            ->getResultArray();
        foreach ($nonTenderRups as $r) {
            if (!empty($r['kd_rup'])) {
                $rupCodes[] = $r['kd_rup'];
            }
        }
        
        // Epurchasing
        $epurchasingRups = $db->table('epurchasing')
                              ->select('rup_code')
                              ->whereIn('kd_paket', $kdPakets)
                              ->get()
                              ->getResultArray();
        foreach ($epurchasingRups as $r) {
            if (!empty($r['rup_code'])) {
                $rupCodes[] = $r['rup_code'];
            }
        }
        
        $rupCodes = array_unique(array_filter($rupCodes));
        
        return !empty($rupCodes) ? $rupCodes : ['0'];
    }

    public function getRupDetails($kdPaket)
    {
        $kdPaket = trim($kdPaket);
        if (empty($kdPaket)) {
            return $this->fail('Kode paket tidak boleh kosong.');
        }

        $db = \Config\Database::connect();
        
        // Cari di Tender
        $paket = $db->table('lpse_tender')->where('kd_paket', $kdPaket)->get()->getRowArray();
        $type = 'Tender';
        
        if (!$paket) {
            // Cari di Non-Tender
            $paket = $db->table('lpse_nontender')->where('kd_paket', $kdPaket)->get()->getRowArray();
            $type = 'Non-Tender';
        }
        
        if (!$paket) {
            // Cari di E-Purchasing
            $paket = $db->table('epurchasing')->where('kd_paket', $kdPaket)->get()->getRowArray();
            $type = 'E-Purchasing';
        }

        if (!$paket) {
            return $this->failNotFound('Paket SPSE tidak ditemukan.');
        }

        $kdRup = $type === 'E-Purchasing' ? ($paket['rup_code'] ?? '-') : ($paket['kd_rup'] ?? '-');
        $nilaiKontrak = $type === 'E-Purchasing' ? ($paket['total_harga'] ?? 0) : ($paket['nilai_kontrak'] ?? 0);
        $noKontrak = $type === 'E-Purchasing' ? $paket['kd_paket'] : ($paket['no_kontrak'] ?? '');

        return $this->response->setJSON([
            'kd_paket'      => $paket['kd_paket'],
            'kd_rup'        => $kdRup,
            'nama_paket'    => $paket['nama_paket'],
            'nama_satker'   => $paket['nama_satker'] ?? 'N/A',
            'pagu'          => $paket['pagu'],
            'pagu_format'   => 'Rp ' . number_format($paket['pagu'], 0, ',', '.'),
            'nilai_kontrak' => $nilaiKontrak,
            'nilai_kontrak_format' => 'Rp ' . number_format($nilaiKontrak, 0, ',', '.'),
            'nama_penyedia' => $paket['nama_penyedia'] ?? '',
            'no_kontrak'    => $noKontrak,
            'type'          => $type,
            'tahun'         => $paket['tahun'] ?? date('Y')
        ]);
    }

    public function addMonevPaket()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['status' => 'error', 'message' => 'Aksi ini hanya diperbolehkan untuk role PPK.']);
            }
            return redirect()->back()->with('error', 'Aksi ini hanya diperbolehkan untuk role PPK.');
        }

        $kdPaket = trim($this->request->getPost('kd_paket') ?? '');
        if (empty($kdPaket)) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['status' => 'error', 'message' => 'Kode Paket tidak boleh kosong.']);
            }
            return redirect()->back()->with('error', 'Kode Paket tidak boleh kosong.');
        }

        $db = \Config\Database::connect();
        
        $type = null;
        $paket = null;
        
        // Cari di Tender
        $check = $db->table('lpse_tender')->where('kd_paket', $kdPaket)->get()->getRowArray();
        if ($check) {
            $type = 'Tender';
            $paket = $check;
        } else {
            // Cari di Non-Tender
            $check = $db->table('lpse_nontender')->where('kd_paket', $kdPaket)->get()->getRowArray();
            if ($check) {
                $type = 'Non-Tender';
                $paket = $check;
            } else {
                // Cari di E-Purchasing
                $check = $db->table('epurchasing')->where('kd_paket', $kdPaket)->get()->getRowArray();
                if ($check) {
                    $type = 'E-Purchasing';
                    $paket = $check;
                }
            }
        }

        if (!$paket) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['status' => 'error', 'message' => "Kode Paket {$kdPaket} tidak ditemukan di database transaksi SPSE."]);
            }
            return redirect()->back()->with('error', "Kode Paket {$kdPaket} tidak ditemukan di database transaksi SPSE.");
        }

        $mappingModel = new \App\Models\PpkRupMappingModel();
        
        $alreadyClaimed = $mappingModel->where([
            'user_id'  => session()->get('id'),
            'kd_paket' => $kdPaket
        ])->first();

        if ($alreadyClaimed) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['status' => 'error', 'message' => "Kode Paket {$kdPaket} sudah ada di daftar monitoring Anda."]);
            }
            return redirect()->back()->with('error', "Kode Paket {$kdPaket} sudah ada di daftar monitoring Anda.");
        }

        $mappingModel->save([
            'user_id'  => session()->get('id'),
            'kd_paket' => $kdPaket,
            'type'     => $type
        ]);

        if ($this->request->isAJAX()) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => "Berhasil menambahkan paket SPSE {$kdPaket} [{$type}] ke monitoring Anda.",
                'data' => [
                    'kd_paket'   => $paket['kd_paket'],
                    'kd_rup'     => $type === 'E-Purchasing' ? ($paket['rup_code'] ?? '-') : ($paket['kd_rup'] ?? '-'),
                    'nama_paket' => $paket['nama_paket'],
                    'pagu'       => $paket['pagu'],
                    'type'       => $type
                ]
            ]);
        }

        return redirect()->to('/dashboard/monev-proyek')->with('success', "Berhasil menambahkan paket SPSE {$kdPaket} [{$type}] ke monitoring Anda.");
    }

    public function removeMonevPaket($kdPaket)
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['status' => 'error', 'message' => 'Aksi ini hanya diperbolehkan untuk role PPK.']);
            }
            return redirect()->back()->with('error', 'Aksi ini hanya diperbolehkan untuk role PPK.');
        }

        $mappingModel = new \App\Models\PpkRupMappingModel();
        $mappingModel->where([
            'user_id'  => session()->get('id'),
            'kd_paket' => $kdPaket
        ])->delete();

        if ($this->request->isAJAX()) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => "Berhasil menghapus paket SPSE {$kdPaket} dari monitoring Anda."
            ]);
        }

        return redirect()->to('/dashboard/monev-proyek')->with('success', "Berhasil menghapus paket SPSE {$kdPaket} dari monitoring Anda.");
    }

    public function analyzeAnomaly()
    {
        if (!$this->request->isAJAX()) {
            return $this->failForbidden('Hanya menerima request AJAX.');
        }

        $satker = $this->request->getPost('satker');
        $program = $this->request->getPost('program');
        $paguMaster = $this->request->getPost('pagu_master');
        $paguRup = $this->request->getPost('pagu_rup');
        $packagesInfo = $this->request->getPost('packages_info');

        // Cache logic for token efficiency (v2 to clear old cut-off caches)
        $cacheKey = md5("anomaly_analysis_v2_" . $satker . $program . $paguMaster . $paguRup);
        if ($cached = cache($cacheKey)) {
            return $this->response->setJSON(['status' => 'success', 'analysis' => $cached]);
        }

        $settingsModel = new \App\Models\SettingsModel();
        $apiKey = $settingsModel->getSetting('chatbot_api_key', env('OPENAI_API_KEY'));
        $model = $settingsModel->getSetting('chatbot_model', 'gpt-4o-mini');
        $apiUrl = $settingsModel->getSetting('chatbot_api_url', 'https://api.openai.com/v1/chat/completions');

        if (empty($apiKey)) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'API Key OpenAI tidak dikonfigurasi.']);
        }

        $prompt = "Anda adalah Auditor Pengadaan dan Konsultan Manajemen. 
Ditemukan anomali pada pengumuman RUP (Rencana Umum Pengadaan) untuk program '{$program}' di Instansi '{$satker}'.
Data Anggaran (Pagu Master): Rp " . number_format((float)$paguMaster, 0, ',', '.') . "
Data Terumumkan di SIRUP (Pagu RUP): Rp " . number_format((float)$paguRup, 0, ',', '.') . "
Detail Paket Terumumkan: " . $packagesInfo . "

Analisa singkat (maksimal 3-4 kalimat pendek yang profesional) mengapa Pagu RUP jauh berbeda dari Pagu Master, apa potensi risikonya, dan berikan saran tindak lanjut yang tepat. Format output dengan bullet points singkat jika perlu.";

        $data = [
            'model' => $model,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => 800,
            'temperature' => 0.5
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Koneksi ke AI gagal: ' . $error]);
        }

        $responseArray = json_decode($response, true);
        $analysis = $responseArray['choices'][0]['message']['content'] ?? 'Tidak dapat menganalisa data saat ini.';

        // Simpan di cache selama 7 hari (7 * 24 * 60 * 60 detik)
        cache()->save($cacheKey, $analysis, 604800);

        return $this->response->setJSON(['status' => 'success', 'analysis' => $analysis]);
    }

    public function analyzeEpurchasing()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setBody('Forbidden');
        }

        $summaryData = $this->request->getPost('summary');
        
        $cacheKey = md5("epurchasing_ai_analysis_v3_" . json_encode($summaryData));
        if ($cached = cache($cacheKey)) {
            return $this->response->setJSON(['status' => 'success', 'analysis' => $cached]);
        }

        $settingsModel = new \App\Models\SettingsModel();
        $apiKey = $settingsModel->getSetting('chatbot_api_key', env('OPENAI_API_KEY'));
        $model = $settingsModel->getSetting('chatbot_model', 'gpt-4o-mini');
        $apiUrl = $settingsModel->getSetting('chatbot_api_url', 'https://api.openai.com/v1/chat/completions');

        if (empty($apiKey)) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'API Key OpenAI tidak dikonfigurasi.']);
        }

        $prompt = "Anda adalah AI Analis E-Purchasing Katalog Pemerintah yang bertugas menganalisis data transaksi belanja katalog elektronik secara cerdas, profesional, dan kontekstual berdasarkan waktu realisasi aktual.

Fokus utama Anda adalah:
- analisis transaksi e-purchasing,
- analisis vendor dan produk,
- analisis pola belanja,
- analisis status transaksi,
- analisis tren realisasi,
- deteksi anomali,
- dan pemberian insight strategis.

Anda harus bertindak sebagai analis pengadaan profesional, bukan sekadar pembaca tabel.

---

# ATURAN WAKTU REALISASI (SANGAT PENTING)

Saat menganalisis tren bulanan atau realisasi tahunan:
- Gunakan tanggal saat ini sebagai acuan analisis.
- Abaikan bulan yang memang belum memasuki periode pelaksanaan.
- Jangan menganggap bulan yang belum terjadi sebagai anomali atau nol realisasi.
- Jangan menyimpulkan keterlambatan jika periode pelaksanaan belum masuk.
- Fokus hanya pada bulan yang sudah berjalan hingga bulan saat ini.

---

# DATA YANG DITERIMA
" . json_encode($summaryData, JSON_PRETTY_PRINT) . "

---

# GAYA JAWABAN
- Gunakan bahasa Indonesia formal namun mudah dipahami.
- Fokus pada insight penting.
- Hindari membaca ulang data mentah.
- Ringkas tetapi analitis.
- Jangan mengarang data.
- JANGAN membandingkan nilai anggaran antar vendor atau membahas persaingan harga antar vendor secara berlebihan. Fokus vendor pada produk apa yang mereka sediakan.

---

# FORMAT OUTPUT Wajib
## Ringkasan Utama
(Tuliskan insight utama dalam 1-3 paragraf)
## Temuan Penting
(Gunakan bullet point)
## Analisis Detail
(Bahas belanja, vendor & produk, status transaksi, tren waktu, risiko)
## Risiko atau Perhatian
(Jelaskan hal yang perlu perhatian khusus)
## Rekomendasi
(Berikan rekomendasi konkret dan praktis)";

        $data = [
            'model' => $model,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => 2000,
            'temperature' => 0.5
        ];

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Koneksi ke AI gagal: ' . $error]);
        }

        $responseArray = json_decode($response, true);
        $analysis = $responseArray['choices'][0]['message']['content'] ?? 'Tidak dapat menganalisa data saat ini.';

        cache()->save($cacheKey, $analysis, 86400);

        return $this->response->setJSON(['status' => 'success', 'analysis' => $analysis]);
    }

    public function generateWeeklyAiAnalysis()
    {
        $userRole = trim(strtolower(session()->get('role') ?? ''));
        if ($userRole !== 'ppk') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Hanya pengguna dengan role PPK yang dapat melakukan analisis AI.']);
        }

        $proyekId = $this->request->getPost('proyek_id');
        $week = (int)$this->request->getPost('week');
        $deviasi = (float)$this->request->getPost('deviasi');

        if (!$proyekId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'ID Proyek tidak valid.']);
        }

        // Self-healing database check
        $db = \Config\Database::connect();
        if (!$db->fieldExists('weekly_ai_analysis', 'monev_proyek')) {
            $db->query("ALTER TABLE monev_proyek ADD COLUMN weekly_ai_analysis TEXT NULL AFTER dokumen_mc");
        }

        $proyekModel = new \App\Models\MonevProyekModel();
        $harianModel = new \App\Models\MonevHarianModel();
        
        $proyek = $proyekModel->find($proyekId);
        if (!$proyek) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Proyek tidak ditemukan.']);
        }

        // Ambil data logbook harian untuk minggu tersebut
        $tglMulai = strtotime($proyek['tgl_mulai']);
        $weekStart = date('Y-m-d', $tglMulai + ($week - 1) * 7 * 86400);
        $weekEnd = date('Y-m-d', $tglMulai + $week * 7 * 86400 - 86400);

        $harianLogs = $harianModel->where('proyek_id', $proyekId)
                                  ->where('tanggal >=', $weekStart)
                                  ->where('tanggal <=', $weekEnd)
                                  ->findAll();

        $kendalaAsli = [];
        $itemsKerja = [];
        foreach ($harianLogs as $log) {
            if (!empty($log['kendala'])) {
                $kendalaAsli[] = $log['tanggal'] . ': ' . $log['kendala'];
            }
            $itemsKerja[] = $log['lokasi'] ?? '';
        }
        $kendalaText = !empty($kendalaAsli) ? implode("; ", array_unique($kendalaAsli)) : 'Tidak ada laporan kendala spesifik di logbook harian.';
        $lokasiText = !empty($itemsKerja) ? implode(", ", array_filter(array_unique($itemsKerja))) : '-';

        // Lakukan semantic RAG search di knowledge base jika ada
        $sopRujukan = "Gunakan pedoman standar percepatan konstruksi (SOP SCM - Show Cause Meeting).";
        try {
            $chatbot = new \App\Controllers\Chatbot();
            $chatbot->initController($this->request, $this->response, $this->logger);
            $searchQuery = ($proyek['jenis_pekerjaan'] ?? '') . ' ' . $kendalaText . ' percepatan konstruksi SCM denda';
            $kbJson = $chatbot->searchKnowledgeBase(json_encode(['query' => $searchQuery]));
            $kbParsed = json_decode($kbJson, true);
            if (isset($kbParsed['top_relevant_rules']) && is_array($kbParsed['top_relevant_rules'])) {
                $topRule = $kbParsed['top_relevant_rules'][0];
                if (($topRule['similarity'] ?? 0) > 0.3) {
                    $sopRujukan = "Merujuk pada pedoman: \"" . ($topRule['document'] ?? 'Pedoman') . "\", klausul: \"" . ($topRule['text'] ?? '') . "\"";
                }
            }
        } catch (\Exception $e) {
            // Fallback
        }

        // Panggil AI menggunakan settings yang sudah disetup user
        $settingsModel = new \App\Models\SettingsModel();
        $apiKey = $settingsModel->getSetting('chatbot_api_key', env('OPENAI_API_KEY'));
        $model = $settingsModel->getSetting('chatbot_model', 'gpt-5.4-mini');
        $apiUrl = $settingsModel->getSetting('chatbot_api_url', 'https://api.ai.cc/v1/chat/completions');

        if (empty($apiKey)) {
            $hambatan = 'API Key kecerdasan belum dikonfigurasi. Kendala: ' . $kendalaText;
            $tindakLanjut = 'Silakan konfigurasikan API Key AI di menu pengaturan.';

            // Persist the fallback results
            $weeklyAnalysis = [];
            if (!empty($proyek['weekly_ai_analysis'])) {
                $weeklyAnalysis = json_decode($proyek['weekly_ai_analysis'], true) ?: [];
            }
            $weeklyAnalysis[$week] = [
                'hambatan' => $hambatan,
                'tindak_lanjut' => $tindakLanjut,
                'generated_by' => session()->get('username') ?? session()->get('nama') ?? 'PPK',
                'generated_at' => date('Y-m-d H:i:s')
            ];
            $proyekModel->update($proyekId, ['weekly_ai_analysis' => json_encode($weeklyAnalysis)]);

            return $this->response->setJSON([
                'status' => 'success',
                'hambatan' => $hambatan,
                'tindak_lanjut' => $tindakLanjut
            ]);
        }

        $systemPrompt = "Kamu adalah AJIP, AI Auditor & Konsultan Manajemen Konstruksi cerdas.
        Tugasmu adalah menganalisis kendala mingguan proyek dan membuat Rencana Tindak Lanjut percepatan konstruksi (SCM) secara profesional dan sangat spesifik.
        Jawablah dengan format JSON yang mengandung dua key:
        1. 'hambatan': Kalimat singkat analisis teknis hambatan berdasarkan kendala asli lapangan.
        2. 'tindak_lanjut': Langkah taktis, terukur, dan operasional (Tindak Lanjut) untuk mengejar ketertinggalan deviasi tersebut.
        Jangan berikan teks penjelasan lain di luar JSON.";

        $userMessage = "Proyek: {$proyek['nama_proyek']} ({$proyek['jenis_pekerjaan']})
        Minggu Pekerjaan: Minggu ke-{$week}
        Deviasi Kumulatif: {$deviasi}% (Terlambat)
        Kendala Lapangan: {$kendalaText}
        Lokasi Pekerjaan: {$lokasiText}
        Referensi SOP/Regulasi: {$sopRujukan}";

        $payload = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $userMessage]
            ],
            'temperature' => 0.5,
            'response_format' => ['type' => 'json_object']
        ];

        // cURL request ke AI
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'api-key: ' . $apiKey
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal terhubung ke AI: ' . $error]);
        }

        $resArray = json_decode($response, true);
        $content = $resArray['choices'][0]['message']['content'] ?? '';
        
        $aiParsed = json_decode($content, true);
        if (!$aiParsed || !isset($aiParsed['hambatan']) || !isset($aiParsed['tindak_lanjut'])) {
            $hambatan = 'Terganggu oleh kendala teknis: ' . $kendalaText;
            $tindakLanjut = 'Lakukan evaluasi ulang Show Cause Meeting (SCM) dan percepat mobilisasi tenaga kerja tambahan.';
        } else {
            $hambatan = $aiParsed['hambatan'];
            $tindakLanjut = $aiParsed['tindak_lanjut'];
        }

        // Save / merge to weekly_ai_analysis column
        $weeklyAnalysis = [];
        if (!empty($proyek['weekly_ai_analysis'])) {
            $weeklyAnalysis = json_decode($proyek['weekly_ai_analysis'], true) ?: [];
        }
        
        $weeklyAnalysis[$week] = [
            'hambatan' => $hambatan,
            'tindak_lanjut' => $tindakLanjut,
            'generated_by' => session()->get('username') ?? session()->get('nama') ?? 'PPK',
            'generated_at' => date('Y-m-d H:i:s')
        ];

        $proyekModel->update($proyekId, [
            'weekly_ai_analysis' => json_encode($weeklyAnalysis)
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'hambatan' => $hambatan,
            'tindak_lanjut' => $tindakLanjut
        ]);
    }

    public function alterDb()
    {
        $db = \Config\Database::connect();
        $sql = "
        ALTER TABLE monev_proyek
        ADD COLUMN lokasi TEXT NULL AFTER nama_proyek,
        ADD COLUMN ppk VARCHAR(255) NULL AFTER konsultan_pengawas,
        ADD COLUMN sumber_dana VARCHAR(100) NULL AFTER ppk,
        ADD COLUMN jenis_pekerjaan VARCHAR(100) NULL AFTER sumber_dana,
        ADD COLUMN metode_kontrak VARCHAR(100) NULL AFTER jenis_pekerjaan,
        ADD COLUMN gps_kordinat VARCHAR(255) NULL AFTER metode_kontrak,
        ADD COLUMN polygon_lokasi TEXT NULL AFTER gps_kordinat,
        ADD COLUMN target_progres_mingguan VARCHAR(100) NULL AFTER polygon_lokasi,
        ADD COLUMN file_kontrak VARCHAR(255) NULL AFTER target_progres_mingguan,
        ADD COLUMN dokumen_mc VARCHAR(255) NULL AFTER file_kontrak;
        ";
        try {
            $db->query($sql);
            return "DB altered successfully";
        } catch (\Exception $e) {
            return "Error: " . $e->getMessage();
        }
    }
}
