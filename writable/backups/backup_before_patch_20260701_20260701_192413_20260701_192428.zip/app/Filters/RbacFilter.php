<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\RolePermissionModel;

class RbacFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (!$session->get('isLoggedIn')) {
            return redirect()->to('/auth');
        }

        $role = $session->get('role');
        if ($role === 'admin') {
            return; // Admin always has all permissions
        }

        $path = $request->getUri()->getPath(); // e.g. "dashboard/comparisons"
        $menuKey = $this->mapPathToMenuKey($path);

        if ($menuKey !== null) {
            $userPermModel = new \App\Models\UserPermissionModel();
            $permModel = new RolePermissionModel();
            
            $userId = $session->get('id');
            
            // Check custom permission first
            $hasCustomAccess = $userPermModel->getCustomPermissionStatus($userId, $menuKey);
            
            $isAllowed = false;
            if ($hasCustomAccess !== null) {
                $isAllowed = $hasCustomAccess;
            } else {
                $isAllowed = $permModel->checkPermission($role, $menuKey);
            }

            if (!$isAllowed) {
                // If it is an AJAX request, return a JSON error
                if ($request->isAJAX()) {
                    $response = service('response');
                    return $response->setJSON([
                        'status' => 'error',
                        'message' => 'Anda tidak memiliki hak akses untuk tindakan ini.'
                    ])->setStatusCode(403);
                }

                $firstUrl = $permModel->getFirstAllowedUrl($role);
                if ($firstUrl) {
                    return redirect()->to(base_url($firstUrl))->with('error', 'Anda tidak memiliki hak akses ke halaman tersebut.');
                } else {
                    $session->destroy();
                    return redirect()->to(base_url('auth'))->with('error', 'Akun Anda tidak memiliki hak akses menu apapun. Silakan hubungi admin.');
                }
            }
        }
    }

    private function mapPathToMenuKey($path)
    {
        $path = trim($path, '/');

        // Exact mappings for main pages
        if ($path === 'dashboard' || $path === 'dashboard/index') {
            return 'dashboard';
        }
        if ($path === 'dashboard/comparisons') {
            return 'comparisons';
        }
        if ($path === 'dashboard/penyedia') {
            return 'penyedia';
        }
        if ($path === 'dashboard/swakelola') {
            return 'swakelola';
        }
        if ($path === 'dashboard/rup-opd') {
            return 'rup-opd';
        }
        if ($path === 'dashboard/dashboard-lpse') {
            return 'dashboard-lpse';
        }
        if ($path === 'dashboard/epurchasing') {
            return 'epurchasing';
        }
        if ($path === 'report') {
            return 'report';
        }

        // LPSE Subpages
        if (strpos($path, 'dashboard/lpse/tender') === 0) {
            return 'lpse_tender';
        }
        if (strpos($path, 'dashboard/lpse/nontender') === 0) {
            return 'lpse_nontender';
        }
        if (strpos($path, 'dashboard/lpse/pencatatan_nontender') === 0) {
            return 'lpse_pencatatan_nontender';
        }
        if (strpos($path, 'dashboard/lpse/pencatatan_swakelola') === 0) {
            return 'lpse_pencatatan_swakelola';
        }

        // Monev Proyek Subpages & Supporting API endpoints
        if ($path === 'dashboard/monev-proyek' || 
            strpos($path, 'dashboard/monev/') === 0 ||
            strpos($path, 'dashboard/add-monev-paket') === 0 ||
            strpos($path, 'dashboard/remove-monev-paket') === 0 ||
            strpos($path, 'dashboard/get-rup-details') === 0) {
            return 'monev';
        }

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
